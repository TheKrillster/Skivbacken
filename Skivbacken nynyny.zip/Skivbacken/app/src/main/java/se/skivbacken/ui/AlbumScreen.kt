package se.skivbacken.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import se.skivbacken.Album
import se.skivbacken.MainViewModel

@Composable
fun AlbumScreen(album: Album, vm: MainViewModel, onBack: () -> Unit) {
    val c = LocalSkiv.current
    val multiDisc = album.discCount > 1
    LazyColumn(
        Modifier.fillMaxSize().background(c.panel),
        contentPadding = WindowInsets.systemBars.asPaddingValues(),
    ) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                PressButton(onClick = onBack, size = 48.dp) { Glyph(Ic.Down, c.ink, Modifier.size(26.dp)) }
                Spacer(Modifier.weight(1f))
                Text(
                    "${vm.albums.indexOf(album) + 1} / ${vm.albums.size}",
                    modifier = Modifier.padding(end = 12.dp), fontFamily = AppFont, fontSize = 12.sp, color = c.inkSoft,
                )
            }
        }
        item {
            BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                val dim = minOf(maxWidth * 0.82f, 340.dp)
                val shape = RoundedCornerShape(3.dp)
                Box(Modifier.size(dim).shadow(16.dp, shape).clip(shape)) {
                    AlbumArt(album, Modifier.fillMaxSize(), dim)
                    Sticker(album, dim)
                }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(album.artist.uppercase(), fontSize = 13.sp, letterSpacing = 0.1.em, color = c.inkSoft, fontWeight = FontWeight.SemiBold)
                Text(
                    album.title, modifier = Modifier.padding(top = 4.dp, bottom = 6.dp),
                    fontSize = 34.sp, lineHeight = 36.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, letterSpacing = (-0.025).em,
                )
                MetaLine(album)
                val ctx = LocalContext.current
                Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { vm.play(album, 0) },
                        colors = ButtonDefaults.buttonColors(containerColor = c.sticker, contentColor = c.stickerInk),
                    ) {
                        Glyph(Ic.Play, c.stickerInk, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Spela skivan", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    OutlinedButton(
                        onClick = {
                            vm.addToQueue(album, album.tracks)
                            Toast.makeText(ctx, "Skivan lagd i kön", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = c.ink),
                    ) {
                        Text("Lägg i kön", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    }
                }
                Text(
                    "Håll fingret på en låt för att lägga den i kön.",
                    modifier = Modifier.padding(top = 10.dp), fontSize = 12.5.sp, color = c.inkSoft,
                )
            }
        }
        itemsIndexed(album.tracks) { i, t ->
            Column {
                if (multiDisc && (i == 0 || album.tracks[i - 1].disc != t.disc)) {
                    Text(
                        "SKIVA ${t.disc}", modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 6.dp),
                        fontFamily = AppFont, fontSize = 11.sp, letterSpacing = 0.12.em, color = c.inkSoft,
                    )
                }
                TrackRow(
                    no = if (t.no > 0) t.no else i + 1,
                    title = t.title,
                    subtitle = t.artist.takeIf { it != album.artist },
                    durationMs = t.durationMs,
                    playing = vm.currentAlbum === album && vm.currentTrackIndex == i,
                    onClick = { vm.play(album, i) },
                    progress = if (vm.currentAlbum === album && vm.currentTrackIndex == i && vm.durationMs > 0)
                        vm.positionMs.toFloat() / vm.durationMs else null,
                    menu = { dismiss -> QueueMenuItems(vm, album, i, dismiss) },
                )
            }
        }
    }
}
