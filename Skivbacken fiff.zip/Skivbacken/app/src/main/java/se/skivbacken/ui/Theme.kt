package se.skivbacken.ui

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

/** Shop palette: sage walls, plywood crates, orange price stickers, a hi-fi deck for the player. */
@Immutable
data class SkivColors(
    val wall: Color, val wall2: Color, val ink: Color, val inkSoft: Color, val line: Color,
    val panel: Color, val chip: Color,
    val ply: Color, val plyDark: Color, val plyGrain: Color, val plyHole: Color,
    val sticker: Color, val stickerInk: Color,
    val vfdBg: Color, val vfdInk: Color,
    val deck: Color, val deckShine: Color,
)

val LightSkiv = SkivColors(
    wall = Color(0xFFDFE3D8), wall2 = Color(0xFFCFD6C6), ink = Color(0xFF1C211B), inkSoft = Color(0xFF5A6357),
    line = Color(0x241C211B), panel = Color(0xFFEBEEE6), chip = Color(0xFFD3D9CB),
    ply = Color(0xFFCFA673), plyDark = Color(0xFFA47A49), plyGrain = Color(0x29704620), plyHole = Color(0xFF5C3F22),
    sticker = Color(0xFFE3502A), stickerInk = Color(0xFFFFFAF2),
    vfdBg = Color(0xFF151C1E), vfdInk = Color(0xFF7FE0CF),
    deck = Color(0xFF2A302C), deckShine = Color(0xFF4A524C),
)

val DarkSkiv = SkivColors(
    wall = Color(0xFF1A1D18), wall2 = Color(0xFF141612), ink = Color(0xFFEBE8DE), inkSoft = Color(0xFF9BA293),
    line = Color(0x21EBE8DE), panel = Color(0xFF20241D), chip = Color(0xFF2B3027),
    ply = Color(0xFF7A5A39), plyDark = Color(0xFF553D25), plyGrain = Color(0x38000000), plyHole = Color(0xFF22170C),
    sticker = Color(0xFFF0643A), stickerInk = Color(0xFFFFFAF2),
    vfdBg = Color(0xFF0C1213), vfdInk = Color(0xFF7FE0CF),
    deck = Color(0xFF0E100D), deckShine = Color(0xFF2C312A),
)

val LocalSkiv = staticCompositionLocalOf { LightSkiv }
/** One typeface for all text in the app (the phone's own, Roboto on most phones; its digits keep equal widths). */
val AppFont: FontFamily = FontFamily.Default

/** An accent colour for the whole app, tuned for light and dark backgrounds. */
class Accent(val name: String, val light: Color, val dark: Color)

val Accents = listOf(
    Accent("Skog", Color(0xFF2F8F5B), Color(0xFF52C48A)),
    Accent("Hav", Color(0xFF2F6FD0), Color(0xFF6EA6FF)),
    Accent("Turkos", Color(0xFF13837A), Color(0xFF3FCBB9)),
    Accent("Lila", Color(0xFF7A4FD0), Color(0xFFAA8CFF)),
    Accent("Rosa", Color(0xFFC63D7A), Color(0xFFFF7DB2)),
    Accent("Röd", Color(0xFFC8363D), Color(0xFFFF6B6E)),
    Accent("Guld", Color(0xFF9C700E), Color(0xFFE6B84A)),
    Accent("Orange", Color(0xFFE3502A), Color(0xFFF0643A)),
)

/** The look the user picked: accent colour and light / dark / follow the phone. Saved on the phone. */
object ThemePrefs {
    const val SYSTEM = 0
    const val LIGHT = 1
    const val DARK = 2

    var accent by mutableIntStateOf(0)
        private set
    var mode by mutableIntStateOf(SYSTEM)
        private set
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.getSharedPreferences("skivbacken", Context.MODE_PRIVATE)
        prefs = p
        accent = p.getInt("accent", 0).coerceIn(0, Accents.size - 1)
        mode = p.getInt("themeMode", SYSTEM).coerceIn(SYSTEM, DARK)
    }

    fun pickAccent(i: Int) { accent = i; prefs?.edit()?.putInt("accent", i)?.apply() }
    fun pickMode(m: Int) { mode = m; prefs?.edit()?.putInt("themeMode", m)?.apply() }
}

@Composable
fun SkivTheme(content: @Composable () -> Unit) {
    val dark = when (ThemePrefs.mode) {
        ThemePrefs.LIGHT -> false
        ThemePrefs.DARK -> true
        else -> isSystemInDarkTheme()
    }
    val accent = Accents[ThemePrefs.accent]
    val c = (if (dark) DarkSkiv else LightSkiv).copy(sticker = if (dark) accent.dark else accent.light)
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    val scheme = if (dark) {
        darkColorScheme(primary = c.sticker, onPrimary = c.stickerInk, background = c.wall, onBackground = c.ink, surface = c.panel, onSurface = c.ink)
    } else {
        lightColorScheme(primary = c.sticker, onPrimary = c.stickerInk, background = c.wall, onBackground = c.ink, surface = c.panel, onSurface = c.ink)
    }
    CompositionLocalProvider(LocalSkiv provides c) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
