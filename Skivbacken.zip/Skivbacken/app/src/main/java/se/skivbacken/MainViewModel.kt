package se.skivbacken

import android.app.Application
import android.content.ComponentName
import android.content.ContentUris
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface Screen {
    data object Library : Screen
    data class AlbumView(val key: String) : Screen
    data object Playing : Screen
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    var albums by mutableStateOf<List<Album>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var hasPermission by mutableStateOf(false)
    var screen by mutableStateOf<Screen>(Screen.Library)
    var cratePos by mutableFloatStateOf(0f)

    var isPlaying by mutableStateOf(false); private set
    var currentId by mutableStateOf<Long?>(null); private set
    var positionMs by mutableLongStateOf(0L); private set
    var durationMs by mutableLongStateOf(0L); private set
    var shuffle by mutableStateOf(false); private set
    var repeatMode by mutableStateOf(Player.REPEAT_MODE_OFF); private set

    private var controller: MediaController? = null
    private var connecting = false
    private var index: Map<Long, Pair<Album, Int>> = emptyMap()

    val currentAlbum: Album? get() = currentId?.let { index[it]?.first }
    val currentTrackIndex: Int get() = currentId?.let { index[it]?.second } ?: -1
    val currentTrack: Track? get() = currentAlbum?.tracks?.getOrNull(currentTrackIndex)

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync()
    }

    fun connect() {
        if (controller != null || connecting) return
        connecting = true
        val ctx = getApplication<Application>()
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            connecting = false
            controller = runCatching { future.get() }.getOrNull()
            controller?.addListener(listener)
            sync()
        }, ContextCompat.getMainExecutor(ctx))
        viewModelScope.launch {
            while (true) {
                controller?.let {
                    positionMs = it.currentPosition.coerceAtLeast(0)
                    if (it.duration > 0) durationMs = it.duration
                }
                delay(400)
            }
        }
    }

    private fun sync() {
        val c = controller ?: return
        isPlaying = c.isPlaying
        shuffle = c.shuffleModeEnabled
        repeatMode = c.repeatMode
        currentId = c.currentMediaItem?.mediaId?.toLongOrNull()
        durationMs = if (c.duration > 0) c.duration else currentTrack?.durationMs ?: 0L
    }

    fun load() {
        viewModelScope.launch {
            loading = true
            val list = withContext(Dispatchers.IO) {
                runCatching { LibraryRepo.load(getApplication<Application>()) }.getOrDefault(emptyList())
            }
            index = buildMap { list.forEach { a -> a.tracks.forEachIndexed { i, t -> put(t.id, a to i) } } }
            albums = list
            cratePos = cratePos.coerceIn(0f, (list.size - 1).coerceAtLeast(0).toFloat())
            loading = false
            sync()
        }
    }

    fun play(album: Album, i: Int) {
        val c = controller ?: return
        val sameQueue = c.mediaItemCount == album.tracks.size && c.mediaItemCount > 0 &&
            c.getMediaItemAt(0).mediaId == album.tracks[0].id.toString()
        if (sameQueue) {
            c.seekTo(i, 0L)
        } else {
            val art = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), album.albumId)
            val items = album.tracks.map { t ->
                MediaItem.Builder()
                    .setMediaId(t.id.toString())
                    .setUri(t.uri)
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(t.title)
                            .setArtist(t.artist)
                            .setAlbumTitle(album.title)
                            .setAlbumArtist(album.artist)
                            .setTrackNumber(t.no)
                            .setArtworkUri(art)
                            .build()
                    )
                    .build()
            }
            c.setMediaItems(items, i, 0L)
            c.prepare()
        }
        c.play()
        screen = Screen.Playing
    }

    fun toggle() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else {
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(0, 0L)
            c.play()
        }
    }

    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }
    fun next() { controller?.seekToNext() }
    fun prev() { controller?.seekToPrevious() }
    fun seek(ms: Long) { controller?.seekTo(ms); positionMs = ms }
    fun jumpTo(i: Int) { controller?.let { it.seekTo(i, 0L); it.play() } }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        controller = null
    }
}
