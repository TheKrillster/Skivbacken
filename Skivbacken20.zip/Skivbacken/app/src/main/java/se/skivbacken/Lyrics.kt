package se.skivbacken

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Song lyrics from LRCLIB (lrclib.net): free, no account, often time-synced. Cached per track. */
object Lyrics {
    data class Line(val timeMs: Long, val text: String)

    sealed interface State {
        data object Loading : State
        data object NotFound : State
        data object Offline : State
        data object Instrumental : State
        data class Found(val synced: List<Line>, val plain: String) : State
    }

    private const val UA = "Skivbacken/1.0 ( personal music player )"

    private fun file(ctx: Context, track: Track) = File(File(ctx.filesDir, "lyrics").apply { mkdirs() }, "${track.id}.json")

    suspend fun get(ctx: Context, album: Album, track: Track): State = withContext(Dispatchers.IO) {
        val f = file(ctx, track)
        if (f.exists()) return@withContext parse(f.readText())
        try {
            fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
            val dur = track.durationMs / 1000
            var json = httpGet(
                "https://lrclib.net/api/get?artist_name=${enc(track.artist)}&track_name=${enc(track.title)}" +
                    "&album_name=${enc(album.title)}" + (if (dur > 0) "&duration=$dur" else "")
            )
            if (json == null) {
                val list = httpGet("https://lrclib.net/api/search?artist_name=${enc(track.artist)}&track_name=${enc(track.title)}")
                json = list?.let { JSONArray(it).optJSONObject(0)?.toString() } ?: "{}"
            }
            f.writeText(json)
            parse(json)
        } catch (e: Exception) {
            State.Offline
        }
    }

    private fun parse(json: String): State {
        val o = runCatching { JSONObject(json) }.getOrNull() ?: return State.NotFound
        if (o.optBoolean("instrumental")) return State.Instrumental
        val synced = parseLrc(o.optString("syncedLyrics").takeIf { it != "null" } ?: "")
        val plain = o.optString("plainLyrics").takeIf { it != "null" } ?: ""
        return if (synced.isEmpty() && plain.isBlank()) State.NotFound else State.Found(synced, plain)
    }

    private val tag = Regex("""\[(\d+):(\d+(?:\.\d+)?)]""")

    /** "[01:23.45] text" lines; a line may carry several time tags. */
    private fun parseLrc(lrc: String): List<Line> =
        lrc.lines().flatMap { raw ->
            val stamps = tag.findAll(raw).toList()
            if (stamps.isEmpty()) return@flatMap emptyList()
            val text = raw.substring(stamps.last().range.last + 1).trim()
            stamps.map { m ->
                val ms = m.groupValues[1].toLong() * 60_000 + (m.groupValues[2].toDouble() * 1000).toLong()
                Line(ms, text)
            }
        }.sortedBy { it.timeMs }

    private fun httpGet(url: String): String? {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 15_000
            setRequestProperty("User-Agent", UA)
        }
        return try {
            when (c.responseCode) {
                200 -> c.inputStream.bufferedReader().use { it.readText() }
                404 -> null
                else -> throw java.io.IOException("HTTP ${c.responseCode}")
            }
        } finally {
            c.disconnect()
        }
    }
}
