package se.skivbacken.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

enum class Ic { Play, Pause, Next, Prev, Down, Refresh, Shuffle, Repeat, RepeatOne, Folder, Flow, Crate, Close, Settings }

/** Hand-drawn icons, so the app needs no icon library. */
@Composable
fun Glyph(ic: Ic, tint: Color, modifier: Modifier = Modifier.size(24.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = w * 0.09f
        val stroke = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (ic) {
            Ic.Play -> drawPath(Path().apply {
                moveTo(w * 0.30f, h * 0.18f); lineTo(w * 0.84f, h * 0.5f); lineTo(w * 0.30f, h * 0.82f); close()
            }, tint)
            Ic.Pause -> {
                drawRoundRect(tint, Offset(w * 0.25f, h * 0.18f), Size(w * 0.17f, h * 0.64f), CornerRadius(w * 0.03f))
                drawRoundRect(tint, Offset(w * 0.58f, h * 0.18f), Size(w * 0.17f, h * 0.64f), CornerRadius(w * 0.03f))
            }
            Ic.Next -> {
                drawPath(Path().apply { moveTo(w * 0.18f, h * 0.2f); lineTo(w * 0.66f, h * 0.5f); lineTo(w * 0.18f, h * 0.8f); close() }, tint)
                drawRoundRect(tint, Offset(w * 0.68f, h * 0.2f), Size(w * 0.12f, h * 0.6f), CornerRadius(w * 0.03f))
            }
            Ic.Prev -> {
                drawPath(Path().apply { moveTo(w * 0.82f, h * 0.2f); lineTo(w * 0.34f, h * 0.5f); lineTo(w * 0.82f, h * 0.8f); close() }, tint)
                drawRoundRect(tint, Offset(w * 0.20f, h * 0.2f), Size(w * 0.12f, h * 0.6f), CornerRadius(w * 0.03f))
            }
            Ic.Down -> drawPath(Path().apply {
                moveTo(w * 0.22f, h * 0.38f); lineTo(w * 0.5f, h * 0.64f); lineTo(w * 0.78f, h * 0.38f)
            }, tint, style = stroke)
            Ic.Refresh -> {
                drawArc(tint, -40f, 300f, false, Offset(w * 0.22f, h * 0.22f), Size(w * 0.56f, h * 0.56f), style = stroke)
                drawPath(Path().apply {
                    moveTo(w * 0.60f, h * 0.10f); lineTo(w * 0.80f, h * 0.30f); lineTo(w * 0.54f, h * 0.36f); close()
                }, tint)
            }
            Ic.Folder -> drawPath(Path().apply {
                moveTo(w * 0.12f, h * 0.24f); lineTo(w * 0.40f, h * 0.24f); lineTo(w * 0.48f, h * 0.33f)
                lineTo(w * 0.88f, h * 0.33f); lineTo(w * 0.88f, h * 0.78f); lineTo(w * 0.12f, h * 0.78f); close()
            }, tint, style = stroke)
            Ic.Settings -> {
                val ctr = Offset(w / 2f, h / 2f)
                for (k in 0 until 8) {
                    val a = Math.toRadians(k * 45.0)
                    val dx = kotlin.math.cos(a).toFloat()
                    val dy = kotlin.math.sin(a).toFloat()
                    drawLine(tint, Offset(ctr.x + dx * w * 0.24f, ctr.y + dy * h * 0.24f), Offset(ctr.x + dx * w * 0.38f, ctr.y + dy * h * 0.38f), sw * 1.3f, StrokeCap.Round)
                }
                drawCircle(tint, w * 0.24f, ctr, style = stroke)
                drawCircle(tint, w * 0.09f, ctr)
            }
            Ic.Close -> {
                drawLine(tint, Offset(w * 0.28f, h * 0.28f), Offset(w * 0.72f, h * 0.72f), sw, StrokeCap.Round)
                drawLine(tint, Offset(w * 0.72f, h * 0.28f), Offset(w * 0.28f, h * 0.72f), sw, StrokeCap.Round)
            }
            Ic.Flow -> {
                drawPath(Path().apply { moveTo(w * 0.08f, h * 0.30f); lineTo(w * 0.28f, h * 0.24f); lineTo(w * 0.28f, h * 0.76f); lineTo(w * 0.08f, h * 0.70f); close() }, tint)
                drawPath(Path().apply { moveTo(w * 0.92f, h * 0.30f); lineTo(w * 0.72f, h * 0.24f); lineTo(w * 0.72f, h * 0.76f); lineTo(w * 0.92f, h * 0.70f); close() }, tint)
                drawRoundRect(tint, Offset(w * 0.33f, h * 0.18f), Size(w * 0.34f, h * 0.64f), CornerRadius(w * 0.04f))
            }
            Ic.Crate -> {
                for (k in 0..2) {
                    val x = w * (0.26f + k * 0.17f)
                    drawLine(tint, Offset(x, h * 0.18f), Offset(x + w * 0.08f, h * 0.58f), sw, StrokeCap.Round)
                }
                drawRoundRect(tint, Offset(w * 0.14f, h * 0.52f), Size(w * 0.72f, h * 0.30f), CornerRadius(w * 0.04f))
            }
            Ic.Shuffle -> {
                drawPath(Path().apply {
                    moveTo(w * 0.14f, h * 0.30f); cubicTo(w * 0.45f, h * 0.30f, w * 0.50f, h * 0.70f, w * 0.80f, h * 0.70f)
                }, tint, style = stroke)
                drawPath(Path().apply {
                    moveTo(w * 0.14f, h * 0.70f); cubicTo(w * 0.45f, h * 0.70f, w * 0.50f, h * 0.30f, w * 0.80f, h * 0.30f)
                }, tint, style = stroke)
                arrowHead(tint, w * 0.86f, h * 0.30f, w)
                arrowHead(tint, w * 0.86f, h * 0.70f, w)
            }
            Ic.Repeat, Ic.RepeatOne -> {
                drawRoundRect(tint, Offset(w * 0.16f, h * 0.28f), Size(w * 0.68f, h * 0.44f), CornerRadius(w * 0.14f), style = stroke)
                arrowHead(tint, w * 0.62f, h * 0.28f, w)
                if (ic == Ic.RepeatOne) {
                    drawLine(tint, Offset(w * 0.5f, h * 0.40f), Offset(w * 0.5f, h * 0.60f), sw * 0.8f, StrokeCap.Round)
                }
            }
        }
    }
}

private fun DrawScope.arrowHead(tint: Color, x: Float, y: Float, w: Float) {
    drawPath(Path().apply {
        moveTo(x, y); lineTo(x - w * 0.14f, y - w * 0.11f); lineTo(x - w * 0.14f, y + w * 0.11f); close()
    }, tint)
}
