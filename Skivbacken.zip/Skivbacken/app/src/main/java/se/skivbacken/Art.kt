package se.skivbacken

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaExtractor
import android.media.MediaFormat
import android.util.LruCache
import android.util.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Small in-memory cache of decoded covers, at most about 600 px each. */
object ArtCache {
    private const val PX = 600
    private val cache = LruCache<String, ImageBitmap>(48)
    private val missing: MutableSet<Long> = ConcurrentHashMap.newKeySet()

    fun peekTrack(trackId: Long): ImageBitmap? = cache.get("t:$trackId")
    fun peekFile(file: File): ImageBitmap? = cache.get("f:${file.path}")

    /** Embedded cover from the audio file, via MediaStore's thumbnailer. */
    suspend fun loadEmbedded(context: Context, track: Track): ImageBitmap? {
        peekTrack(track.id)?.let { return it }
        if (track.id in missing) return null
        return withContext(Dispatchers.IO) {
            try {
                val bmp = context.contentResolver.loadThumbnail(track.uri, Size(PX, PX), null)
                bmp.asImageBitmap().also { cache.put("t:${track.id}", it) }
            } catch (e: Exception) {
                missing.add(track.id)
                null
            }
        }
    }

    /** A cover downloaded earlier and stored in the app's own folder. */
    suspend fun loadFile(file: File): ImageBitmap? {
        peekFile(file)?.let { return it }
        if (!file.exists()) return null
        return withContext(Dispatchers.IO) {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.path, bounds)
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= PX && bounds.outHeight / (sample * 2) >= PX) sample *= 2
                val bmp = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
                    ?: return@withContext null
                bmp.asImageBitmap().also { cache.put("f:${file.path}", it) }
            } catch (e: Exception) {
                null
            }
        }
    }
}

data class Spec(val bits: Int, val rate: Int) {
    val known: Boolean get() = rate > 0
    val hiRes: Boolean get() = bits > 16 || rate > 48000
    private val khz: String
        get() = if (rate % 1000 == 0) "${rate / 1000}" else String.format(Locale.ROOT, "%.1f", rate / 1000.0)
    /** "24/96" for the price sticker. */
    val short: String get() = if (bits > 0) "$bits/$khz" else "$khz kHz"
    /** "24-bit / 96 kHz" for captions. */
    val long: String get() = if (bits > 0) "$bits-bit / $khz kHz" else "$khz kHz"
}

/** Reads bit depth and sample rate from the file header. */
object SpecCache {
    private val map = ConcurrentHashMap<Long, Spec>()
    fun peek(id: Long): Spec? = map[id]

    suspend fun load(context: Context, track: Track): Spec {
        map[track.id]?.let { return it }
        return withContext(Dispatchers.IO) {
            var spec = Spec(0, 0)
            val ex = MediaExtractor()
            try {
                ex.setDataSource(context, track.uri, null)
                if (ex.trackCount > 0) {
                    val f = ex.getTrackFormat(0)
                    val rate = if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) f.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 0
                    val bits = when {
                        f.containsKey("bits-per-sample") -> f.getInteger("bits-per-sample")
                        f.containsKey(MediaFormat.KEY_PCM_ENCODING) -> when (f.getInteger(MediaFormat.KEY_PCM_ENCODING)) {
                            3 -> 8       // ENCODING_PCM_8BIT
                            21 -> 24     // ENCODING_PCM_24BIT_PACKED
                            4, 22 -> 32  // ENCODING_PCM_FLOAT, ENCODING_PCM_32BIT
                            else -> 16
                        }
                        else -> 0
                    }
                    spec = Spec(bits, rate)
                }
            } catch (_: Exception) {
            } finally {
                ex.release()
            }
            map[track.id] = spec
            spec
        }
    }
}
