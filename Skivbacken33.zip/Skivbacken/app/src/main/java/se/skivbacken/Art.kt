package se.skivbacken

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.graphics.BitmapFactory
import android.media.MediaExtractor
import android.media.MediaFormat
import android.util.LruCache
import android.util.Size
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Bumped when a cover is changed by hand, so every view showing it reloads. */
object ArtVersion {
    var value by mutableIntStateOf(0)
        private set
    fun bump() { value++ }
}

/** Thumbnails from the web for the cover search. */
object RemoteImages {
    private val cache = LruCache<String, ImageBitmap>(60)
    suspend fun load(url: String): ImageBitmap? {
        cache.get(url)?.let { return it }
        return withContext(Dispatchers.IO) {
            runCatching {
                val bytes = OnlineArt.fetchBytes(url) ?: return@runCatching null
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= 300) sample *= 2
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                    ?.asImageBitmap()?.also { cache.put(url, it) }
            }.getOrNull()
        }
    }
}

/** Small in-memory cache of decoded covers, at most about 600 px each. */
object ArtCache {
    private const val PX = 600
    private val cache = LruCache<String, ImageBitmap>(48)
    private val missing: MutableSet<Long> = ConcurrentHashMap.newKeySet()

    fun peekTrack(trackId: Long): ImageBitmap? = cache.get("t:$trackId")
    fun peekFile(file: File): ImageBitmap? = cache.get("f:${file.path}")
    fun forget(file: File) { cache.remove("f:${file.path}") }

    /** Embedded cover from the audio file, via MediaStore's thumbnailer. */
    suspend fun loadEmbedded(context: Context, track: Track): ImageBitmap? {
        peekTrack(track.id)?.let { return it }
        if (track.id in missing) return null
        return withContext(Dispatchers.IO) {
            try {
                val bmp = context.contentResolver.loadThumbnail(track.uri, Size(PX, PX), null)
                bmp.asImageBitmap().also { cache.put("t:${track.id}", it) }
            } catch (e: Exception) {
                missing.add(track.id)
                null
            }
        }
    }

    /** A cover downloaded earlier and stored in the app's own folder. */
    suspend fun loadFile(file: File): ImageBitmap? {
        peekFile(file)?.let { return it }
        if (!file.exists()) return null
        return withContext(Dispatchers.IO) {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.path, bounds)
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= PX && bounds.outHeight / (sample * 2) >= PX) sample *= 2
                val bmp = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
                    ?: return@withContext null
                bmp.asImageBitmap().also { cache.put("f:${file.path}", it) }
            } catch (e: Exception) {
                null
            }
        }
    }
}

data class Spec(val bits: Int, val rate: Int, val codec: String = "") {
    val known: Boolean get() = rate > 0
    val lossless: Boolean get() = codec == "FLAC" || codec == "ALAC" || codec == "WAV"
    val hiRes: Boolean get() = lossless && (bits > 16 || rate > 48000)
    /** "44,1 kHz", the Swedish way. */
    val khzLabel: String get() = (if (rate % 1000 == 0) "${rate / 1000}" else String.format(Locale.ROOT, "%.1f", rate / 1000.0)).replace('.', ',') + " kHz"
    private val khz: String
        get() = if (rate % 1000 == 0) "${rate / 1000}" else String.format(Locale.ROOT, "%.1f", rate / 1000.0)
    /** "24/96" for the price sticker. */
    val short: String get() = if (bits > 0) "$bits/$khz" else "$khz kHz"
    /** "24-bit / 96 kHz" for captions. */
    val long: String get() = if (bits > 0) "$bits-bit / $khz kHz" else "$khz kHz"
}

/** Reads bit depth and sample rate from the file header. */
object SpecCache {
    private val map = ConcurrentHashMap<Long, Spec>()
    fun peek(id: Long): Spec? = map[id]

    suspend fun load(context: Context, track: Track): Spec {
        map[track.id]?.let { return it }
        return withContext(Dispatchers.IO) {
            var spec = Spec(0, 0)
            val ex = MediaExtractor()
            try {
                ex.setDataSource(context, track.uri, null)
                if (ex.trackCount > 0) {
                    val f = ex.getTrackFormat(0)
                    val rate = if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) f.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 0
                    val bits = when {
                        f.containsKey("bits-per-sample") -> f.getInteger("bits-per-sample")
                        f.containsKey(MediaFormat.KEY_PCM_ENCODING) -> when (f.getInteger(MediaFormat.KEY_PCM_ENCODING)) {
                            3 -> 8       // ENCODING_PCM_8BIT
                            21 -> 24     // ENCODING_PCM_24BIT_PACKED
                            4, 22 -> 32  // ENCODING_PCM_FLOAT, ENCODING_PCM_32BIT
                            else -> 16
                        }
                        else -> 0
                    }
                    val mime = if (f.containsKey(MediaFormat.KEY_MIME)) f.getString(MediaFormat.KEY_MIME) ?: "" else ""
                    val codec = when {
                        mime.contains("flac") -> "FLAC"
                        mime.contains("alac") -> "ALAC"
                        mime.contains("mp4a") || mime.contains("aac") -> "AAC"
                        mime.contains("mpeg") -> "MP3"
                        mime.contains("opus") -> "Opus"
                        mime.contains("vorbis") -> "Vorbis"
                        mime.contains("raw") || mime.contains("wav") -> "WAV"
                        else -> track.format
                    }
                    spec = Spec(if (codec == "FLAC" || codec == "ALAC" || codec == "WAV") bits else 0, rate, codec)
                }
            } catch (_: Exception) {
            } finally {
                ex.release()
            }
            map[track.id] = spec
            spec
        }
    }
}

/**
 * Cover as a plain image file, for the lock screen, the notification and Android Auto.
 * Same order as in the app: picked by hand, inside the music file, then downloaded.
 * Blocking; call off the main thread.
 */
object ArtFiles {
    /**
     * Address other apps (Android Auto, lock screen) can fetch the album's cover from.
     * The version part changes when a cover is picked by hand, so they don't keep an old picture.
     */
    fun uriFor(ctx: Context, album: Album, @Suppress("UNUSED_PARAMETER") extract: Boolean = true): Uri? {
        val custom = OnlineArt.customFile(ctx, album)
        val v = if (custom.exists()) custom.lastModified() else 0L
        return Uri.parse("content://se.skivbacken.art/t/${album.tracks.first().id}/${OnlineArt.base(album)}?v=$v")
    }
}
