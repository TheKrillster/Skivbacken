package se.skivbacken

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import android.view.KeyEvent
import android.widget.RemoteViews
import androidx.compose.ui.graphics.toArgb
import androidx.media3.common.Player
import se.skivbacken.ui.Accents
import java.util.concurrent.Executors

class NowPlayingWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.refresh(context)
}

class CoverWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.refresh(context)
}

class SpinWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.refresh(context)
}

class BarWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.refresh(context)
}

/**
 * Home-screen widgets. The player service saves what is playing; the widgets draw from that,
 * so they show the last record even when the app isn't running. The buttons send media-button
 * presses to the player service, which picks up where you left off if it had stopped.
 */
object Widgets {
    private const val PREFS = "skivbacken"
    private val worker = Executors.newSingleThreadExecutor()
    private var lastArtKey: String? = null
    private var lastArt: Bitmap? = null
    private var lastArtSmall: Bitmap? = null

    /** Called by the player service whenever anything about playback changes. */
    fun fromPlayer(ctx: Context, player: Player) {
        val m = player.currentMediaItem?.mediaMetadata
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val changed = p.edit()
        if (m != null) {
            changed.putString("w_title", m.title?.toString())
                .putString("w_artist", m.artist?.toString())
                .putString("w_album", m.albumTitle?.toString())
                .putString("w_art", m.artworkUri?.toString())
        }
        changed.putBoolean("w_playing", player.isPlaying).apply()
        refresh(ctx.applicationContext)
    }

    fun stopped(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("w_playing", false).apply()
        refresh(ctx.applicationContext)
    }

    fun refresh(ctx: Context) {
        val app = ctx.applicationContext
        worker.execute { runCatching { draw(app) } }
    }

    private fun draw(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val now = mgr.getAppWidgetIds(ComponentName(ctx, NowPlayingWidget::class.java))
        val cover = mgr.getAppWidgetIds(ComponentName(ctx, CoverWidget::class.java))
        val bar = mgr.getAppWidgetIds(ComponentName(ctx, BarWidget::class.java))
        val spin = mgr.getAppWidgetIds(ComponentName(ctx, SpinWidget::class.java))
        if (now.isEmpty() && cover.isEmpty() && bar.isEmpty() && spin.isEmpty()) return

        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val title = p.getString("w_title", null)
        val artist = p.getString("w_artist", null)
        val album = p.getString("w_album", null)
        val playing = p.getBoolean("w_playing", false)
        val accentIdx = p.getInt("accent", 0).coerceIn(0, Accents.size - 1)
        val accent = Accents[accentIdx].dark.toArgb()
        val (big, small) = art(ctx, p.getString("w_art", null))

        fun common(v: RemoteViews, coverBmp: Bitmap?) {
            v.setOnClickPendingIntent(R.id.w_root, openApp(ctx))
            if (coverBmp != null) v.setImageViewBitmap(R.id.w_cover, coverBmp)
            else v.setImageViewResource(R.id.w_cover, R.drawable.ic_w_disc)
            v.setInt(R.id.w_play_bg, "setColorFilter", accent)
            v.setImageViewResource(R.id.w_play, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
            v.setOnClickPendingIntent(R.id.w_play_box, mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
            v.setOnClickPendingIntent(R.id.w_cover, openApp(ctx))
        }

        if (now.isNotEmpty()) {
            val v = RemoteViews(ctx.packageName, R.layout.widget_now)
            common(v, small)
            v.setTextViewText(R.id.w_title, title ?: "Ingen musik spelas")
            v.setTextViewText(
                R.id.w_artist,
                if (artist == null) "Tryck för att öppna Skivbacken" else listOfNotNull(artist, album).joinToString(" · "),
            )
            bars(v, BARS, playing, accent)
            v.setOnClickPendingIntent(R.id.w_prev, mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS))
            v.setOnClickPendingIntent(R.id.w_next, mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_NEXT))
            mgr.updateAppWidget(now, v)
        }
        if (cover.isNotEmpty()) {
            val v = RemoteViews(ctx.packageName, R.layout.widget_cover)
            common(v, big)
            v.setTextViewText(R.id.w_title, title ?: "Skivbacken")
            bars(v, BARS, playing, accent)
            mgr.updateAppWidget(cover, v)
        }
        if (spin.isNotEmpty()) {
            val v = RemoteViews(ctx.packageName, R.layout.widget_spin)
            v.setOnClickPendingIntent(R.id.w_root, openApp(ctx))
            v.setInt(R.id.w_play_bg, "setColorFilter", accent)
            v.setImageViewResource(R.id.w_play, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
            v.setOnClickPendingIntent(R.id.w_play_box, mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
            val frames = SpinFrames.prepare(ctx, p.getString("w_art", null), big)
            SPIN_IDS.forEachIndexed { k, id -> v.setImageViewUri(id, frames[k]) }
            v.setImageViewUri(R.id.w_spin_still, frames[0])
            v.setViewVisibility(R.id.w_spin_anim, if (playing) android.view.View.VISIBLE else android.view.View.GONE)
            v.setViewVisibility(R.id.w_spin_still, if (playing) android.view.View.GONE else android.view.View.VISIBLE)
            mgr.updateAppWidget(spin, v)
        }
        if (bar.isNotEmpty()) {
            val v = RemoteViews(ctx.packageName, R.layout.widget_bar)
            common(v, small)
            v.setTextViewText(R.id.w_title, title ?: "Ingen musik spelas")
            v.setTextViewText(R.id.w_artist, artist ?: "Skivbacken")
            v.setOnClickPendingIntent(R.id.w_next, mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_NEXT))
            bars(v, EQ, playing, accent)
            mgr.updateAppWidget(bar, v)
        }
    }

    private val SPIN_IDS = intArrayOf(
        R.id.w_spin_f0, R.id.w_spin_f1, R.id.w_spin_f2, R.id.w_spin_f3, R.id.w_spin_f4, R.id.w_spin_f5,
        R.id.w_spin_f6, R.id.w_spin_f7, R.id.w_spin_f8, R.id.w_spin_f9, R.id.w_spin_f10, R.id.w_spin_f11,
        R.id.w_spin_f12, R.id.w_spin_f13, R.id.w_spin_f14, R.id.w_spin_f15,
    )

    private class Anim(val anim: Int, val still: Int, val frames: IntArray)

    private val BARS = Anim(
        R.id.w_bars_anim, R.id.w_bars_still,
        intArrayOf(
            R.id.w_bars_f0, R.id.w_bars_f1, R.id.w_bars_f2, R.id.w_bars_f3, R.id.w_bars_f4,
            R.id.w_bars_f5, R.id.w_bars_f6, R.id.w_bars_f7, R.id.w_bars_f8, R.id.w_bars_f9,
        ),
    )
    private val EQ = Anim(
        R.id.w_eq_anim, R.id.w_eq_still,
        intArrayOf(
            R.id.w_eq_f0, R.id.w_eq_f1, R.id.w_eq_f2, R.id.w_eq_f3, R.id.w_eq_f4,
            R.id.w_eq_f5, R.id.w_eq_f6, R.id.w_eq_f7, R.id.w_eq_f8, R.id.w_eq_f9,
        ),
    )

    /**
     * Dancing bars: a loop of frames the home screen flips through by itself while music plays
     * (the app doesn't redraw the widget for it), and a flat row when paused.
     */
    private fun bars(v: RemoteViews, a: Anim, playing: Boolean, accent: Int) {
        v.setViewVisibility(a.anim, if (playing) android.view.View.VISIBLE else android.view.View.GONE)
        v.setViewVisibility(a.still, if (playing) android.view.View.GONE else android.view.View.VISIBLE)
        a.frames.forEach { v.setInt(it, "setColorFilter", accent) }
        v.setInt(a.still, "setColorFilter", accent)
    }

    /** Cover in two sizes with rounded corners; kept until the record changes. */
    private fun art(ctx: Context, uri: String?): Pair<Bitmap?, Bitmap?> {
        if (uri == null) return null to null
        if (uri == lastArtKey && lastArt != null) return lastArt to lastArtSmall
        val bmp = runCatching {
            val u = Uri.parse(uri)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 400) sample *= 2
            ctx.contentResolver.openInputStream(u)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            }
        }.getOrNull() ?: return null to null
        val big = rounded(square(bmp, 400), 400 * 0.09f)
        val small = rounded(square(bmp, 200), 200 * 0.08f)
        lastArtKey = uri
        lastArt = big
        lastArtSmall = small
        return big to small
    }

    private fun square(src: Bitmap, size: Int): Bitmap {
        val m = minOf(src.width, src.height)
        val crop = Bitmap.createBitmap(src, (src.width - m) / 2, (src.height - m) / 2, m, m)
        return Bitmap.createScaledBitmap(crop, size, size, true)
    }

    private fun rounded(src: Bitmap, radius: Float): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
        Canvas(out).drawRoundRect(RectF(0f, 0f, src.width.toFloat(), src.height.toFloat()), radius, radius, paint)
        return out
    }

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    /** A press on a media button, sent straight to the player service. */
    private fun mediaKey(ctx: Context, keyCode: Int): PendingIntent {
        val intent = Intent(Intent.ACTION_MEDIA_BUTTON)
            .setComponent(ComponentName(ctx, PlaybackService::class.java))
            .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        return PendingIntent.getForegroundService(ctx, keyCode, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }
}
