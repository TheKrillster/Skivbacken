package se.skivbacken

import android.app.Application
import android.content.Context
import android.content.ComponentName
import android.content.ContentUris
import android.net.Uri
import android.widget.Toast
import androidx.media3.common.PlaybackException
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class QueueItem(val index: Int, val mediaId: String, val title: String, val artist: String)

sealed interface Screen {
    data object Library : Screen
    data class AlbumView(val key: String) : Screen
    data object Playing : Screen
    data object Folders : Screen
    data class CoverSearch(val key: String, val back: Screen) : Screen
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    var albums by mutableStateOf<List<Album>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var hasPermission by mutableStateOf(false)
    var screen by mutableStateOf<Screen>(Screen.Library)
    var cratePos by mutableFloatStateOf(0f)

    var isPlaying by mutableStateOf(false); private set
    var currentId by mutableStateOf<Long?>(null); private set
    var positionMs by mutableLongStateOf(0L); private set
    var durationMs by mutableLongStateOf(0L); private set
    var shuffle by mutableStateOf(false); private set
    var repeatMode by mutableStateOf(Player.REPEAT_MODE_OFF); private set
    var queue by mutableStateOf<List<QueueItem>>(emptyList()); private set
    var queueIndex by mutableIntStateOf(-1); private set

    private val prefs = app.getSharedPreferences("skivbacken", Context.MODE_PRIVATE)
    private var allAlbums: List<Album> = emptyList()
    var folders by mutableStateOf<List<Folder>>(emptyList()); private set
    /** Folder prefixes to read music from. Empty means everything on the phone. */
    var chosenFolders by mutableStateOf<Set<String>>(prefs.getStringSet("folders", null)?.toSet() ?: emptySet()); private set

    /** Coverflow (true) or the flip-through crate (false). */
    var gridView by mutableStateOf(prefs.getBoolean("gridView", true)); private set
    fun toggleView() {
        gridView = !gridView
        prefs.edit().putBoolean("gridView", gridView).apply()
    }

    /** Albums the user has hidden, by album key. */
    var hiddenAlbums by mutableStateOf<Set<String>>(prefs.getStringSet("hidden", null)?.toSet() ?: emptySet()); private set
    val hiddenList: List<Album> get() = filterFolders(allAlbums, chosenFolders).filter { it.key in hiddenAlbums }

    fun hide(album: Album) {
        hiddenAlbums = hiddenAlbums + album.key
        prefs.edit().putStringSet("hidden", hiddenAlbums).apply()
        applyFilter()
    }

    fun unhide(key: String) {
        hiddenAlbums = hiddenAlbums - key
        prefs.edit().putStringSet("hidden", hiddenAlbums).apply()
        applyFilter()
    }

    private var controller: MediaController? = null
    private var connecting = false
    private var index: Map<Long, Pair<Album, Int>> = emptyMap()

    val currentAlbum: Album? get() = currentId?.let { index[it]?.first }
    val currentTrackIndex: Int get() = currentId?.let { index[it]?.second } ?: -1
    val currentTrack: Track? get() = currentAlbum?.tracks?.getOrNull(currentTrackIndex)

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync()

        override fun onPlayerError(error: PlaybackException) {
            val title = currentTrack?.title?.let { "\"$it\": " } ?: ""
            val what = when (error.errorCode) {
                PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
                PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
                PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
                PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED ->
                    "telefonen kan inte avkoda ljudformatet" + (LastError.format?.let { " ($it)" } ?: "") + "."
                PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
                PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ->
                    "filen kunde inte läsas. Den kan vara trasig eller av en okänd sort."
                PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND,
                PlaybackException.ERROR_CODE_IO_NO_PERMISSION ->
                    "filen hittades inte eller får inte läsas."
                PlaybackException.ERROR_CODE_DRM_UNSPECIFIED,
                PlaybackException.ERROR_CODE_DRM_CONTENT_ERROR,
                PlaybackException.ERROR_CODE_DRM_SCHEME_UNSUPPORTED ->
                    "filen är kopieringsskyddad och kan inte spelas."
                else -> "kunde inte spelas (${error.errorCodeName})."
            }
            Toast.makeText(getApplication<Application>(), "Går inte att spela $title$what", Toast.LENGTH_LONG).show()
        }
    }

    fun connect() {
        if (controller != null || connecting) return
        connecting = true
        val ctx = getApplication<Application>()
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            connecting = false
            controller = runCatching { future.get() }.getOrNull()
            controller?.addListener(listener)
            sync()
            pendingSearch?.let { pendingSearch = null; playFromSearch(it) }
        }, ContextCompat.getMainExecutor(ctx))
        viewModelScope.launch {
            while (true) {
                controller?.let {
                    positionMs = it.currentPosition.coerceAtLeast(0)
                    if (it.duration > 0) durationMs = it.duration
                }
                delay(400)
            }
        }
    }

    private fun sync() {
        val c = controller ?: return
        isPlaying = c.isPlaying
        shuffle = c.shuffleModeEnabled
        repeatMode = c.repeatMode
        queueIndex = c.currentMediaItemIndex
        queue = (0 until c.mediaItemCount).map { i ->
            val m = c.getMediaItemAt(i)
            QueueItem(i, m.mediaId, m.mediaMetadata.title?.toString() ?: "", m.mediaMetadata.artist?.toString() ?: "")
        }
        currentId = c.currentMediaItem?.mediaId?.toLongOrNull()
        durationMs = if (c.duration > 0) c.duration else currentTrack?.durationMs ?: 0L
    }

    /** Reads the whole library again (the ↻ button). */
    fun load() = loadLibrary(force = true)

    /**
     * On start: show the saved library at once, then ask Android whether any music has changed
     * since; only then read it again, in the background.
     */
    fun loadCached() = loadLibrary(force = false)

    private fun loadLibrary(force: Boolean) {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            loading = true
            if (!force && allAlbums.isEmpty()) {
                val cached = withContext(Dispatchers.IO) { LibraryCache.load(ctx) }
                if (!cached.isNullOrEmpty()) show(cached)
            }
            val stamp = withContext(Dispatchers.IO) { LibraryCache.stamp(ctx) }
            val unchanged = !force && allAlbums.isNotEmpty() && stamp.isNotEmpty() && stamp == LibraryCache.storedStamp(ctx)
            if (!unchanged) {
                val list = withContext(Dispatchers.IO) {
                    runCatching { LibraryRepo.load(ctx) }.getOrDefault(emptyList())
                }
                show(list)
                withContext(Dispatchers.IO) { runCatching { LibraryCache.save(ctx, list, stamp) } }
            }
            loading = false
        }
    }

    private fun show(list: List<Album>) {
        allAlbums = list
        folders = foldersOf(list)
        applyFilter()
    }

    fun setFolders(chosen: Set<String>) {
        chosenFolders = chosen
        prefs.edit().putStringSet("folders", chosen).apply()
        cratePos = 0f
        applyFilter()
    }

    private fun applyFilter() {
        val list = filterFolders(allAlbums, chosenFolders).filterNot { it.key in hiddenAlbums }
        index = buildMap { list.forEach { a -> a.tracks.forEachIndexed { i, t -> put(t.id, a to i) } } }
        albums = list
        cratePos = cratePos.coerceIn(0f, (list.size - 1).coerceAtLeast(0).toFloat())
        sync()
    }

    fun play(album: Album, i: Int) {
        val c = controller ?: return
        screen = Screen.Playing
        val sameQueue = c.mediaItemCount == album.tracks.size && c.mediaItemCount > 0 &&
            c.getMediaItemAt(0).mediaId == album.tracks[0].id.toString()
        if (sameQueue) {
            c.seekTo(i, 0L)
            c.play()
            return
        }
        viewModelScope.launch {
            val items = itemsFor(album, album.tracks)
            c.setMediaItems(items, i, 0L)
            c.prepare()
            c.play()
        }
    }

    /** Builds queue items; the cover goes along as an image file so the lock screen can show it. */
    private suspend fun itemsFor(album: Album, tracks: List<Track>): List<MediaItem> {
        val art = ArtFiles.uriFor(getApplication<Application>(), album) ?: artUri(album)
        return tracks.map { itemFor(album, it, art) }
    }

    private fun itemFor(album: Album, t: Track, art: Uri): MediaItem = MediaItem.Builder()
        .setMediaId(t.id.toString())
        .setUri(t.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(t.title)
                .setArtist(t.artist)
                .setAlbumTitle(album.title)
                .setAlbumArtist(album.artist)
                .setTrackNumber(t.no)
                .setArtworkUri(art)
                .build()
        )
        .build()

    /** Puts the track right after the one playing now. */
    fun playNext(album: Album, i: Int) {
        val c = controller ?: return
        viewModelScope.launch {
            val item = itemsFor(album, listOf(album.tracks[i])).first()
            if (c.mediaItemCount == 0) { c.setMediaItem(item); c.prepare(); c.play() }
            else c.addMediaItem(c.currentMediaItemIndex + 1, item)
        }
    }

    /** Puts tracks at the end of the queue. */
    fun addToQueue(album: Album, tracks: List<Track>) {
        val c = controller ?: return
        viewModelScope.launch {
            val items = itemsFor(album, tracks)
            if (c.mediaItemCount == 0) { c.setMediaItems(items); c.prepare(); c.play() }
            else c.addMediaItems(items)
        }
    }

    fun removeFromQueue(index: Int) { controller?.removeMediaItem(index) }
    fun jumpToQueue(index: Int) { controller?.let { it.seekTo(index, 0L); it.play() } }

    /** Plays a track from the album list; uses its place in the queue if it is already there. */
    fun jumpTo(album: Album, i: Int) {
        val id = album.tracks[i].id.toString()
        val idx = queue.indexOfFirst { it.mediaId == id }
        if (idx >= 0) jumpToQueue(idx) else play(album, i)
    }

    /** "Hey Google, spela … i Skivbacken": the player service works out what to play. */
    fun playFromSearch(query: String) {
        val c = controller
        if (c == null) {
            pendingSearch = query
            return
        }
        c.setMediaItem(
            MediaItem.Builder()
                .setMediaId("")
                .setRequestMetadata(MediaItem.RequestMetadata.Builder().setSearchQuery(query).build())
                .build(),
        )
        c.prepare()
        c.play()
        screen = Screen.Playing
    }

    private var pendingSearch: String? = null

    fun toggle() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else {
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(0, 0L)
            c.play()
        }
    }

    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }
    fun next() { controller?.seekToNext() }
    fun prev() { controller?.seekToPrevious() }
    fun seek(ms: Long) { controller?.seekTo(ms); positionMs = ms }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        controller = null
    }
}
