package se.skivbacken.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

/** Shop palette: sage walls, plywood crates, orange price stickers, a hi-fi deck for the player. */
@Immutable
data class SkivColors(
    val wall: Color, val wall2: Color, val ink: Color, val inkSoft: Color, val line: Color,
    val panel: Color, val chip: Color,
    val ply: Color, val plyDark: Color, val plyGrain: Color, val plyHole: Color,
    val sticker: Color, val stickerInk: Color,
    val vfdBg: Color, val vfdInk: Color,
    val deck: Color, val deckShine: Color,
)

val LightSkiv = SkivColors(
    wall = Color(0xFFDFE3D8), wall2 = Color(0xFFCFD6C6), ink = Color(0xFF1C211B), inkSoft = Color(0xFF5A6357),
    line = Color(0x241C211B), panel = Color(0xFFEBEEE6), chip = Color(0xFFD3D9CB),
    ply = Color(0xFFCFA673), plyDark = Color(0xFFA47A49), plyGrain = Color(0x29704620), plyHole = Color(0xFF5C3F22),
    sticker = Color(0xFFE3502A), stickerInk = Color(0xFFFFFAF2),
    vfdBg = Color(0xFF151C1E), vfdInk = Color(0xFF7FE0CF),
    deck = Color(0xFF2A302C), deckShine = Color(0xFF4A524C),
)

val DarkSkiv = SkivColors(
    wall = Color(0xFF1A1D18), wall2 = Color(0xFF141612), ink = Color(0xFFEBE8DE), inkSoft = Color(0xFF9BA293),
    line = Color(0x21EBE8DE), panel = Color(0xFF20241D), chip = Color(0xFF2B3027),
    ply = Color(0xFF7A5A39), plyDark = Color(0xFF553D25), plyGrain = Color(0x38000000), plyHole = Color(0xFF22170C),
    sticker = Color(0xFFF0643A), stickerInk = Color(0xFFFFFAF2),
    vfdBg = Color(0xFF0C1213), vfdInk = Color(0xFF7FE0CF),
    deck = Color(0xFF0E100D), deckShine = Color(0xFF2C312A),
)

val LocalSkiv = staticCompositionLocalOf { LightSkiv }
/** One typeface for all text in the app (the phone's own, Roboto on most phones; its digits keep equal widths). */
val AppFont: FontFamily = FontFamily.Default

@Composable
fun SkivTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val c = if (dark) DarkSkiv else LightSkiv
    val scheme = if (dark) {
        darkColorScheme(primary = c.sticker, onPrimary = c.stickerInk, background = c.wall, onBackground = c.ink, surface = c.panel, onSurface = c.ink)
    } else {
        lightColorScheme(primary = c.sticker, onPrimary = c.stickerInk, background = c.wall, onBackground = c.ink, surface = c.panel, onSurface = c.ink)
    }
    CompositionLocalProvider(LocalSkiv provides c) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
