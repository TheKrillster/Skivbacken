package se.skivbacken.ui

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import se.skivbacken.Album
import se.skivbacken.MainViewModel
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sign

/**
 * Vertical coverflow: swipe up and down; the record in the middle faces you and the ones
 * above and below tilt away. Tap the middle one to open it, one above or below to go there.
 */
@Composable
fun CoverFlow(vm: MainViewModel, onOpen: (Album) -> Unit, modifier: Modifier) {
    val c = LocalSkiv.current
    val albums = vm.albums
    val n = albums.size
    val scope = rememberCoroutineScope()
    var anim by remember { mutableStateOf<Job?>(null) }

    fun settle(target: Float) {
        anim?.cancel()
        val t = target.coerceIn(0f, (n - 1).coerceAtLeast(0).toFloat())
        anim = scope.launch {
            animate(vm.cratePos, t, animationSpec = spring(dampingRatio = 0.9f, stiffness = 220f)) { v, _ -> vm.cratePos = v }
        }
    }

    val pos = vm.cratePos
    val cur = pos.roundToInt().coerceIn(0, n - 1)

    Column(modifier.fillMaxWidth()) {
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val dim = minOf(maxWidth * 0.62f, maxHeight * 0.44f, 320.dp)
            val dimPx = with(LocalDensity.current) { dim.toPx() }
            val heightPx = with(LocalDensity.current) { maxHeight.toPx() }
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(n, dimPx) {
                        var start = 0f
                        var acc = 0f
                        detectVerticalDragGestures(
                            onDragStart = { anim?.cancel(); start = vm.cratePos; acc = 0f },
                            onDragEnd = { settle(vm.cratePos.roundToInt().toFloat()) },
                            onDragCancel = { settle(vm.cratePos.roundToInt().toFloat()) },
                        ) { change, dy ->
                            change.consume()
                            acc += dy
                            vm.cratePos = (start - acc / (dimPx * 0.5f)).coerceIn(-0.35f, n - 0.65f)
                        }
                    }
                    .pointerInput(albums, dimPx, heightPx) {
                        detectTapGestures(onTap = { o ->
                            val now = vm.cratePos.roundToInt().coerceIn(0, n - 1)
                            val dy = o.y - heightPx / 2f
                            when {
                                dy > dimPx / 2f -> settle((now + 1).toFloat())
                                dy < -dimPx / 2f -> settle((now - 1).toFloat())
                                else -> albums.getOrNull(now)?.let(onOpen)
                            }
                        })
                    },
                contentAlignment = Alignment.Center,
            ) {
                val first = floor(pos - 4.5f).toInt().coerceAtLeast(0)
                val last = ceil(pos + 4.5f).toInt().coerceAtMost(n - 1)
                for (i in first..last) {
                    val a = albums[i]
                    key(a.key) {
                        val d = i - pos
                        val ad = abs(d)
                        val near = ad.coerceAtMost(1f)
                        val y = sign(d) * (near * dimPx * 0.62f + (ad - 1f).coerceAtLeast(0f) * dimPx * 0.2f)
                        val rx = d.coerceIn(-1f, 1f) * 55f
                        val sc = 1f - near * 0.2f
                        val al = if (ad > 3.5f) ((4.5f - ad)).coerceIn(0f, 1f) else 1f
                        val shade = near * 0.25f + (ad - 1f).coerceAtLeast(0f) * 0.06f
                        FlowItem(
                            a, dim, shade,
                            Modifier
                                .zIndex(100f - ad * 10f)
                                .graphicsLayer {
                                    translationY = y
                                    rotationX = rx
                                    scaleX = sc
                                    scaleY = sc
                                    alpha = al
                                    cameraDistance = 10f * density
                                },
                        )
                    }
                }
                AlphaStrip(
                    albums, albums[cur].letter,
                    onPick = { idx -> if (idx >= 0) settle(idx.toFloat()) },
                    modifier = Modifier.align(Alignment.CenterEnd).zIndex(1000f),
                )
            }
        }

        val a = albums[cur]
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 6.dp), verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f)) {
                Text(a.artist.uppercase(), fontSize = 13.sp, letterSpacing = 0.1.em, color = c.inkSoft, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(a.title, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, letterSpacing = (-0.02).em, maxLines = 1, overflow = TextOverflow.Ellipsis)
                MetaLine(a, Modifier.padding(top = 4.dp))
            }
            Text("${cur + 1} / $n", fontFamily = AppFont, fontSize = 12.sp, color = c.inkSoft)
        }
        Text(
            "Svep upp eller ner för att bläddra · tryck på skivan i mitten för att öppna",
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), fontSize = 12.5.sp, color = c.inkSoft,
        )
    }
}

/** One sleeve in the column. */
@Composable
private fun FlowItem(album: Album, dim: Dp, shade: Float, modifier: Modifier) {
    val shape = RoundedCornerShape(3.dp)
    Box(modifier.size(dim).shadow(14.dp, shape).clip(shape)) {
        AlbumArt(album, Modifier.fillMaxSize(), dim)
        Sticker(album, dim)
        if (shade > 0.001f) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = shade)))
    }
}
