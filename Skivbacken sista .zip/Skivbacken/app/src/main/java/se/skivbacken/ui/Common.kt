package se.skivbacken.ui

import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import se.skivbacken.Album
import se.skivbacken.ArtCache
import se.skivbacken.ArtVersion
import se.skivbacken.Screen
import se.skivbacken.MainViewModel
import se.skivbacken.OnlineArt
import se.skivbacken.Spec
import se.skivbacken.SpecCache
import se.skivbacken.Track

val ArtInk = Color(0xFFF8F6F0)

fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

fun fmtTotal(ms: Long): String {
    val m = ms / 60000
    return if (m >= 60) "${m / 60} h ${m % 60} min" else "$m min"
}

/**
 * Order: a cover picked by hand, then the one inside the file, then Cover Art Archive.
 * Reloads when the album changes or a cover is changed by hand.
 */
@Composable
fun rememberCover(album: Album): ImageBitmap? {
    val ctx = LocalContext.current
    val first = album.tracks.first()
    val version = ArtVersion.value
    val custom = remember(album.key) { OnlineArt.customFile(ctx, album) }
    fun peek(): ImageBitmap? = ArtCache.peekFile(custom)
        ?: if (custom.exists()) null
        else ArtCache.peekTrack(first.id) ?: ArtCache.peekFile(OnlineArt.frontFile(ctx, album))
    val state = produceState(remember(album.key, version) { peek() }, album.key, version) {
        value = peek()
        if (value != null) return@produceState
        if (custom.exists()) {
            value = ArtCache.loadFile(custom)
            if (value != null) return@produceState
        }
        value = ArtCache.loadEmbedded(ctx, first)
            ?: OnlineArt.get(ctx, album).front?.let { ArtCache.loadFile(it) }
    }
    return state.value
}

/** Photo of the disc itself ("Medium" in Cover Art Archive), if anyone has uploaded one. */
@Composable
fun rememberDiscImage(album: Album): ImageBitmap? {
    val ctx = LocalContext.current
    val version = ArtVersion.value
    val disc = remember(album.key) { OnlineArt.discFile(ctx, album) }
    val state = produceState(remember(album.key, version) { ArtCache.peekFile(disc) }, album.key, version) {
        value = ArtCache.peekFile(disc)
        if (value != null) return@produceState
        value = OnlineArt.get(ctx, album).disc?.let { ArtCache.loadFile(it) }
    }
    return state.value
}

@Composable
fun rememberSpec(track: Track): Spec? {
    val ctx = LocalContext.current
    val state = produceState(SpecCache.peek(track.id), track.id) {
        value = SpecCache.peek(track.id) ?: SpecCache.load(ctx, track)
    }
    return state.value
}

/** Long-press menu on a cover: search for another one, or look it up again from scratch. */
@Composable
fun CoverMenu(vm: MainViewModel, album: Album, expanded: Boolean, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(text = { Text("Sök omslag…") }, onClick = {
            onDismiss()
            vm.screen = Screen.CoverSearch(album.key, vm.screen)
        })
        DropdownMenuItem(text = { Text("Hämta omslaget igen") }, onClick = {
            onDismiss()
            OnlineArt.reset(ctx, album)
            Toast.makeText(ctx, "Hämtar omslaget igen", Toast.LENGTH_SHORT).show()
        })
    }
}

@Composable
fun AlbumArt(album: Album, modifier: Modifier, dim: Dp, showText: Boolean = true) {
    val art = rememberCover(album)
    Box(modifier) {
        if (art != null) {
            Image(art, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            GenArt(album, dim, showText)
        }
    }
}

/** A printed sleeve for albums without any cover: colour and pattern come from the name. */
@Composable
fun GenArt(album: Album, dim: Dp, showText: Boolean = true) {
    val h = remember(album.key) { (album.artist + album.title).hashCode().toLong() and 0xffffffffL }
    val hue = (h % 360).toFloat()
    val variant = ((h shr 9) % 3).toInt()
    val base = Color.hsv(hue, 0.36f, 0.42f)
    val pattern = Color.hsv((hue + 30f) % 360f, 0.45f, 0.62f, 0.55f)
    val comp = Color.hsv((hue + 180f) % 360f, 0.5f, 0.66f)
    val low = Color.hsv(hue, 0.4f, 0.28f)
    Box(
        Modifier
            .fillMaxSize()
            .background(base)
            .drawBehind {
                val w = size.width
                val hgt = size.height
                when (variant) {
                    0 -> {
                        val c = Offset(w * 0.78f, hgt * 0.26f)
                        var r = w * 0.06f
                        while (r < w * 1.2f) {
                            drawCircle(pattern, r, c, style = Stroke(w * 0.03f))
                            r += w * 0.08f
                        }
                    }
                    1 -> {
                        val step = w * 0.12f
                        var x = -hgt
                        while (x < w + hgt) {
                            drawLine(pattern, Offset(x, 0f), Offset(x - hgt * 0.5f, hgt), strokeWidth = step * 0.5f)
                            x += step
                        }
                    }
                    else -> {
                        drawCircle(comp, w * 0.27f, Offset(w * 0.3f, hgt * 0.34f))
                        drawRect(low, topLeft = Offset(0f, hgt * 0.62f), size = Size(w, hgt * 0.38f))
                    }
                }
            },
    ) {
        if (showText) {
            Column(Modifier.align(Alignment.BottomStart).padding(dim * 0.09f)) {
                Text(
                    album.artist.uppercase(), color = ArtInk, fontSize = (dim.value * 0.05f).sp,
                    letterSpacing = 0.12.em, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    album.title, color = ArtInk, fontSize = (dim.value * 0.11f).sp, lineHeight = (dim.value * 0.11f).sp,
                    fontWeight = FontWeight.ExtraBold, maxLines = 3, overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/** Round price-sticker with the format, like the stickers on a record shop's sleeves. */
@Composable
fun BoxScope.Sticker(album: Album, dim: Dp) {
    val c = LocalSkiv.current
    val spec = if (album.format == "FLAC") rememberSpec(album.tracks.first()) else null
    val top = when {
        album.format == "MP3" -> "MP3"
        spec != null && spec.known && spec.hiRes -> "HI-RES"
        else -> "FLAC"
    }
    val bottom = if (spec != null && spec.known) spec.short else ""
    Box(
        Modifier
            .align(Alignment.TopEnd)
            .padding(dim * 0.05f)
            .size(dim * 0.19f)
            .rotate(-12f)
            .shadow(2.dp, CircleShape)
            .background(c.sticker, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(top, fontFamily = AppFont, fontSize = (dim.value * 0.027f).sp, color = c.stickerInk, letterSpacing = 0.06.em, lineHeight = (dim.value * 0.032f).sp)
            if (bottom.isNotEmpty()) {
                Text(bottom, fontFamily = AppFont, fontSize = (dim.value * 0.034f).sp, color = c.stickerInk, fontWeight = FontWeight.Medium, lineHeight = (dim.value * 0.04f).sp)
            }
        }
    }
}

@Composable
fun MetaLine(album: Album, modifier: Modifier = Modifier) {
    val c = LocalSkiv.current
    val spec = if (album.format == "FLAC") rememberSpec(album.tracks.first()) else null
    val parts = listOfNotNull(
        album.year.takeIf { it > 0 }?.toString(),
        "${album.tracks.size} spår",
        fmtTotal(album.totalMs),
        spec?.takeIf { it.known }?.long ?: if (album.format == "MP3") "MP3" else null,
    )
    Text(parts.joinToString(" · "), modifier = modifier, fontFamily = AppFont, fontSize = 12.sp, color = c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
}

/**
 * One row in a track list. Behind the playing track a translucent fill grows with the song;
 * a long press opens [menu] (queue actions) when one is given.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TrackRow(
    no: Int,
    title: String,
    subtitle: String?,
    durationMs: Long,
    playing: Boolean,
    onClick: () -> Unit,
    progress: Float? = null,
    menu: (@Composable (dismiss: () -> Unit) -> Unit)? = null,
) {
    val c = LocalSkiv.current
    var open by remember { mutableStateOf(false) }
    Column {
        Box {
            Row(
                Modifier
                    .fillMaxWidth()
                    .drawBehind {
                        if (progress != null) {
                            drawRect(c.sticker.copy(alpha = 0.16f), size = Size(size.width * progress.coerceIn(0f, 1f), size.height))
                        }
                    }
                    .combinedClickable(onClick = onClick, onLongClick = if (menu != null) ({ open = true }) else null)
                    .padding(horizontal = 16.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("%02d".format(no), modifier = Modifier.width(36.dp), fontFamily = AppFont, fontSize = 12.sp, color = if (playing) c.sticker else c.inkSoft)
                Column(Modifier.weight(1f)) {
                    Text(
                        title, fontSize = 15.5.sp, color = if (playing) c.sticker else c.ink,
                        fontWeight = if (playing) FontWeight.SemiBold else FontWeight.Normal, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    )
                    if (subtitle != null) Text(subtitle, fontSize = 12.5.sp, color = c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (durationMs > 0) Text(fmtTime(durationMs), fontFamily = AppFont, fontSize = 12.sp, color = c.inkSoft)
            }
            if (menu != null) {
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) { menu { open = false } }
            }
        }
        Box(Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(1.dp).background(c.line))
    }
}

/** "Play next" / "Add to queue" entries for a track's long-press menu. */
@Composable
fun QueueMenuItems(vm: MainViewModel, album: Album, index: Int, dismiss: () -> Unit) {
    val ctx = LocalContext.current
    DropdownMenuItem(text = { Text("Spela härnäst") }, onClick = {
        vm.playNext(album, index)
        Toast.makeText(ctx, "Spelas härnäst", Toast.LENGTH_SHORT).show()
        dismiss()
    })
    DropdownMenuItem(text = { Text("Lägg sist i kön") }, onClick = {
        vm.addToQueue(album, listOf(album.tracks[index]))
        Toast.makeText(ctx, "Lagd i kön", Toast.LENGTH_SHORT).show()
        dismiss()
    })
}

/** Round button that dips a little when pressed. */
@Composable
fun PressButton(
    onClick: () -> Unit,
    size: Dp,
    modifier: Modifier = Modifier,
    background: Color = Color.Transparent,
    content: @Composable BoxScope.() -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.86f else 1f, spring(dampingRatio = 0.45f, stiffness = 700f), label = "press")
    Box(
        modifier
            .size(size)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape)
            .background(background)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
        content = content,
    )
}
