package se.skivbacken.ui

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.background
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import se.skivbacken.Album
import se.skivbacken.MainViewModel
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sign

/**
 * Landscape library: records standing on edge on a shelf, spine towards you with "Artist • Album".
 * The one in the middle opens up and shows its cover. Swipe sideways; tilt the phone and the
 * sleeves turn as if you looked at them from another angle. Tap the middle one to open it.
 */
@Composable
fun ShelfScreen(vm: MainViewModel, onOpen: (Album) -> Unit, modifier: Modifier = Modifier) {
    val c = LocalSkiv.current
    val albums = vm.albums
    val n = albums.size
    val scope = rememberCoroutineScope()
    var anim by remember { mutableStateOf<Job?>(null) }
    val tilt = rememberTilt()

    fun settle(target: Float) {
        anim?.cancel()
        val t = target.coerceIn(0f, (n - 1).coerceAtLeast(0).toFloat())
        anim = scope.launch {
            animate(vm.cratePos, t, animationSpec = spring(dampingRatio = 0.9f, stiffness = 200f)) { v, _ -> vm.cratePos = v }
        }
    }
    if (n == 0) return
    val pos = vm.cratePos.coerceIn(-0.4f, n - 0.6f)
    val cur = pos.roundToInt().coerceIn(0, n - 1)

    Row(modifier.fillMaxSize()) {
        // Records stay inside their own area, so the text beside them stays readable.
        BoxWithConstraints(Modifier.weight(1f).fillMaxSize().clipToBounds()) {
            val density = LocalDensity.current
            val wPx = with(density) { maxWidth.toPx() }
            val hPx = with(density) { maxHeight.toPx() }
            val dim = minOf(hPx * 0.80f, wPx * 0.34f)
            val first = floor(pos - 9f).toInt().coerceAtLeast(0)
            val last = ceil(pos + 9f).toInt().coerceAtMost(n - 1)

            // Covers for the visible records.
            val covers = HashMap<String, ImageBitmap?>()
            for (i in first..last) {
                val a = albums[i]
                key(a.key) { covers[a.key] = rememberCover(a) }
            }
            val spinePaint = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) } }
            val bmpPaint = remember { Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG) }

            Canvas(
                Modifier
                    .fillMaxSize()
                    .pointerInput(n, dim) {
                        var start = 0f
                        var acc = 0f
                        detectHorizontalDragGestures(
                            onDragStart = { anim?.cancel(); start = vm.cratePos; acc = 0f },
                            onDragEnd = { settle(vm.cratePos.roundToInt().toFloat()) },
                            onDragCancel = { settle(vm.cratePos.roundToInt().toFloat()) },
                        ) { change, dx ->
                            change.consume()
                            acc += dx
                            vm.cratePos = (start - acc / (dim * 0.30f)).coerceIn(-0.4f, n - 0.6f)
                        }
                    }
                    .pointerInput(albums, dim, wPx) {
                        detectTapGestures { o ->
                            val now = vm.cratePos.roundToInt().coerceIn(0, n - 1)
                            val dx = o.x - wPx / 2f
                            when {
                                dx > dim * 0.55f -> settle((now + 1 + ((dx - dim * 0.55f) / (dim * 0.22f)).toInt()).toFloat())
                                dx < -dim * 0.55f -> settle((now - 1 - ((-dx - dim * 0.55f) / (dim * 0.22f)).toInt()).toFloat())
                                else -> albums.getOrNull(now)?.let(onOpen)
                            }
                        }
                    },
            ) {
                val cx = size.width / 2f
                val cy = size.height * 0.50f
                val spineW = dim * 0.075f
                val step = dim * 0.22f
                // Middle first, then outwards, so records further out stand in front of the open one's edges.
                val order = (first..last).sortedBy { abs(it - pos) }
                for (i in order) {
                    val a = albums[i]
                    val d = i - pos
                    val ad = abs(d)
                    val near = ad.coerceAtMost(1f)
                    val side = if (d == 0f) 1f else sign(d)
                    // Angle of the sleeve: open in the middle, nearly edge-on further out. Tilt turns them all.
                    val theta = (near * 72f - side * tilt.x * 16f).coerceIn(0f, 84f)
                    val faceW = dim * cos(Math.toRadians(theta.toDouble())).toFloat()
                    val sw = spineW * near
                    val off = side * (near * (dim * 0.5f + dim * 0.06f) + (ad - 1f).coerceAtLeast(0f) * step)
                    val h = dim
                    val shrink = (theta / 84f) * 0.16f // far edge a little smaller, like perspective
                    val lift = tilt.y * h * 0.05f * (theta / 84f)
                    val alpha = if (ad > 8f) (9f - ad).coerceIn(0f, 1f) else 1f
                    // Spine edge (towards the middle) and the far edge of the face.
                    val spineX = cx + off - side * (if (near < 1f) dim / 2f * (1 - near) else 0f)
                    val nearEdge = spineX + side * sw
                    val farEdge = nearEdge + side * faceW
                    val top = cy - h / 2f
                    val bottom = cy + h / 2f

                    val cover = covers[a.key]
                    val colour = spineColour(cover, a)
                    drawIntoCanvas { canvas ->
                        val nc = canvas.nativeCanvas
                        // Face of the sleeve, mapped onto the turned shape.
                        val dst = floatArrayOf(
                            nearEdge, top, farEdge, top + h * shrink / 2f - lift,
                            farEdge, bottom - h * shrink / 2f - lift, nearEdge, bottom,
                        )
                        val bmp: Bitmap? = cover?.asAndroidBitmap()
                        if (bmp != null) {
                            val src = floatArrayOf(0f, 0f, bmp.width.toFloat(), 0f, bmp.width.toFloat(), bmp.height.toFloat(), 0f, bmp.height.toFloat())
                            if (side < 0) {
                                // Mirror the mapping so the cover isn't drawn back to front.
                                src[0] = bmp.width.toFloat(); src[2] = 0f; src[4] = 0f; src[6] = bmp.width.toFloat()
                            }
                            val m = Matrix().apply { setPolyToPoly(src, 0, dst, 0, 4) }
                            bmpPaint.alpha = (alpha * 255).toInt()
                            nc.save()
                            nc.concat(m)
                            nc.drawBitmap(bmp, 0f, 0f, bmpPaint)
                            nc.restore()
                        } else {
                            val p = android.graphics.Path().apply {
                                moveTo(dst[0], dst[1]); lineTo(dst[2], dst[3]); lineTo(dst[4], dst[5]); lineTo(dst[6], dst[7]); close()
                            }
                            spinePaint.color = colour
                            spinePaint.alpha = (alpha * 255).toInt()
                            nc.drawPath(p, spinePaint)
                        }
                        // Shade the face as it turns away from the light.
                        val shade = android.graphics.Path().apply {
                            moveTo(dst[0], dst[1]); lineTo(dst[2], dst[3]); lineTo(dst[4], dst[5]); lineTo(dst[6], dst[7]); close()
                        }
                        spinePaint.color = android.graphics.Color.BLACK
                        spinePaint.alpha = ((theta / 84f) * 110f * alpha).toInt()
                        nc.drawPath(shade, spinePaint)
                        // A soft glare that slides over the open cover when you tilt the phone.
                        if (theta < 30f) {
                            val gx = nearEdge + side * faceW * (0.5f + tilt.x * 0.45f)
                            spinePaint.shader = android.graphics.LinearGradient(
                                gx - faceW * 0.35f, top, gx + faceW * 0.35f, bottom,
                                intArrayOf(0, android.graphics.Color.argb(55, 255, 255, 255), 0), null,
                                android.graphics.Shader.TileMode.CLAMP,
                            )
                            spinePaint.alpha = ((1f - theta / 30f) * 255).toInt()
                            nc.drawPath(shade, spinePaint)
                            spinePaint.shader = null
                        }

                        // The spine, facing you, with the name running along it.
                        if (sw > 1f) {
                            val l = minOf(spineX, nearEdge)
                            spinePaint.color = colour
                            spinePaint.alpha = (alpha * 255).toInt()
                            nc.drawRect(l, top, l + sw, bottom, spinePaint)
                            spinePaint.color = android.graphics.Color.WHITE
                            spinePaint.alpha = (alpha * 30).toInt()
                            nc.drawRect(l, top, l + 1.5f, bottom, spinePaint)
                            val dark = luminance(colour) < 0.55f
                            spinePaint.color = if (dark) 0xFFF2F0E8.toInt() else 0xFF1C1C18.toInt()
                            spinePaint.alpha = (alpha * near * 255).toInt()
                            spinePaint.textSize = sw * 0.42f
                            val text = ellipsize("${a.artist} • ${a.title}", spinePaint, h * 0.86f)
                            nc.save()
                            nc.rotate(90f, l + sw / 2f, top + h * 0.07f)
                            nc.drawText(text, l + sw / 2f, top + h * 0.07f + spinePaint.textSize * 0.35f, spinePaint)
                            nc.restore()
                        }
                    }
                }
            }
        }
        // Caption for the record in the middle.
        val a = albums[cur]
        Column(
            Modifier.width(210.dp).fillMaxSize().background(c.wall).padding(start = 14.dp, end = 12.dp, top = 12.dp, bottom = 12.dp),
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.Bottom,
        ) {
            Text(a.artist.uppercase(), fontSize = 12.sp, letterSpacing = 0.1.em, color = c.inkSoft, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(a.title, fontSize = 22.sp, lineHeight = 25.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, maxLines = 3, overflow = TextOverflow.Ellipsis)
            MetaLine(a, Modifier.padding(top = 4.dp))
            Text("${cur + 1} / $n", modifier = Modifier.padding(top = 10.dp), fontSize = 12.sp, color = c.inkSoft)
            Text("Svep i sidled · tryck på skivan för att öppna", modifier = Modifier.padding(top = 4.dp), fontSize = 12.sp, color = c.inkSoft)
        }
    }
}

private val spineCache = HashMap<String, Int>()

/** A colour for the spine, taken from the cover. */
private fun spineColour(cover: ImageBitmap?, a: Album): Int {
    spineCache[a.key]?.let { return it }
    if (cover == null) {
        val h = ((a.key.hashCode().toLong() and 0xffffffffL) % 360).toFloat()
        return Color.hsv(h, 0.35f, 0.32f).toArgb()
    }
    val col = runCatching {
        val b = cover.asAndroidBitmap().let { if (it.config == Bitmap.Config.HARDWARE) it.copy(Bitmap.Config.ARGB_8888, false) else it }
        // The left edge of a cover is what a spine usually looks like.
        val strip = Bitmap.createBitmap(b, 0, 0, (b.width / 12).coerceAtLeast(1), b.height)
        Bitmap.createScaledBitmap(strip, 1, 1, true).getPixel(0, 0)
    }.getOrElse { 0xFF2A2C2E.toInt() }
    spineCache[a.key] = col
    return col
}

private fun luminance(c: Int): Float {
    val r = (c shr 16 and 0xff) / 255f
    val g = (c shr 8 and 0xff) / 255f
    val b = (c and 0xff) / 255f
    return 0.299f * r + 0.587f * g + 0.114f * b
}

private fun ellipsize(text: String, p: Paint, max: Float): String {
    if (p.measureText(text) <= max) return text
    var t = text
    while (t.isNotEmpty() && p.measureText("$t…") > max) t = t.dropLast(1)
    return "$t…"
}
