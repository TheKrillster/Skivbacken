package se.skivbacken

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Spectrum analyser fed straight from the player's PCM output (no microphone permission).
 * 20 bands, log spaced from 40 Hz to 16 kHz, each 0..1.
 */
@OptIn(UnstableApi::class)
object Spectrum : TeeAudioProcessor.AudioBufferSink {
    const val BANDS = 20
    private const val N = 1024

    val levels = FloatArray(BANDS)
    @Volatile var updatedAt = 0L
        private set

    private var rate = 44100
    private var channels = 2
    private var encoding = C.ENCODING_PCM_16BIT
    private val buf = FloatArray(N)
    private var fill = 0
    private val re = FloatArray(N)
    private val im = FloatArray(N)
    private val window = FloatArray(N) { (0.5 - 0.5 * cos(2 * PI * it / (N - 1))).toFloat() }

    override fun flush(sampleRateHz: Int, channelCount: Int, encoding: Int) {
        rate = sampleRateHz.coerceAtLeast(8000)
        channels = channelCount.coerceAtLeast(1)
        this.encoding = encoding
        fill = 0
    }

    override fun handleBuffer(buffer: ByteBuffer) {
        val bytesPer = when (encoding) {
            C.ENCODING_PCM_16BIT -> 2
            C.ENCODING_PCM_FLOAT -> 4
            else -> return
        }
        val b = buffer.duplicate().order(ByteOrder.nativeOrder())
        val frame = bytesPer * channels
        while (b.remaining() >= frame) {
            var sum = 0f
            for (ch in 0 until channels) sum += if (bytesPer == 2) b.short / 32768f else b.float
            buf[fill++] = sum / channels
            if (fill == N) {
                analyze()
                fill = 0
            }
        }
    }

    private fun analyze() {
        for (i in 0 until N) {
            re[i] = buf[i] * window[i]
            im[i] = 0f
        }
        fft(re, im)
        val top = minOf(16000.0, rate / 2.0)
        val lo = 40.0
        for (band in 0 until BANDS) {
            val f0 = lo * (top / lo).pow(band.toDouble() / BANDS)
            val f1 = lo * (top / lo).pow((band + 1).toDouble() / BANDS)
            val k0 = (f0 * N / rate).toInt().coerceIn(1, N / 2 - 1)
            val k1 = (f1 * N / rate).toInt().coerceIn(k0 + 1, N / 2)
            var peak = 0f
            for (k in k0 until k1) {
                val m = sqrt(re[k] * re[k] + im[k] * im[k])
                if (m > peak) peak = m
            }
            val db = 20f * log10(peak / (N / 4f) + 1e-9f)
            levels[band] = ((db + 62f) / 58f).coerceIn(0f, 1f)
        }
        updatedAt = System.nanoTime()
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang).toFloat()
            val wi = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var cr = 1f
                var ci = 0f
                for (k in 0 until len / 2) {
                    val a = i + k
                    val b = a + len / 2
                    val tr = re[b] * cr - im[b] * ci
                    val ti = re[b] * ci + im[b] * cr
                    re[b] = re[a] - tr
                    im[b] = im[a] - ti
                    re[a] += tr
                    im[a] += ti
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
