package se.skivbacken.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.flow.first
import se.skivbacken.Album
import se.skivbacken.MainViewModel
import se.skivbacken.Spectrum

/** Full-screen player. The library is hidden while this is shown. */
@Composable
fun PlayingScreen(vm: MainViewModel, onBack: () -> Unit) {
    val c = LocalSkiv.current
    val album = vm.currentAlbum
    val track = vm.currentTrack
    Column(
        Modifier
            .fillMaxSize()
            .background(c.panel)
            .systemBarsPadding()
            .verticalScroll(rememberScrollState()),
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            PressButton(onClick = onBack, size = 48.dp) { Glyph(Ic.Down, c.ink, Modifier.size(26.dp)) }
            Text("Till backen", fontSize = 14.sp, color = c.inkSoft, modifier = Modifier.weight(1f))
            if (album != null) {
                Text(
                    album.title, modifier = Modifier.padding(end = 12.dp).weight(1f), fontSize = 13.sp, color = c.inkSoft,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }

        if (album == null || track == null) {
            Text("Ingen skiva i spelaren", modifier = Modifier.padding(24.dp), fontSize = 18.sp, color = c.ink)
            return@Column
        }

        BoxWithConstraints(Modifier.fillMaxWidth().padding(top = 8.dp)) {
            val dim = minOf(maxWidth - 64.dp, 340.dp)
            CdStage(album, vm.isPlaying, dim)
        }

        Vfd(
            trackNo = vm.currentTrackIndex + 1,
            total = album.tracks.size,
            posMs = vm.positionMs,
            playing = vm.isPlaying,
            format = album.format,
            album = album,
        )

        Column(Modifier.padding(horizontal = 24.dp).padding(top = 20.dp)) {
            Text(track.title, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, letterSpacing = (-0.02).em, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(track.artist, fontSize = 15.sp, color = c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }

        SeekBar(
            positionMs = vm.positionMs,
            durationMs = vm.durationMs,
            onSeek = { vm.seek(it) },
            modifier = Modifier.padding(horizontal = 24.dp).padding(top = 18.dp),
        )

        Controls(vm, Modifier.padding(horizontal = 16.dp, vertical = 8.dp))

        Text(
            "SPÅR", modifier = Modifier.padding(start = 16.dp, top = 20.dp, bottom = 4.dp),
            fontFamily = Mono, fontSize = 11.sp, letterSpacing = 0.12.em, color = c.inkSoft,
        )
        album.tracks.forEachIndexed { i, t ->
            TrackRow(
                no = if (t.no > 0) t.no else i + 1,
                title = t.title,
                subtitle = t.artist.takeIf { it != album.artist },
                durationMs = t.durationMs,
                playing = i == vm.currentTrackIndex,
                onClick = { vm.jumpTo(i) },
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** The disc standing on a glossy deck, with its reflection fading into the surface. */
@Composable
private fun CdStage(album: Album, playing: Boolean, dim: Dp) {
    val c = LocalSkiv.current
    val angle = rememberSpin(playing)
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        CdFace(album, angle, Modifier.size(dim).shadow(20.dp, CircleShape))
        Box(
            Modifier
                .fillMaxWidth()
                .height(dim * 0.42f)
                .background(Brush.verticalGradient(listOf(c.deckShine, c.deck, c.panel)))
                .drawBehind {
                    drawLine(Color.White.copy(alpha = 0.28f), Offset(0f, 0f), Offset(size.width, 0f), 1.5.dp.toPx())
                    drawRect(
                        Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.07f), Color.Transparent)),
                        size = Size(size.width, size.height * 0.5f),
                    )
                }
                .clipToBounds(),
            contentAlignment = Alignment.TopCenter,
        ) {
            CdFace(
                album, angle,
                Modifier
                    .padding(top = 3.dp)
                    .wrapContentHeight(Alignment.Top, unbounded = true)
                    .size(dim)
                    .graphicsLayer {
                        scaleY = -1f
                        alpha = 0.42f
                        compositingStrategy = CompositingStrategy.Offscreen
                    }
                    .drawWithContent {
                        drawContent()
                        drawRect(
                            Brush.verticalGradient(0f to Color.Transparent, 0.58f to Color.Transparent, 1f to Color.Black),
                            blendMode = BlendMode.DstIn,
                        )
                    },
            )
        }
    }
}

/** Spins up when playing and coasts to a stop on pause, like a real drive. */
@Composable
private fun rememberSpin(playing: Boolean): Float {
    val playingState = rememberUpdatedState(playing)
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        var speed = 0f
        while (true) {
            if (!playingState.value && speed < 0.5f) {
                speed = 0f
                last = 0L
                snapshotFlow { playingState.value }.first { it }
            }
            withFrameNanos { now ->
                if (last != 0L) {
                    val dt = ((now - last) / 1e9f).coerceAtMost(0.1f)
                    val target = if (playingState.value) 240f else 0f
                    speed += (target - speed) * (dt * 2.2f).coerceAtMost(1f)
                    angle = (angle + speed * dt) % 360f
                }
                last = now
            }
        }
    }
    return angle
}

@Composable
private fun CdFace(album: Album, angle: Float, modifier: Modifier) {
    val disc = rememberDiscImage(album)
    val cover = rememberCover(album)
    BoxWithConstraints(modifier.clip(CircleShape).background(Color(0xFFD9DCDF)), contentAlignment = Alignment.Center) {
        val dim = maxWidth
        // The printed face turns; the light on the plastic stays put.
        Box(Modifier.fillMaxSize().padding(dim * 0.012f).graphicsLayer { rotationZ = angle }.clip(CircleShape)) {
            val img = disc ?: cover
            if (img != null) {
                Image(img, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                GenArt(album, dim, showText = false)
            }
            if (disc == null) {
                Text(
                    album.title.uppercase(),
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = dim * 0.1f),
                    color = Color.White.copy(alpha = 0.85f), fontSize = (dim.value * 0.045f).sp,
                    letterSpacing = 0.2.em, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            val ctr = center
            drawCircle(
                Brush.sweepGradient(
                    listOf(
                        Color.Transparent, Color(0x3300E5FF), Color.Transparent, Color(0x2EFF4FD8),
                        Color.Transparent, Color(0x2EFFE14F), Color.Transparent, Color(0x3300E5FF), Color.Transparent,
                    ),
                    ctr,
                ),
                r, ctr,
            )
            drawCircle(Color.White.copy(alpha = 0.30f), r * 0.25f, ctr)
            drawCircle(Color(0xCCE6E9EC), r * 0.17f, ctr)
            drawCircle(Color.White.copy(alpha = 0.55f), r * 0.17f, ctr, style = Stroke(1.dp.toPx()))
            drawCircle(Color(0xFF2A2E2B), r * 0.075f, ctr)
            drawCircle(Color.White.copy(alpha = 0.4f), r - 1.dp.toPx(), ctr, style = Stroke(1.5.dp.toPx()))
        }
    }
}

/** Fluorescent display like a CD deck's: track, time and Winamp-style spectrum bars. */
@Composable
private fun Vfd(trackNo: Int, total: Int, posMs: Long, playing: Boolean, format: String, album: Album) {
    val c = LocalSkiv.current
    val spec = if (format == "FLAC") rememberSpec(album.tracks.first()) else null
    Column(
        Modifier
            .padding(horizontal = 16.dp)
            .padding(top = 4.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(c.vfdBg)
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f)) {
                Text("TRACK", fontFamily = Mono, fontSize = 10.sp, letterSpacing = 0.15.em, color = c.vfdInk.copy(alpha = 0.6f))
                Text("%02d / %02d".format(trackNo, total), fontFamily = Mono, fontSize = 20.sp, color = c.vfdInk)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(if (playing) "▶ PLAY" else "❚❚ PAUS", fontFamily = Mono, fontSize = 10.sp, letterSpacing = 0.15.em, color = c.vfdInk.copy(alpha = 0.6f))
                Text(fmtTime(posMs).padStart(5, '0'), fontFamily = Mono, fontSize = 30.sp, fontWeight = FontWeight.Medium, color = c.vfdInk)
            }
        }
        Analyzer(Modifier.fillMaxWidth().height(64.dp).padding(top = 10.dp))
        Text(
            if (format == "FLAC" && spec != null && spec.known) "FLAC  ${spec.long}" else format,
            modifier = Modifier.padding(top = 8.dp),
            fontFamily = Mono, fontSize = 10.sp, letterSpacing = 0.12.em, color = c.vfdInk.copy(alpha = 0.6f),
        )
    }
}

private val BarLow = Color(0xFF3BD14B)
private val BarMid = Color(0xFFE6D63A)
private val BarHigh = Color(0xFFE5452C)
private val BarPeak = Color(0xFFC9CED1)

@Composable
private fun Analyzer(modifier: Modifier) {
    val n = Spectrum.BANDS
    val heights = remember { FloatArray(n) }
    val peaks = remember { FloatArray(n) }
    val hold = remember { FloatArray(n) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1e9f).coerceAtMost(0.1f)
                last = now
                val fresh = System.nanoTime() - Spectrum.updatedAt < 250_000_000L
                for (i in 0 until n) {
                    val target = if (fresh) Spectrum.levels[i] else 0f
                    heights[i] = if (target > heights[i]) target else maxOf(target, heights[i] - dt * 1.6f)
                    if (heights[i] >= peaks[i]) {
                        peaks[i] = heights[i]
                        hold[i] = 0.4f
                    } else {
                        hold[i] -= dt
                        if (hold[i] <= 0f) peaks[i] = maxOf(heights[i], peaks[i] - dt * 0.8f)
                    }
                }
                tick++
            }
        }
    }
    Canvas(modifier) {
        @Suppress("UNUSED_VARIABLE") val frame = tick
        val gap = 2.dp.toPx()
        val barW = (size.width - gap * (n - 1)) / n
        val seg = 3.dp.toPx()
        val segGap = 1.dp.toPx()
        val segs = (size.height / (seg + segGap)).toInt().coerceAtLeast(1)
        for (i in 0 until n) {
            val x = i * (barW + gap)
            val lit = (heights[i] * segs).toInt()
            for (s in 0 until segs) {
                val y = size.height - (s + 1) * (seg + segGap) + segGap
                val f = s.toFloat() / segs
                val col = when {
                    f > 0.8f -> BarHigh
                    f > 0.55f -> BarMid
                    else -> BarLow
                }
                drawRect(if (s < lit) col else col.copy(alpha = 0.08f), Offset(x, y), Size(barW, seg))
            }
            if (peaks[i] > 0.02f) {
                val py = size.height - peaks[i] * size.height
                drawRect(BarPeak, Offset(x, py.coerceAtLeast(0f)), Size(barW, 2.dp.toPx()))
            }
        }
    }
}

/** Thin timeline: tap or drag anywhere on it; the knob shows while you touch it. */
@Composable
private fun SeekBar(positionMs: Long, durationMs: Long, onSeek: (Long) -> Unit, modifier: Modifier) {
    val c = LocalSkiv.current
    var drag by remember { mutableStateOf<Float?>(null) }
    val dur = durationMs.coerceAtLeast(1L)
    val frac = drag ?: (positionMs.toFloat() / dur).coerceIn(0f, 1f)
    Column(modifier.fillMaxWidth()) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(28.dp)
                .pointerInput(dur) {
                    detectTapGestures { o -> onSeek(((o.x / size.width).coerceIn(0f, 1f) * dur).toLong()) }
                }
                .pointerInput(dur) {
                    detectHorizontalDragGestures(
                        onDragStart = { o -> drag = (o.x / size.width).coerceIn(0f, 1f) },
                        onDragEnd = { drag?.let { onSeek((it * dur).toLong()) }; drag = null },
                        onDragCancel = { drag = null },
                    ) { change, _ ->
                        change.consume()
                        drag = (change.position.x / size.width).coerceIn(0f, 1f)
                    }
                },
        ) {
            val h = if (drag != null) 6.dp.toPx() else 4.dp.toPx()
            val y = size.height / 2f - h / 2f
            drawRoundRect(c.line, Offset(0f, y), Size(size.width, h), CornerRadius(h))
            drawRoundRect(if (drag != null) c.sticker else c.ink, Offset(0f, y), Size(size.width * frac, h), CornerRadius(h))
            if (drag != null) drawCircle(c.sticker, 8.dp.toPx(), Offset(size.width * frac, size.height / 2f))
        }
        Row(Modifier.fillMaxWidth()) {
            Text(fmtTime((frac * dur).toLong()), fontFamily = Mono, fontSize = 11.sp, color = c.inkSoft, modifier = Modifier.weight(1f))
            Text(fmtTime(durationMs), fontFamily = Mono, fontSize = 11.sp, color = c.inkSoft)
        }
    }
}

/** Shuffle · previous · big play/pause · next · repeat. */
@Composable
private fun Controls(vm: MainViewModel, modifier: Modifier) {
    val c = LocalSkiv.current
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        ToggleButton(on = vm.shuffle, onClick = { vm.toggleShuffle() }) { tint -> Glyph(Ic.Shuffle, tint, Modifier.size(24.dp)) }
        PressButton(onClick = { vm.prev() }, size = 60.dp) { Glyph(Ic.Prev, c.ink, Modifier.size(32.dp)) }
        PressButton(onClick = { vm.toggle() }, size = 76.dp, background = c.sticker, modifier = Modifier.shadow(10.dp, CircleShape)) {
            Crossfade(vm.isPlaying, label = "playpause") { playing ->
                Glyph(if (playing) Ic.Pause else Ic.Play, c.stickerInk, Modifier.size(34.dp))
            }
        }
        PressButton(onClick = { vm.next() }, size = 60.dp) { Glyph(Ic.Next, c.ink, Modifier.size(32.dp)) }
        ToggleButton(on = vm.repeatMode != Player.REPEAT_MODE_OFF, onClick = { vm.cycleRepeat() }) { tint ->
            Glyph(if (vm.repeatMode == Player.REPEAT_MODE_ONE) Ic.RepeatOne else Ic.Repeat, tint, Modifier.size(24.dp))
        }
    }
}

@Composable
private fun ToggleButton(on: Boolean, onClick: () -> Unit, icon: @Composable (Color) -> Unit) {
    val c = LocalSkiv.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        PressButton(onClick = onClick, size = 48.dp) { icon(if (on) c.sticker else c.inkSoft) }
        Box(Modifier.size(4.dp).clip(CircleShape).background(if (on) c.sticker else Color.Transparent))
    }
}
