package se.skivbacken

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlaybackException
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaLibraryService.LibraryParams
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaSession
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import java.util.concurrent.Executors

/** Audio format of the last track the player could not decode; read by the app's error message. */
object LastError {
    @Volatile var format: String? = null
}

/**
 * Plays the music with the screen off, shows lock-screen controls, and lets
 * Android Auto browse albums → tracks.
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaLibraryService() {
    private var session: MediaLibrarySession? = null
    private val io = MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor())

    private val lock = Any()
    private var loaded = false
    private var albums: List<Album> = emptyList()
    private var albumById: Map<String, Album> = emptyMap()
    private var trackById: Map<String, Pair<Album, Track>> = emptyMap()

    override fun onCreate() {
        super.onCreate()
        // Taps the decoded audio for the spectrum bars on the player screen.
        val renderers = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean,
            ): AudioSink = DefaultAudioSink.Builder(context)
                .setAudioProcessors(arrayOf<AudioProcessor>(TeeAudioProcessor(Spectrum)))
                .build()
        }
        // The phone's own decoders first; FFmpeg only for formats it can't play, such as ALAC.
        renderers.setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        val player = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true,
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val f = (error as? ExoPlaybackException)
                    ?.takeIf { it.type == ExoPlaybackException.TYPE_RENDERER }?.rendererFormat
                LastError.format = f?.sampleMimeType ?: f?.containerMimeType
            }
        })
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        session = MediaLibrarySession.Builder(this, player, Callback()).setSessionActivity(open).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.run {
            player.release()
            release()
        }
        session = null
        io.shutdown()
        super.onDestroy()
    }

    // ---------- library for Android Auto ----------

    private fun albumId(a: Album) = "album:${a.albumId}:${a.key.hashCode()}"

    private fun ensureLoaded(force: Boolean = false) = synchronized(lock) {
        if (loaded && !force) return@synchronized
        val prefs = getSharedPreferences("skivbacken", Context.MODE_PRIVATE)
        val chosen = prefs.getStringSet("folders", null)?.toSet() ?: emptySet()
        val hidden = prefs.getStringSet("hidden", null)?.toSet() ?: emptySet()
        val list = runCatching { filterFolders(LibraryRepo.load(this), chosen).filterNot { it.key in hidden } }
            .getOrDefault(emptyList())
        albums = list
        albumById = list.associateBy { albumId(it) }
        trackById = buildMap { list.forEach { a -> a.tracks.forEach { t -> put(t.id.toString(), a to t) } } }
        loaded = true
    }

    private val rootItem: MediaItem = MediaItem.Builder()
        .setMediaId(ROOT)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle("Skivbacken")
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_ALBUMS)
                .build()
        )
        .build()

    private fun albumItem(a: Album): MediaItem = MediaItem.Builder()
        .setMediaId(albumId(a))
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(a.title)
                .setArtist(a.artist)
                .setAlbumTitle(a.title)
                .setAlbumArtist(a.artist)
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setMediaType(MediaMetadata.MEDIA_TYPE_ALBUM)
                .setArtworkUri(artUri(a))  // Android Auto's album grid reads this itself
                .build()
        )
        .build()

    private fun trackItem(a: Album, t: Track): MediaItem = MediaItem.Builder()
        .setMediaId(t.id.toString())
        .setUri(t.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(t.title)
                .setArtist(t.artist)
                .setAlbumTitle(a.title)
                .setAlbumArtist(a.artist)
                .setTrackNumber(t.no)
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                .setArtworkUri(ArtFiles.uriFor(this, a) ?: artUri(a))
                .build()
        )
        .build()

    private inner class Callback : MediaLibrarySession.Callback {
        override fun onGetLibraryRoot(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<MediaItem>> = io.submit<LibraryResult<MediaItem>> {
            ensureLoaded(force = true)
            LibraryResult.ofItem(rootItem, params)
        }

        override fun onGetChildren(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> = io.submit<LibraryResult<ImmutableList<MediaItem>>> {
            ensureLoaded()
            val items: List<MediaItem> = when {
                parentId == ROOT -> albums.map { albumItem(it) }
                else -> albumById[parentId]?.let { a -> a.tracks.map { trackItem(a, it) } } ?: emptyList()
            }
            val from = (page * pageSize).coerceAtMost(items.size)
            val to = (from + pageSize).coerceAtMost(items.size)
            LibraryResult.ofItemList(ImmutableList.copyOf(items.subList(from, to)), params)
        }

        override fun onGetItem(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            mediaId: String,
        ): ListenableFuture<LibraryResult<MediaItem>> = io.submit<LibraryResult<MediaItem>> {
            ensureLoaded()
            val item = when {
                mediaId == ROOT -> rootItem
                albumById[mediaId] != null -> albumItem(albumById.getValue(mediaId))
                trackById[mediaId] != null -> trackById.getValue(mediaId).let { (a, t) -> trackItem(a, t) }
                else -> null
            }
            if (item != null) LibraryResult.ofItem(item, null) else LibraryResult.ofError(LibraryResult.RESULT_ERROR_BAD_VALUE)
        }

        /** Items from Android Auto arrive without a file address; look them up. */
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> = io.submit<MutableList<MediaItem>> {
            ensureLoaded()
            mediaItems.mapNotNull { item ->
                if (item.localConfiguration != null) item
                else trackById[item.mediaId]?.let { (a, t) -> trackItem(a, t) }
            }.toMutableList()
        }

        /** Picking one track in the car queues the whole album from that track. */
        override fun onSetMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
            startIndex: Int,
            startPositionMs: Long,
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            val single = mediaItems.singleOrNull()
            if (single != null && single.localConfiguration == null) {
                return io.submit<MediaSession.MediaItemsWithStartPosition> {
                    ensureLoaded()
                    val hit = trackById[single.mediaId]
                    if (hit == null) {
                        MediaSession.MediaItemsWithStartPosition(emptyList(), 0, C.TIME_UNSET)
                    } else {
                        val (a, t) = hit
                        MediaSession.MediaItemsWithStartPosition(
                            a.tracks.map { trackItem(a, it) },
                            a.tracks.indexOf(t).coerceAtLeast(0),
                            C.TIME_UNSET,
                        )
                    }
                }
            }
            return Futures.transform(
                onAddMediaItems(mediaSession, controller, mediaItems),
                { items -> MediaSession.MediaItemsWithStartPosition(items, startIndex, startPositionMs) },
                MoreExecutors.directExecutor(),
            )
        }
    }

    private companion object {
        const val ROOT = "root"
    }
}
