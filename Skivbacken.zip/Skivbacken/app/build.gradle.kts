plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "se.skivbacken"
    compileSdk = 35

    defaultConfig {
        applicationId = "se.skivbacken"
        minSdk = 30
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
    // A fixed key, so every new build can be installed over the previous one.
    signingConfigs {
        create("skivbacken") {
            storeFile = file("skivbacken.keystore")
            storePassword = "skivbacken"
            keyAlias = "skivbacken"
            keyPassword = "skivbacken"
        }
    }
    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("skivbacken")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("skivbacken")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
    implementation("androidx.palette:palette-ktx:1.0.0")
    // Chromecast: play on the TV, with the phone as remote.
    implementation("androidx.media3:media3-cast:1.5.1")
    implementation("androidx.mediarouter:mediarouter:1.7.0")
    // FFmpeg decoders (Apple Lossless/ALAC and others the phone lacks), prebuilt by the Jellyfin project.
    implementation("org.jellyfin.media3:media3-ffmpeg-decoder:1.5.0+1")
}
