package se.skivbacken.ui

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import se.skivbacken.Album
import se.skivbacken.LETTERS
import se.skivbacken.MainViewModel
import se.skivbacken.Screen
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

@Composable
fun CrateScreen(vm: MainViewModel, onOpen: (Album) -> Unit) {
    val c = LocalSkiv.current
    val albums = vm.albums
    val n = albums.size
    val scope = rememberCoroutineScope()
    var anim by remember { mutableStateOf<Job?>(null) }

    fun settle(target: Float) {
        anim?.cancel()
        val t = target.coerceIn(0f, (n - 1).coerceAtLeast(0).toFloat())
        anim = scope.launch {
            animate(vm.cratePos, t, animationSpec = spring(dampingRatio = 0.85f, stiffness = 260f)) { v, _ -> vm.cratePos = v }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.wall, c.wall2)))
            .statusBarsPadding(),
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Skivbacken", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, letterSpacing = (-0.02).em)
            Spacer(Modifier.width(10.dp))
            Text(
                if (n == 1) "1 skiva" else "$n skivor",
                modifier = Modifier.weight(1f), fontFamily = AppFont, fontSize = 12.sp, color = c.inkSoft,
            )
            PressButton(onClick = { vm.screen = Screen.Folders }, size = 44.dp) {
                Glyph(Ic.Folder, if (vm.chosenFolders.isEmpty()) c.ink else c.sticker, Modifier.size(23.dp))
            }
            PressButton(onClick = { vm.load() }, size = 44.dp) { Glyph(Ic.Refresh, c.ink, Modifier.size(22.dp)) }
        }

        if (n == 0) {
            EmptyCrate(
                loading = vm.loading,
                filtered = vm.chosenFolders.isNotEmpty(),
                onRetry = { vm.load() },
                onFolders = { vm.screen = Screen.Folders },
                modifier = Modifier.weight(1f),
            )
        } else {
            val pos = vm.cratePos
            val cur = pos.roundToInt().coerceIn(0, n - 1)

            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                val dim = minOf(maxWidth * 0.68f, maxHeight * 0.6f, 380.dp)
                val dimPx = with(LocalDensity.current) { dim.toPx() }
                Box(
                    Modifier
                        .fillMaxSize()
                        .pointerInput(n, dimPx) {
                            var start = 0f
                            var acc = 0f
                            detectVerticalDragGestures(
                                onDragStart = { anim?.cancel(); start = vm.cratePos; acc = 0f },
                                onDragEnd = { settle(vm.cratePos.roundToInt().toFloat()) },
                                onDragCancel = { settle(vm.cratePos.roundToInt().toFloat()) },
                            ) { change, dy ->
                                change.consume()
                                acc += dy
                                vm.cratePos = (start + acc / (dimPx * 0.32f)).coerceIn(-0.35f, n - 0.65f)
                            }
                        }
                        .pointerInput(albums) {
                            detectTapGestures(onTap = {
                                albums.getOrNull(vm.cratePos.roundToInt().coerceIn(0, n - 1))?.let(onOpen)
                            })
                        },
                ) {
                    val first = floor(pos - 2.5f).toInt().coerceAtLeast(0)
                    val last = ceil(pos + 9f).toInt().coerceAtMost(n - 1)
                    for (i in first..last) {
                        val a = albums[i]
                        key(a.key) {
                            val d = i - pos
                            val t = (-d).coerceIn(0f, 1f)
                            val rx = if (d >= 0) 5f else 5f - t * 80f
                            val ty = if (d >= 0) -d * dimPx * 0.055f
                            else t * dimPx * 0.05f + (-d - 1f).coerceAtLeast(0f) * dimPx * 0.03f
                            val sc = if (d >= 0) 1f - d.coerceAtMost(9f) * 0.045f else 1f
                            val al = when {
                                d > 9f -> (10f - d).coerceIn(0f, 1f)
                                d < -2f -> ((2.5f + d) * 2f).coerceIn(0f, 1f)
                                else -> 1f
                            }
                            val shade = if (d >= 0) d.coerceAtMost(8f) * 0.065f else t * 0.3f
                            Sleeve(
                                a, dim, shade,
                                Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = dim * 0.07f)
                                    .zIndex(1000f - d * 10f)
                                    .graphicsLayer {
                                        transformOrigin = TransformOrigin(0.5f, 1f)
                                        cameraDistance = 14f * density
                                        rotationX = rx
                                        translationY = ty
                                        scaleX = sc
                                        scaleY = sc
                                        alpha = al
                                    },
                            )
                        }
                    }
                    CrateFront(albums[cur].letter, dim, Modifier.align(Alignment.BottomCenter).zIndex(5000f))
                    AlphaStrip(
                        albums, albums[cur].letter,
                        onPick = { idx -> if (idx >= 0) settle(idx.toFloat()) },
                        modifier = Modifier.align(Alignment.CenterEnd).zIndex(6000f),
                    )
                }
            }

            val a = albums[cur]
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 10.dp), verticalAlignment = Alignment.Bottom) {
                Column(Modifier.weight(1f)) {
                    Text(a.artist.uppercase(), fontSize = 13.sp, letterSpacing = 0.1.em, color = c.inkSoft, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(a.title, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, letterSpacing = (-0.02).em, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    MetaLine(a, Modifier.padding(top = 4.dp))
                }
                Text("${cur + 1} / $n", fontFamily = AppFont, fontSize = 12.sp, color = c.inkSoft)
            }
            Text(
                "Dra nedåt för att bläddra · tryck på skivan för att öppna",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), fontSize = 12.5.sp, color = c.inkSoft,
            )
        }
        MiniPlayer(vm)
        Spacer(Modifier.navigationBarsPadding())
    }
}

@Composable
private fun Sleeve(album: Album, dim: Dp, shade: Float, modifier: Modifier) {
    val shape = RoundedCornerShape(3.dp)
    Box(modifier.size(dim).shadow(10.dp, shape).clip(shape)) {
        AlbumArt(album, Modifier.fillMaxSize(), dim)
        Sticker(album, dim)
        if (shade > 0.001f) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = shade)))
    }
}

/** Front board of the plywood crate, with a hand hole and the divider letter. */
@Composable
private fun CrateFront(letter: Char, dim: Dp, modifier: Modifier) {
    val c = LocalSkiv.current
    val shape = RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp, bottomStart = 2.dp, bottomEnd = 2.dp)
    Box(
        modifier
            .size(width = dim * 1.2f, height = dim * 0.30f)
            .shadow(8.dp, shape)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(c.ply, c.plyDark)))
            .drawBehind {
                val step = 9.dp.toPx()
                var x = 0f
                var k = 0
                while (x < size.width) {
                    drawLine(c.plyGrain, Offset(x, 0f), Offset(x + size.width * 0.01f, size.height), strokeWidth = (1 + k % 2).dp.toPx())
                    x += step * (1f + (k % 3) * 0.45f)
                    k++
                }
                drawLine(Color.White.copy(alpha = 0.16f), Offset(0f, 2.dp.toPx()), Offset(size.width, 2.dp.toPx()), 2.dp.toPx())
                drawRoundRect(
                    c.plyHole,
                    topLeft = Offset(size.width * 0.35f, size.height * 0.24f),
                    size = Size(size.width * 0.30f, size.height * 0.17f),
                    cornerRadius = CornerRadius(size.height),
                )
            },
    ) {
        Text(
            letter.toString(),
            modifier = Modifier.align(Alignment.BottomStart).padding(start = dim * 0.07f, bottom = dim * 0.03f),
            color = c.plyHole.copy(alpha = 0.75f), fontSize = (dim.value * 0.11f).sp, fontWeight = FontWeight.ExtraBold,
        )
        Text(
            "A–Ö",
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = dim * 0.07f, bottom = dim * 0.05f),
            color = c.plyHole.copy(alpha = 0.75f), fontFamily = AppFont, fontSize = (dim.value * 0.035f).sp,
        )
    }
}

@Composable
private fun AlphaStrip(albums: List<Album>, current: Char, onPick: (Int) -> Unit, modifier: Modifier) {
    val c = LocalSkiv.current
    val have = remember(albums) { albums.map { it.letter }.toSet() }
    Column(
        modifier.fillMaxHeight().padding(vertical = 6.dp),
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        LETTERS.forEach { l ->
            val on = l in have
            Text(
                l.toString(),
                modifier = Modifier.width(30.dp).clickable(enabled = on) { onPick(albums.indexOfFirst { it.letter == l }) },
                textAlign = TextAlign.Center, fontFamily = AppFont, fontSize = 11.sp,
                fontWeight = if (l == current) FontWeight.Bold else FontWeight.Normal,
                color = when {
                    l == current -> c.sticker
                    on -> c.inkSoft
                    else -> c.inkSoft.copy(alpha = 0.3f)
                },
            )
        }
    }
}

@Composable
private fun EmptyCrate(loading: Boolean, filtered: Boolean, onRetry: () -> Unit, onFolders: () -> Unit, modifier: Modifier) {
    val c = LocalSkiv.current
    Column(modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.Center) {
        if (loading) {
            Text("Letar efter musik på telefonen…", fontSize = 18.sp, color = c.ink)
        } else {
            Text("Backen är tom", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = c.ink)
            Text(
                if (filtered) "Det finns inga FLAC- eller MP3-filer i mapparna du valt."
                else "Hittade inga FLAC- eller MP3-filer. Lägg musiken i telefonens Music-mapp och tryck Sök igen.",
                modifier = Modifier.padding(top = 8.dp, bottom = 16.dp), fontSize = 15.sp, color = c.inkSoft,
            )
            Button(
                onClick = if (filtered) onFolders else onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = c.ink, contentColor = c.panel),
            ) {
                Text(if (filtered) "Välj mappar" else "Sök igen", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun MiniPlayer(vm: MainViewModel) {
    val c = LocalSkiv.current
    val a = vm.currentAlbum ?: return
    val t = vm.currentTrack ?: return
    Column(Modifier.fillMaxWidth().background(c.panel)) {
        val frac = if (vm.durationMs > 0) (vm.positionMs.toFloat() / vm.durationMs).coerceIn(0f, 1f) else 0f
        Box(Modifier.fillMaxWidth().height(2.dp).background(c.line)) {
            Box(Modifier.fillMaxWidth(frac).height(2.dp).background(c.sticker))
        }
        Row(
            Modifier.fillMaxWidth().clickable { vm.screen = Screen.Playing }.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(3.dp))) { AlbumArt(a, Modifier.fillMaxSize(), 44.dp, showText = false) }
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(t.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = c.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${t.artist} · ${a.title}", fontSize = 12.5.sp, color = c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            PressButton(onClick = { vm.toggle() }, size = 44.dp) {
                Glyph(if (vm.isPlaying) Ic.Pause else Ic.Play, c.ink, Modifier.size(24.dp))
            }
        }
    }
}
