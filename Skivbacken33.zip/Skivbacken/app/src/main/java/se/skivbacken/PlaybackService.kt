package se.skivbacken

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlaybackException
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaLibraryService.LibraryParams
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaConstants
import androidx.media3.session.MediaSession
import android.os.Bundle
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import java.util.concurrent.Executors

/** Audio format of the last track the player could not decode; read by the app's error message. */
object LastError {
    @Volatile var format: String? = null
}

/**
 * Plays the music with the screen off, shows lock-screen controls, and lets
 * Android Auto browse albums → tracks.
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaLibraryService() {
    private var session: MediaLibrarySession? = null
    private val io = MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor())

    private val lock = Any()
    private var loaded = false
    private var albums: List<Album> = emptyList()
    private var albumById: Map<String, Album> = emptyMap()
    private var artists: List<Pair<String, List<Album>>> = emptyList()
    private var artistById: Map<String, Pair<String, List<Album>>> = emptyMap()
    private var trackById: Map<String, Pair<Album, Track>> = emptyMap()

    override fun onCreate() {
        super.onCreate()
        // Taps the decoded audio for the spectrum bars on the player screen.
        val renderers = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean,
            ): AudioSink = DefaultAudioSink.Builder(context)
                .setAudioProcessors(arrayOf<AudioProcessor>(TeeAudioProcessor(Spectrum)))
                .build()
        }
        // The phone's own decoders first; FFmpeg only for formats it can't play, such as ALAC.
        renderers.setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        val player = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true,
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val f = (error as? ExoPlaybackException)
                    ?.takeIf { it.type == ExoPlaybackException.TYPE_RENDERER }?.rendererFormat
                LastError.format = f?.sampleMimeType ?: f?.containerMimeType
            }
        })
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        session = MediaLibrarySession.Builder(this, player, Callback()).setSessionActivity(open).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.run {
            player.release()
            release()
        }
        session = null
        io.shutdown()
        super.onDestroy()
    }

    // ---------- library for Android Auto ----------

    private fun albumId(a: Album) = "album:${a.albumId}:${a.key.hashCode()}"

    private fun ensureLoaded(force: Boolean = false) = synchronized(lock) {
        if (loaded && !force) return@synchronized
        val prefs = getSharedPreferences("skivbacken", Context.MODE_PRIVATE)
        val chosen = prefs.getStringSet("folders", null)?.toSet() ?: emptySet()
        val hidden = prefs.getStringSet("hidden", null)?.toSet() ?: emptySet()
        val list = runCatching { filterFolders(LibraryRepo.load(this), chosen).filterNot { it.key in hidden } }
            .getOrDefault(emptyList())
        albums = list
        albumById = list.associateBy { albumId(it) }
        val coll = java.text.Collator.getInstance(java.util.Locale.forLanguageTag("sv-SE")).apply { strength = java.text.Collator.PRIMARY }
        artists = list.groupBy { it.artist }.toList()
            .sortedWith { x, y -> coll.compare(sortName(x.first), sortName(y.first)) }
            .map { (name, al) -> name to al.sortedBy { it.year } }
        artistById = artists.associateBy { artistId(it.first) }
        trackById = buildMap { list.forEach { a -> a.tracks.forEach { t -> put(t.id.toString(), a to t) } } }
        loaded = true
    }

    /** A plain root that can't fail, for when building the real menu does. */
    private val plainRoot: MediaItem = MediaItem.Builder()
        .setMediaId(ROOT)
        .setMediaMetadata(MediaMetadata.Builder().setTitle("Skivbacken").setIsBrowsable(true).setIsPlayable(false).build())
        .build()

    /**
     * Runs one Android Auto request. If it fails, the error is saved (shown under Settings in the app)
     * and the car gets an empty answer instead of the app crashing and being hidden.
     */
    private fun <T> guard(what: String, block: () -> T): T? = try {
        block()
    } catch (t: Throwable) {
        runCatching {
            getSharedPreferences("skivbacken", Context.MODE_PRIVATE).edit()
                .putString("autoError", "Fel när bilen hämtade $what:\n" + t.stackTraceToString().take(1200))
                .apply()
        }
        null
    }

    private fun artistId(name: String) = "artist:" + Integer.toHexString(name.lowercase().hashCode())

    /** How Android Auto lays out the children of an item: covers in a grid or rows in a list. */
    private fun style(browsable: Int, playable: Int = MediaConstants.EXTRAS_VALUE_CONTENT_STYLE_LIST_ITEM) = Bundle().apply {
        putInt(MediaConstants.EXTRAS_KEY_CONTENT_STYLE_BROWSABLE, browsable)
        putInt(MediaConstants.EXTRAS_KEY_CONTENT_STYLE_PLAYABLE, playable)
    }

    private val rootItem: MediaItem = MediaItem.Builder()
        .setMediaId(ROOT)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle("Skivbacken")
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_MIXED)
                .setExtras(style(MediaConstants.EXTRAS_VALUE_CONTENT_STYLE_GRID_ITEM))
                .build()
        )
        .build()

    /** The tabs along the top in Android Auto. */
    private fun tab(id: String, title: String, type: Int, childStyle: Int): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setMediaType(type)
                .setExtras(style(childStyle))
                .build()
        )
        .build()

    private val tabs: List<MediaItem> by lazy {
        listOf(
            tab(TAB_ALBUMS, "Album", MediaMetadata.MEDIA_TYPE_FOLDER_ALBUMS, MediaConstants.EXTRAS_VALUE_CONTENT_STYLE_GRID_ITEM),
            tab(TAB_ARTISTS, "Artister", MediaMetadata.MEDIA_TYPE_FOLDER_ARTISTS, MediaConstants.EXTRAS_VALUE_CONTENT_STYLE_LIST_ITEM),
        )
    }

    private fun artistItem(name: String, al: List<Album>): MediaItem = MediaItem.Builder()
        .setMediaId(artistId(name))
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(name)
                .setSubtitle(if (al.size == 1) "1 album" else "${al.size} album")
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setMediaType(MediaMetadata.MEDIA_TYPE_ARTIST)
                .setArtworkUri(ArtFiles.uriFor(this, al.first()))
                .setExtras(style(MediaConstants.EXTRAS_VALUE_CONTENT_STYLE_GRID_ITEM))
                .build()
        )
        .build()

    private fun albumItem(a: Album): MediaItem = MediaItem.Builder()
        .setMediaId(albumId(a))
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(a.title)
                .setArtist(a.artist)
                .setAlbumTitle(a.title)
                .setAlbumArtist(a.artist)
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setSubtitle(listOfNotNull(a.artist, a.year.takeIf { it > 0 }?.toString()).joinToString(" · "))
                .setMediaType(MediaMetadata.MEDIA_TYPE_ALBUM)
                .setArtworkUri(ArtFiles.uriFor(this, a))
                .setExtras(style(MediaConstants.EXTRAS_VALUE_CONTENT_STYLE_LIST_ITEM))
                .build()
        )
        .build()

    private fun trackItem(a: Album, t: Track): MediaItem = MediaItem.Builder()
        .setMediaId(t.id.toString())
        .setUri(t.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(t.title)
                .setArtist(t.artist)
                .setAlbumTitle(a.title)
                .setAlbumArtist(a.artist)
                .setTrackNumber(t.no)
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                .setArtworkUri(ArtFiles.uriFor(this, a))
                .build()
        )
        .build()

    private inner class Callback : MediaLibrarySession.Callback {
        override fun onGetLibraryRoot(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<MediaItem>> = io.submit<LibraryResult<MediaItem>> {
            guard("menyn") {
                ensureLoaded(force = true)
                val out = LibraryParams.Builder()
                    .setExtras(style(MediaConstants.EXTRAS_VALUE_CONTENT_STYLE_GRID_ITEM))
                    .build()
                LibraryResult.ofItem(rootItem, out)
            } ?: LibraryResult.ofItem(plainRoot, null)
        }

        override fun onGetChildren(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> = io.submit<LibraryResult<ImmutableList<MediaItem>>> {
            guard("listan " + parentId) {
                ensureLoaded()
                val items: List<MediaItem> = when {
                    parentId == ROOT -> tabs
                    parentId == TAB_ALBUMS -> albums.map { albumItem(it) }
                    parentId == TAB_ARTISTS -> artists.map { (name, al) -> artistItem(name, al) }
                    artistById[parentId] != null -> artistById.getValue(parentId).second.map { albumItem(it) }
                    else -> albumById[parentId]?.let { a -> a.tracks.map { trackItem(a, it) } } ?: emptyList()
                }
                val from = (page.toLong() * pageSize).coerceIn(0L, items.size.toLong()).toInt()
                val to = (from.toLong() + pageSize).coerceIn(from.toLong(), items.size.toLong()).toInt()
                LibraryResult.ofItemList(ImmutableList.copyOf(items.subList(from, to)), params)
            } ?: LibraryResult.ofItemList(ImmutableList.of(), params)
        }

        override fun onGetItem(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            mediaId: String,
        ): ListenableFuture<LibraryResult<MediaItem>> = io.submit<LibraryResult<MediaItem>> {
            guard("objektet " + mediaId) {
                ensureLoaded()
                val item = when {
                    mediaId == ROOT -> rootItem
                    mediaId == TAB_ALBUMS || mediaId == TAB_ARTISTS -> tabs.first { it.mediaId == mediaId }
                    artistById[mediaId] != null -> artistById.getValue(mediaId).let { (n, al) -> artistItem(n, al) }
                    albumById[mediaId] != null -> albumItem(albumById.getValue(mediaId))
                    trackById[mediaId] != null -> trackById.getValue(mediaId).let { (a, t) -> trackItem(a, t) }
                    else -> null
                }
                if (item != null) LibraryResult.ofItem(item, null) else LibraryResult.ofError(LibraryResult.RESULT_ERROR_BAD_VALUE)
            } ?: LibraryResult.ofError(LibraryResult.RESULT_ERROR_UNKNOWN)
        }

        /** Items from Android Auto arrive without a file address; look them up. */
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> = io.submit<MutableList<MediaItem>> {
            ensureLoaded()
            mediaItems.mapNotNull { item ->
                if (item.localConfiguration != null) item
                else trackById[item.mediaId]?.let { (a, t) -> trackItem(a, t) }
            }.toMutableList()
        }

        /** Picking one track in the car queues the whole album from that track. */
        override fun onSetMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
            startIndex: Int,
            startPositionMs: Long,
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            val single = mediaItems.singleOrNull()
            if (single != null && single.localConfiguration == null) {
                return io.submit<MediaSession.MediaItemsWithStartPosition> {
                    ensureLoaded()
                    val hit = trackById[single.mediaId]
                    if (hit == null) {
                        MediaSession.MediaItemsWithStartPosition(emptyList(), 0, C.TIME_UNSET)
                    } else {
                        val (a, t) = hit
                        MediaSession.MediaItemsWithStartPosition(
                            a.tracks.map { trackItem(a, it) },
                            a.tracks.indexOf(t).coerceAtLeast(0),
                            C.TIME_UNSET,
                        )
                    }
                }
            }
            return Futures.transform(
                onAddMediaItems(mediaSession, controller, mediaItems),
                { items -> MediaSession.MediaItemsWithStartPosition(items, startIndex, startPositionMs) },
                MoreExecutors.directExecutor(),
            )
        }
    }

    private companion object {
        const val ROOT = "root"
        const val TAB_ALBUMS = "albums"
        const val TAB_ARTISTS = "artists"
    }
}
