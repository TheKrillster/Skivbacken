package se.skivbacken.ui

import android.content.Context
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.runtime.produceState
import se.skivbacken.Lyrics
import se.skivbacken.Track
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import se.skivbacken.Album
import se.skivbacken.MainViewModel
import se.skivbacken.Spectrum

/**
 * Full-screen player. The library is hidden while this is shown.
 * Disc, display and the Spår / Kö / Text tabs scroll; a slim bar with the buttons stays at the bottom.
 */
@Composable
fun PlayingScreen(vm: MainViewModel, onBack: () -> Unit) {
    val c = LocalSkiv.current
    val album = vm.currentAlbum
    val track = vm.currentTrack
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().background(c.panel).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            PressButton(onClick = onBack, size = 48.dp) { Glyph(Ic.Down, c.ink, Modifier.size(26.dp)) }
            Text("Till backen", fontSize = 14.sp, color = c.inkSoft, modifier = Modifier.weight(1f))
            if (album != null) {
                Text(
                    album.title, modifier = Modifier.padding(end = 12.dp).weight(1f), fontSize = 13.sp, color = c.inkSoft,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }

        if (album == null || track == null) {
            Text("Ingen skiva i spelaren", modifier = Modifier.padding(24.dp), fontSize = 18.sp, color = c.ink)
            return@Column
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            BoxWithConstraints(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                val dim = minOf(maxWidth - 64.dp, 320.dp)
                CdStage(album, vm.isPlaying, dim)
            }
            Vfd(
                trackNo = vm.currentTrackIndex + 1,
                total = album.tracks.size,
                posMs = vm.positionMs,
                durationMs = vm.durationMs,
                playing = vm.isPlaying,
                format = album.format,
                album = album,
            )
            Tabs(
                listOf("Spår", if (vm.queue.isEmpty()) "Kö" else "Kö · ${vm.queue.size}", "Text"),
                tab, onPick = { tab = it },
                modifier = Modifier.padding(horizontal = 16.dp).padding(top = 18.dp, bottom = 4.dp),
            )
            when (tab) {
                0 -> album.tracks.forEachIndexed { i, t ->
                    val now = i == vm.currentTrackIndex
                    TrackRow(
                        no = if (t.no > 0) t.no else i + 1,
                        title = t.title,
                        subtitle = t.artist.takeIf { it != album.artist },
                        durationMs = t.durationMs,
                        playing = now,
                        onClick = { vm.jumpTo(album, i) },
                        progress = if (now && vm.durationMs > 0) vm.positionMs.toFloat() / vm.durationMs else null,
                        menu = { dismiss -> QueueMenuItems(vm, album, i, dismiss) },
                    )
                }
                1 -> QueueList(vm)
                else -> LyricsView(album, track, vm.positionMs)
            }
            Spacer(Modifier.height(16.dp))
        }

        // Always visible, kept slim so the display above stays in view.
        Column(
            Modifier
                .fillMaxWidth()
                .shadow(10.dp)
                .background(c.panel)
                .navigationBarsPadding()
                .padding(top = 8.dp),
        ) {
            Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.Bottom) {
                Text(
                    track.title, modifier = Modifier.weight(1f, fill = false), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold,
                    color = c.ink, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "  ·  ${track.artist}", modifier = Modifier.weight(1f, fill = false), fontSize = 13.sp, color = c.inkSoft,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            SeekBar(
                positionMs = vm.positionMs,
                durationMs = vm.durationMs,
                onSeek = { vm.seek(it) },
                modifier = Modifier.padding(horizontal = 20.dp).padding(top = 2.dp),
            )
            Controls(vm, Modifier.padding(horizontal = 12.dp).padding(bottom = 4.dp))
        }
    }
}

@Composable
private fun Tabs(labels: List<String>, selected: Int, onPick: (Int) -> Unit, modifier: Modifier) {
    val c = LocalSkiv.current
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        labels.forEachIndexed { i, label ->
            val on = i == selected
            Text(
                label,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (on) c.ink else c.chip)
                    .clickable { onPick(i) }
                    .padding(horizontal = 14.dp, vertical = 7.dp),
                fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, color = if (on) c.panel else c.ink,
            )
        }
    }
}

/** What will play, in order. Tap to jump there, × to take it out. */
@Composable
private fun QueueList(vm: MainViewModel) {
    val c = LocalSkiv.current
    if (vm.queue.isEmpty()) {
        Text("Kön är tom.", modifier = Modifier.padding(16.dp), fontSize = 15.sp, color = c.inkSoft)
        return
    }
    Text(
        "Håll fingret på en låt i en skiva för att lägga den här.",
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp), fontSize = 12.5.sp, color = c.inkSoft,
    )
    vm.queue.forEach { q ->
        val now = q.index == vm.queueIndex
        val past = q.index < vm.queueIndex
        Column {
            Row(
                Modifier.fillMaxWidth().clickable { vm.jumpToQueue(q.index) }.padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    if (now) "▶" else "%02d".format(q.index + 1), modifier = Modifier.width(36.dp),
                    fontSize = 12.sp, color = if (now) c.sticker else c.inkSoft,
                )
                Column(Modifier.weight(1f)) {
                    Text(
                        q.title, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = when { now -> c.sticker; past -> c.inkSoft; else -> c.ink },
                        fontWeight = if (now) FontWeight.SemiBold else FontWeight.Normal,
                    )
                    Text(q.artist, fontSize = 12.5.sp, color = c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (!now) {
                    PressButton(onClick = { vm.removeFromQueue(q.index) }, size = 40.dp) {
                        Glyph(Ic.Close, c.inkSoft, Modifier.size(18.dp))
                    }
                } else {
                    Spacer(Modifier.size(40.dp))
                }
            }
            Box(Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(1.dp).background(c.line))
        }
    }
}

/** Lyrics from LRCLIB. Synced lyrics light up the line being sung and keep it in view. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LyricsView(album: Album, track: Track, posMs: Long) {
    val c = LocalSkiv.current
    val ctx = LocalContext.current
    var attempt by remember(track.id) { mutableIntStateOf(0) }
    val state by produceState<Lyrics.State>(Lyrics.State.Loading, track.id, attempt) {
        value = Lyrics.State.Loading
        value = Lyrics.get(ctx, album, track)
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        when (val s = state) {
            Lyrics.State.Loading -> Text("Hämtar texten…", fontSize = 15.sp, color = c.inkSoft)
            Lyrics.State.NotFound -> Text("Hittade ingen text till den här låten.", fontSize = 15.sp, color = c.inkSoft)
            Lyrics.State.Instrumental -> Text("Instrumental", fontSize = 15.sp, color = c.inkSoft)
            Lyrics.State.Offline -> {
                Text("Kunde inte hämta texten. Kontrollera internetanslutningen.", fontSize = 15.sp, color = c.inkSoft)
                Text(
                    "Försök igen",
                    modifier = Modifier.padding(top = 10.dp).clip(RoundedCornerShape(50)).background(c.chip)
                        .clickable { attempt++ }.padding(horizontal = 14.dp, vertical = 7.dp),
                    fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, color = c.ink,
                )
            }
            is Lyrics.State.Found -> {
                if (s.synced.isNotEmpty()) {
                    val current = s.synced.indexOfLast { it.timeMs <= posMs + 300 }
                    val requesters = remember(s) { List(s.synced.size) { BringIntoViewRequester() } }
                    LaunchedEffect(current) {
                        if (current >= 0) requesters[current].bringIntoView()
                    }
                    s.synced.forEachIndexed { i, line ->
                        Text(
                            line.text.ifEmpty { "♪" },
                            modifier = Modifier.bringIntoViewRequester(requesters[i]).padding(vertical = 5.dp),
                            fontSize = if (i == current) 19.sp else 17.sp,
                            fontWeight = if (i == current) FontWeight.ExtraBold else FontWeight.Medium,
                            color = when {
                                i == current -> c.sticker
                                i < current -> c.inkSoft
                                else -> c.ink
                            },
                        )
                    }
                } else {
                    Text(s.plain, fontSize = 16.sp, lineHeight = 24.sp, color = c.ink)
                }
                Text("Text från LRCLIB", modifier = Modifier.padding(top = 14.dp), fontSize = 11.sp, color = c.inkSoft)
            }
        }
    }
}

/**
 * The disc (or the sleeve) standing on a glossy deck, with its reflection fading into the surface.
 * Tap it to flip between the spinning disc and the album cover.
 */
@Composable
private fun CdStage(album: Album, playing: Boolean, dim: Dp) {
    val c = LocalSkiv.current
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("skivbacken", Context.MODE_PRIVATE) }
    var showCover by remember { mutableStateOf(prefs.getBoolean("showCover", false)) }
    val flip by animateFloatAsState(if (showCover) 180f else 0f, tween(550), label = "flip")
    val angle = rememberSpin(playing)

    @Composable
    fun Face(modifier: Modifier) {
        Box(modifier.graphicsLayer { rotationY = flip; cameraDistance = 16f * density }) {
            if (flip <= 90f) {
                CdFace(album, angle, Modifier.fillMaxSize().shadow(20.dp, CircleShape))
            } else {
                val shape = RoundedCornerShape(3.dp)
                AlbumArt(
                    album,
                    Modifier.fillMaxSize().graphicsLayer { rotationY = 180f }.shadow(20.dp, shape).clip(shape),
                    dim,
                )
            }
        }
    }

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Face(
            Modifier
                .size(dim)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                    showCover = !showCover
                    prefs.edit().putBoolean("showCover", showCover).apply()
                },
        )
        Box(
            Modifier
                .fillMaxWidth()
                .height(dim * 0.42f)
                .background(Brush.verticalGradient(listOf(c.deckShine, c.deck, c.panel)))
                .drawBehind {
                    drawLine(Color.White.copy(alpha = 0.28f), Offset(0f, 0f), Offset(size.width, 0f), 1.5.dp.toPx())
                    drawRect(
                        Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.07f), Color.Transparent)),
                        size = Size(size.width, size.height * 0.5f),
                    )
                }
                .clipToBounds(),
            contentAlignment = Alignment.TopCenter,
        ) {
            Face(
                Modifier
                    .padding(top = 3.dp)
                    .wrapContentHeight(Alignment.Top, unbounded = true)
                    .size(dim)
                    .graphicsLayer {
                        scaleY = -1f
                        alpha = 0.42f
                        compositingStrategy = CompositingStrategy.Offscreen
                    }
                    .drawWithContent {
                        drawContent()
                        drawRect(
                            Brush.verticalGradient(0f to Color.Transparent, 0.58f to Color.Transparent, 1f to Color.Black),
                            blendMode = BlendMode.DstIn,
                        )
                    },
            )
        }
        Text(
            if (showCover) "Tryck för att visa skivan" else "Tryck för att visa omslaget",
            modifier = Modifier.padding(top = 2.dp, bottom = 6.dp), fontSize = 12.sp, color = c.inkSoft,
        )
    }
}

/** Spins up when playing and coasts to a stop on pause, like a real drive. */
@Composable
private fun rememberSpin(playing: Boolean): Float {
    val playingState = rememberUpdatedState(playing)
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        var speed = 0f
        while (true) {
            if (!playingState.value && speed < 0.5f) {
                speed = 0f
                last = 0L
                snapshotFlow { playingState.value }.first { it }
            }
            withFrameNanos { now ->
                if (last != 0L) {
                    val dt = ((now - last) / 1e9f).coerceAtMost(0.1f)
                    val target = if (playingState.value) 240f else 0f
                    speed += (target - speed) * (dt * 2.2f).coerceAtMost(1f)
                    angle = (angle + speed * dt) % 360f
                }
                last = now
            }
        }
    }
    return angle
}

@Composable
private fun CdFace(album: Album, angle: Float, modifier: Modifier) {
    val disc = rememberDiscImage(album)
    val cover = rememberCover(album)
    BoxWithConstraints(modifier.clip(CircleShape).background(Color(0xFFD9DCDF)), contentAlignment = Alignment.Center) {
        val dim = maxWidth
        // The printed face turns; the light on the plastic stays put.
        Box(Modifier.fillMaxSize().padding(dim * 0.012f).graphicsLayer { rotationZ = angle }.clip(CircleShape)) {
            val img = disc ?: cover
            if (img != null) {
                Image(img, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                GenArt(album, dim, showText = false)
            }
            if (disc == null) {
                Text(
                    album.title.uppercase(),
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = dim * 0.1f),
                    color = Color.White.copy(alpha = 0.85f), fontSize = (dim.value * 0.045f).sp,
                    letterSpacing = 0.2.em, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            val ctr = center
            drawCircle(
                Brush.sweepGradient(
                    listOf(
                        Color.Transparent, Color(0x3300E5FF), Color.Transparent, Color(0x2EFF4FD8),
                        Color.Transparent, Color(0x2EFFE14F), Color.Transparent, Color(0x3300E5FF), Color.Transparent,
                    ),
                    ctr,
                ),
                r, ctr,
            )
            drawCircle(Color.White.copy(alpha = 0.30f), r * 0.25f, ctr)
            drawCircle(Color(0xCCE6E9EC), r * 0.17f, ctr)
            drawCircle(Color.White.copy(alpha = 0.55f), r * 0.17f, ctr, style = Stroke(1.dp.toPx()))
            drawCircle(Color(0xFF2A2E2B), r * 0.075f, ctr)
            drawCircle(Color.White.copy(alpha = 0.4f), r - 1.dp.toPx(), ctr, style = Stroke(1.5.dp.toPx()))
        }
    }
}

/** Fluorescent display like a CD deck's: track, time and Winamp-style spectrum bars. */
@Composable
private fun Vfd(trackNo: Int, total: Int, posMs: Long, durationMs: Long, playing: Boolean, format: String, album: Album) {
    val c = LocalSkiv.current
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("skivbacken", Context.MODE_PRIVATE) }
    // Tap the time to switch between elapsed and remaining, like the TIME button on a CD deck.
    var remaining by remember { mutableStateOf(prefs.getBoolean("timeRemaining", false)) }
    val left = (durationMs - posMs).coerceAtLeast(0L)
    val spec = if (format == "FLAC") rememberSpec(album.tracks.first()) else null
    Column(
        Modifier
            .padding(horizontal = 16.dp)
            .padding(top = 4.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(c.vfdBg)
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f)) {
                Text("TRACK", fontFamily = AppFont, fontSize = 10.sp, letterSpacing = 0.15.em, color = c.vfdInk.copy(alpha = 0.6f))
                Text("%02d / %02d".format(trackNo, total), fontFamily = AppFont, fontSize = 20.sp, color = c.vfdInk)
            }
            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .clickable {
                        remaining = !remaining
                        prefs.edit().putBoolean("timeRemaining", remaining).apply()
                    }
                    .padding(horizontal = 4.dp, vertical = 2.dp),
            ) {
                Text(
                    (if (playing) "▶ PLAY" else "❚❚ PAUS") + if (remaining) " · KVAR" else " · TID",
                    fontFamily = AppFont, fontSize = 10.sp, letterSpacing = 0.15.em, color = c.vfdInk.copy(alpha = 0.6f),
                )
                Text(
                    if (remaining) "-" + fmtTime(left).padStart(5, '0') else fmtTime(posMs).padStart(5, '0'),
                    fontFamily = AppFont, fontSize = 30.sp, fontWeight = FontWeight.Medium, color = c.vfdInk,
                )
            }
        }
        Analyzer(Modifier.fillMaxWidth().height(64.dp).padding(top = 10.dp))
        Text(
            if (format == "FLAC" && spec != null && spec.known) "FLAC  ${spec.long}" else format,
            modifier = Modifier.padding(top = 8.dp),
            fontFamily = AppFont, fontSize = 10.sp, letterSpacing = 0.12.em, color = c.vfdInk.copy(alpha = 0.6f),
        )
    }
}

/** Colour sets for the spectrum bars, bottom to top. Tap the bars to switch. */
private class BarTheme(val name: String, val low: Color, val mid: Color, val high: Color, val peak: Color)

private val BarThemes = listOf(
    BarTheme("WINAMP", Color(0xFF3BD14B), Color(0xFFE6D63A), Color(0xFFE5452C), Color(0xFFC9CED1)),
    BarTheme("TURKOS", Color(0xFF2E9E90), Color(0xFF7FE0CF), Color(0xFFD8FFF6), Color(0xFFFFFFFF)),
    BarTheme("NEON", Color(0xFF6A5CFF), Color(0xFFE040FB), Color(0xFFFF4F9A), Color(0xFFFFE1F5)),
    BarTheme("SOLNEDGÅNG", Color(0xFFC2185B), Color(0xFFFF6D3A), Color(0xFFFFD54F), Color(0xFFFFF3D6)),
    BarTheme("IS", Color(0xFF2D6CDF), Color(0xFF5FB4FF), Color(0xFFE3F4FF), Color(0xFFFFFFFF)),
    BarTheme("BÄRNSTEN", Color(0xFFB86E12), Color(0xFFFFB238), Color(0xFFFFD27A), Color(0xFFFFE9BF)),
)

@Composable
private fun Analyzer(modifier: Modifier) {
    val c = LocalSkiv.current
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("skivbacken", Context.MODE_PRIVATE) }
    var themeIndex by remember { mutableIntStateOf(prefs.getInt("barTheme", 0).coerceIn(0, BarThemes.size - 1)) }
    var showName by remember { mutableStateOf(false) }
    val nameAlpha by animateFloatAsState(if (showName) 1f else 0f, tween(250), label = "themeName")
    LaunchedEffect(themeIndex, showName) {
        if (showName) {
            delay(1300)
            showName = false
        }
    }
    val theme = BarThemes[themeIndex]

    val n = Spectrum.BANDS
    val heights = remember { FloatArray(n) }
    val peaks = remember { FloatArray(n) }
    val hold = remember { FloatArray(n) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1e9f).coerceAtMost(0.1f)
                last = now
                val fresh = System.nanoTime() - Spectrum.updatedAt < 250_000_000L
                for (i in 0 until n) {
                    val target = if (fresh) Spectrum.levels[i] else 0f
                    heights[i] = if (target > heights[i]) target else maxOf(target, heights[i] - dt * 1.6f)
                    if (heights[i] >= peaks[i]) {
                        peaks[i] = heights[i]
                        hold[i] = 0.4f
                    } else {
                        hold[i] -= dt
                        if (hold[i] <= 0f) peaks[i] = maxOf(heights[i], peaks[i] - dt * 0.8f)
                    }
                }
                tick++
            }
        }
    }
    Box(
        modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
            themeIndex = (themeIndex + 1) % BarThemes.size
            prefs.edit().putInt("barTheme", themeIndex).apply()
            showName = true
        },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            @Suppress("UNUSED_VARIABLE") val frame = tick
            val gap = 2.dp.toPx()
            val barW = (size.width - gap * (n - 1)) / n
            val seg = 3.dp.toPx()
            val segGap = 1.dp.toPx()
            val segs = (size.height / (seg + segGap)).toInt().coerceAtLeast(1)
            for (i in 0 until n) {
                val x = i * (barW + gap)
                val lit = (heights[i] * segs).toInt()
                for (s in 0 until segs) {
                    val y = size.height - (s + 1) * (seg + segGap) + segGap
                    val f = s.toFloat() / segs
                    val col = when {
                        f > 0.8f -> theme.high
                        f > 0.55f -> theme.mid
                        else -> theme.low
                    }
                    drawRect(if (s < lit) col else col.copy(alpha = 0.08f), Offset(x, y), Size(barW, seg))
                }
                if (peaks[i] > 0.02f) {
                    val py = size.height - peaks[i] * size.height
                    drawRect(theme.peak, Offset(x, py.coerceAtLeast(0f)), Size(barW, 2.dp.toPx()))
                }
            }
        }
        if (nameAlpha > 0f) {
            Text(
                theme.name,
                modifier = Modifier
                    .align(Alignment.Center)
                    .graphicsLayer { alpha = nameAlpha }
                    .clip(RoundedCornerShape(4.dp))
                    .background(c.vfdBg.copy(alpha = 0.85f))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                fontFamily = AppFont, fontSize = 13.sp, letterSpacing = 0.2.em, color = theme.mid,
            )
        }
    }
}

/** Thin timeline: tap or drag anywhere on it; the knob shows while you touch it. */
@Composable
private fun SeekBar(positionMs: Long, durationMs: Long, onSeek: (Long) -> Unit, modifier: Modifier) {
    val c = LocalSkiv.current
    var drag by remember { mutableStateOf<Float?>(null) }
    val dur = durationMs.coerceAtLeast(1L)
    val frac = drag ?: (positionMs.toFloat() / dur).coerceIn(0f, 1f)
    Column(modifier.fillMaxWidth()) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(22.dp)
                .pointerInput(dur) {
                    detectTapGestures { o -> onSeek(((o.x / size.width).coerceIn(0f, 1f) * dur).toLong()) }
                }
                .pointerInput(dur) {
                    detectHorizontalDragGestures(
                        onDragStart = { o -> drag = (o.x / size.width).coerceIn(0f, 1f) },
                        onDragEnd = { drag?.let { onSeek((it * dur).toLong()) }; drag = null },
                        onDragCancel = { drag = null },
                    ) { change, _ ->
                        change.consume()
                        drag = (change.position.x / size.width).coerceIn(0f, 1f)
                    }
                },
        ) {
            val h = if (drag != null) 6.dp.toPx() else 4.dp.toPx()
            val y = size.height / 2f - h / 2f
            drawRoundRect(c.line, Offset(0f, y), Size(size.width, h), CornerRadius(h))
            drawRoundRect(if (drag != null) c.sticker else c.ink, Offset(0f, y), Size(size.width * frac, h), CornerRadius(h))
            if (drag != null) drawCircle(c.sticker, 8.dp.toPx(), Offset(size.width * frac, size.height / 2f))
        }
        Row(Modifier.fillMaxWidth()) {
            Text(fmtTime((frac * dur).toLong()), fontFamily = AppFont, fontSize = 11.sp, color = c.inkSoft, modifier = Modifier.weight(1f))
            Text(fmtTime(durationMs), fontFamily = AppFont, fontSize = 11.sp, color = c.inkSoft)
        }
    }
}

/** Shuffle · previous · big play/pause · next · repeat. */
@Composable
private fun Controls(vm: MainViewModel, modifier: Modifier) {
    val c = LocalSkiv.current
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        ToggleButton(on = vm.shuffle, onClick = { vm.toggleShuffle() }) { tint -> Glyph(Ic.Shuffle, tint, Modifier.size(22.dp)) }
        PressButton(onClick = { vm.prev() }, size = 50.dp) { Glyph(Ic.Prev, c.ink, Modifier.size(26.dp)) }
        PressButton(onClick = { vm.toggle() }, size = 58.dp, background = c.sticker, modifier = Modifier.shadow(8.dp, CircleShape)) {
            Crossfade(vm.isPlaying, label = "playpause") { playing ->
                Glyph(if (playing) Ic.Pause else Ic.Play, c.stickerInk, Modifier.size(28.dp))
            }
        }
        PressButton(onClick = { vm.next() }, size = 50.dp) { Glyph(Ic.Next, c.ink, Modifier.size(26.dp)) }
        ToggleButton(on = vm.repeatMode != Player.REPEAT_MODE_OFF, onClick = { vm.cycleRepeat() }) { tint ->
            Glyph(if (vm.repeatMode == Player.REPEAT_MODE_ONE) Ic.RepeatOne else Ic.Repeat, tint, Modifier.size(22.dp))
        }
    }
}

@Composable
private fun ToggleButton(on: Boolean, onClick: () -> Unit, icon: @Composable (Color) -> Unit) {
    val c = LocalSkiv.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        PressButton(onClick = onClick, size = 42.dp) { icon(if (on) c.sticker else c.inkSoft) }
        Box(Modifier.size(4.dp).clip(CircleShape).background(if (on) c.sticker else Color.Transparent))
    }
}
