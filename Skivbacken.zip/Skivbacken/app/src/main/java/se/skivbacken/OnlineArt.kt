package se.skivbacken

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Covers and disc images from MusicBrainz + Cover Art Archive.
 * Free, no account. "Front" is the sleeve, "Medium" is a photo of the disc itself.
 * Results are stored in the app's own folder, so each album is looked up once.
 */
object OnlineArt {
    private const val UA = "Skivbacken/1.0 ( https://github.com/TheKrillster/Skivbacken )"
    private val mbLock = Mutex()
    private var lastMbCall = 0L

    data class Result(val front: File?, val disc: File?)

    private fun dir(ctx: Context) = File(ctx.filesDir, "art").apply { mkdirs() }
    fun base(album: Album) = Integer.toHexString(album.key.hashCode()) + "-" + album.key.length
    fun frontFile(ctx: Context, album: Album) = File(dir(ctx), "${base(album)}-front.jpg")
    fun discFile(ctx: Context, album: Album) = File(dir(ctx), "${base(album)}-disc.jpg")
    private fun missFile(ctx: Context, album: Album) = File(dir(ctx), "${base(album)}.none")
    /** A cover the user picked by hand; it wins over everything else. */
    fun customFile(ctx: Context, album: Album) = File(dir(ctx), "${base(album)}-custom.jpg")

    /** Forgets every stored picture for the album, so it is looked up again. */
    fun reset(ctx: Context, album: Album) {
        listOf(frontFile(ctx, album), discFile(ctx, album), missFile(ctx, album), customFile(ctx, album)).forEach {
            ArtCache.forget(it)
            it.delete()
        }
        ArtVersion.bump()
    }

    fun clearCustom(ctx: Context, album: Album) {
        val f = customFile(ctx, album)
        ArtCache.forget(f)
        f.delete()
        ArtVersion.bump()
    }

    data class CoverHit(val thumbUrl: String, val fullUrl: String, val title: String, val artist: String, val source: String)

    /** Free-text cover search in iTunes and Cover Art Archive. */
    suspend fun searchCovers(query: String): List<CoverHit> = withContext(Dispatchers.IO) {
        val hits = mutableListOf<CoverHit>()
        val q = URLEncoder.encode(query.trim(), "UTF-8")
        runCatching {
            val json = httpGet("https://itunes.apple.com/search?term=$q&entity=album&limit=24") ?: return@runCatching
            val arr = JSONObject(json).optJSONArray("results") ?: return@runCatching
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val art = o.optString("artworkUrl100").takeIf { it.isNotEmpty() } ?: continue
                hits += CoverHit(
                    art.replace("100x100bb", "300x300bb"), art.replace("100x100bb", "600x600bb"),
                    o.optString("collectionName"), o.optString("artistName"), "iTunes",
                )
            }
        }
        runCatching {
            val url = "https://musicbrainz.org/ws/2/release/?fmt=json&limit=12&query=$q"
            val json = mbLock.withLock {
                val wait = 1100 - (System.currentTimeMillis() - lastMbCall)
                if (wait > 0) delay(wait)
                lastMbCall = System.currentTimeMillis()
                httpGet(url)
            } ?: return@runCatching
            val arr = JSONObject(json).optJSONArray("releases") ?: return@runCatching
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("id").takeIf { it.isNotEmpty() } ?: continue
                val artist = o.optJSONArray("artist-credit")?.optJSONObject(0)?.optString("name") ?: ""
                hits += CoverHit(
                    "https://coverartarchive.org/release/$id/front-250", "https://coverartarchive.org/release/$id/front-500",
                    o.optString("title"), artist, "Cover Art Archive",
                )
            }
        }
        hits.distinctBy { it.fullUrl }
    }

    /** Downloads the chosen picture and makes it the album's cover. */
    suspend fun saveCustom(ctx: Context, album: Album, url: String): Boolean = withContext(Dispatchers.IO) {
        val bytes = runCatching { fetchBytes(url) }.getOrNull() ?: return@withContext false
        val f = customFile(ctx, album)
        f.writeBytes(bytes)
        ArtCache.forget(f)
        ArtVersion.bump()
        true
    }

    /** GET that follows redirects (also between http and https), returning the body or null. */
    fun fetchBytes(url: String): ByteArray? {
        var current = url.replace("http://", "https://")
        repeat(6) {
            val c = open(current)
            try {
                c.instanceFollowRedirects = false
                val code = c.responseCode
                if (code in 301..308) {
                    current = URL(URL(current), c.getHeaderField("Location") ?: return null).toString().replace("http://", "https://")
                    return@repeat
                }
                return if (code == 200) c.inputStream.use { it.readBytes() } else null
            } finally {
                c.disconnect()
            }
        }
        return null
    }

    suspend fun get(ctx: Context, album: Album): Result = withContext(Dispatchers.IO) {
        val front = frontFile(ctx, album)
        val disc = discFile(ctx, album)
        val miss = missFile(ctx, album)
        // A miss is tried again after three days (earlier ones may have been a busy MusicBrainz).
        val recentMiss = miss.exists() && System.currentTimeMillis() - miss.lastModified() < 3 * 86_400_000L
        if (front.exists() || disc.exists() || recentMiss) {
            return@withContext Result(front.takeIf { it.exists() }, disc.takeIf { it.exists() })
        }
        try {
            val releases = findReleases(album)
            for (mbid in releases) {
                val json = httpGet("https://coverartarchive.org/release/$mbid") ?: continue
                val images = JSONObject(json).optJSONArray("images") ?: continue
                var frontUrl: String? = null
                var discUrl: String? = null
                for (i in 0 until images.length()) {
                    val img = images.getJSONObject(i)
                    val types = img.optJSONArray("types")
                    val typeList = (0 until (types?.length() ?: 0)).map { types!!.getString(it) }
                    val thumbs = img.optJSONObject("thumbnails")
                    val url = (thumbs?.optString("500")?.takeIf { it.isNotEmpty() }
                        ?: thumbs?.optString("large")?.takeIf { it.isNotEmpty() }
                        ?: img.optString("image")).replace("http://", "https://")
                    if (url.isEmpty()) continue
                    if (frontUrl == null && (img.optBoolean("front") || "Front" in typeList)) frontUrl = url
                    if (discUrl == null && "Medium" in typeList) discUrl = url
                }
                frontUrl?.let { download(it, front) }
                discUrl?.let { download(it, disc) }
                if (front.exists()) break
            }
            if (!front.exists() && !disc.exists()) miss.createNewFile()
        } catch (e: Exception) {
            // Offline or the service is busy: try again next time the album is shown.
        }
        Result(front.takeIf { it.exists() }, disc.takeIf { it.exists() })
    }

    private suspend fun findReleases(album: Album): List<String> {
        fun clean(s: String) = s.replace("\"", " ").replace("\\", " ").trim()
        val q = "release:\"${clean(cleanTitle(album.title))}\" AND artist:\"${clean(album.artist)}\""
        val url = "https://musicbrainz.org/ws/2/release/?fmt=json&limit=5&query=" + URLEncoder.encode(q, "UTF-8")
        // Busy or offline is not "no cover": throw so the album isn't marked as having none.
        val (code, json) = mbGet(url)
        if (code != 200 || json == null) throw java.io.IOException("MusicBrainz $code")
        val arr = JSONObject(json).optJSONArray("releases") ?: return emptyList()
        return (0 until arr.length()).map { arr.getJSONObject(it) }
            .filter { it.optInt("score", 0) >= 85 }
            .take(3)
            .map { it.getString("id") }
    }

    private fun open(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 15_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Accept", "application/json")
        }

    private fun httpGet(url: String): String? {
        val c = open(url)
        return try {
            if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
        } finally {
            c.disconnect()
        }
    }

    private fun download(url: String, target: File) {
        var c = open(url)
        try {
            // Cover Art Archive redirects to archive.org; follow by hand in case the host changes.
            var hops = 0
            while (c.responseCode in 301..308 && hops++ < 5) {
                val next = c.getHeaderField("Location") ?: break
                c.disconnect()
                c = open(URL(URL(url), next).toString().replace("http://", "https://"))
            }
            if (c.responseCode != 200) return
            val tmp = File(target.path + ".part")
            c.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            tmp.renameTo(target)
        } finally {
            c.disconnect()
        }
    }

    data class Release(
        val label: String, val catNo: String, val date: String, val country: String,
        val format: String, val barcode: String, val status: String,
    )

    /** Outcome of a release lookup, so the app can say why nothing is shown. */
    sealed interface Lookup {
        data class Found(val release: Release) : Lookup
        data object NoMatch : Lookup
        data class Failed(val why: String) : Lookup
    }

    private fun infoFile(ctx: Context, album: Album) = File(File(ctx.filesDir, "info2").apply { mkdirs() }, base(album) + ".json")

    /** "Revolver (Remastered) (Stereo)" → "Revolver"; "Abbey Road [Deluxe Edition]" → "Abbey Road". */
    fun cleanTitle(t: String): String {
        var s = t.replace(Regex("\\s*[\\(\\[][^\\)\\]]*[\\)\\]]"), " ")
        s = s.replace(Regex("(?i)\\s*-\\s*(remaster(ed)?|deluxe|expanded|anniversary|bonus|special).*$"), "")
        s = s.replace(Regex("(?i)\\b(cd|disc|disk|skiva)\\s*\\d+\\b"), " ")
        return s.replace(Regex("\\s+"), " ").trim().ifEmpty { t.trim() }
    }

    /**
     * Label, catalogue number, release date and so on from MusicBrainz. A hit is kept for good;
     * a miss is tried again after three days, a network error the next time the page opens.
     */
    suspend fun release(ctx: Context, album: Album): Lookup = withContext(Dispatchers.IO) {
        val f = infoFile(ctx, album)
        val fresh = f.exists() && (f.readText() != "{}" || System.currentTimeMillis() - f.lastModified() < 3 * 86_400_000L)
        val json = if (fresh) f.readText() else {
            val title = cleanTitle(album.title)
            val artist = album.artist.replace(Regex("(?i)^the\\s+"), "")
            fun q(s: String) = s.replace("\"", " ").replace("\\", " ").trim()
            fun loose(s: String) = s.replace(Regex("[+\\-!(){}\\[\\]^\"~*?:\\\\/&|]"), " ").replace(Regex("\\s+"), " ").trim()
            val queries = listOf(
                "release:\"${q(title)}\" AND artist:\"${q(album.artist)}\"",
                "release:(${loose(title)}) AND artist:(${loose(artist)})",
            )
            var best: JSONObject? = null
            for (query in queries) {
                val url = "https://musicbrainz.org/ws/2/release/?fmt=json&limit=10&query=" + URLEncoder.encode(query, "UTF-8")
                val (code, body) = mbGet(url)
                if (code != 200 || body == null) {
                    return@withContext Lookup.Failed(
                        when (code) {
                            -1 -> "Ingen kontakt med MusicBrainz. Kontrollera nätet."
                            503 -> "MusicBrainz är upptaget just nu. Försök igen om en stund."
                            else -> "MusicBrainz svarade med fel $code."
                        },
                    )
                }
                val arr = JSONObject(body).optJSONArray("releases")
                best = (0 until (arr?.length() ?: 0)).map { arr!!.getJSONObject(it) }
                    .filter { it.optInt("score", 0) >= 70 }
                    // Prefer a release with as many tracks as the files, then the best score.
                    .maxByOrNull { r ->
                        val n = r.optJSONArray("media")?.let { m -> (0 until m.length()).sumOf { m.getJSONObject(it).optInt("track-count") } } ?: 0
                        (if (n == album.tracks.size) 100 else 0) + r.optInt("score", 0)
                    }
                if (best != null) break
            }
            (best?.toString() ?: "{}").also { f.writeText(it) }
        }
        val o = runCatching { JSONObject(json) }.getOrNull()
        if (o == null || !o.has("id")) return@withContext Lookup.NoMatch
        val li = o.optJSONArray("label-info")?.optJSONObject(0)
        val media = o.optJSONArray("media")
        val formats = (0 until (media?.length() ?: 0)).map { media!!.getJSONObject(it) }
            .groupBy { it.optString("format").ifBlank { "Okänt" } }
            .map { (fmt, list) -> if (list.size > 1) "${list.size} × $fmt" else fmt }
            .joinToString(", ")
        Lookup.Found(
            Release(
                label = li?.optJSONObject("label")?.optString("name").orEmpty(),
                catNo = li?.optString("catalog-number").orEmpty(),
                date = o.optString("date"),
                country = o.optString("country"),
                format = formats,
                barcode = o.optString("barcode"),
                status = o.optString("status"),
            ),
        )
    }

    /**
     * One MusicBrainz request, at most one every 1.2 seconds. When they answer "busy" (503) —
     * common on mobile networks, where many phones share one address — wait and try again,
     * up to four times with longer pauses. Returns (status, body); -1 when offline.
     */
    private suspend fun mbGet(url: String): Pair<Int, String?> {
        var pause = 2_000L
        var last: Pair<Int, String?> = -1 to null
        repeat(5) { attempt ->
            last = mbLock.withLock {
                val wait = 1200 - (System.currentTimeMillis() - lastMbCall)
                if (wait > 0) delay(wait)
                lastMbCall = System.currentTimeMillis()
                try {
                    val c = open(url)
                    try {
                        val code = c.responseCode
                        val retryAfter = c.getHeaderField("Retry-After")?.trim()?.toLongOrNull()
                        if (code == 503 && retryAfter != null) pause = maxOf(pause, retryAfter * 1000)
                        code to (if (code == 200) c.inputStream.bufferedReader().use { it.readText() } else null)
                    } finally {
                        c.disconnect()
                    }
                } catch (e: Exception) {
                    -1 to null
                }
            }
            if (last.first != 503 || attempt == 4) return last
            delay(pause)
            pause = (pause * 2).coerceAtMost(16_000L)
        }
        return last
    }

    /** Forget a stored lookup, so "Sök igen" asks MusicBrainz anew. */
    fun forgetRelease(ctx: Context, album: Album) { infoFile(ctx, album).delete() }
}
