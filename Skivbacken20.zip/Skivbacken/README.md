# Skivbacken

Musikspelare för Android (11 eller nyare) som spelar FLAC och MP3. Du bläddrar bland albumen som i en skivback.

- Skivbacken: dra nedåt för att bläddra, tryck på A–Ö för att hoppa, tryck på en skiva för att öppna den.
- När en skiva spelas döljs biblioteket och CD:n snurrar på en blank yta med spegling.
- Staplarna i displayen räknas fram ur ljudet och rör sig i takt med musiken.
- Saknas omslag i filen hämtas det från MusicBrainz / Cover Art Archive, liksom bild på själva skivan när en sådan finns. Bilderna sparas i appen och hämtas bara en gång. Appen skickar då artist- och albumnamn till musicbrainz.org.
- Musiken fortsätter med skärmen låst och kan styras från låsskärmen.

## Så installerar du den

1. Installera **Android Studio** (gratis) på en dator: https://developer.android.com/studio
2. Packa upp zip-filen. Välj **File › Open** i Android Studio och öppna mappen `Skivbacken`.
   Första gången laddar Android Studio ner det som behövs. Det tar några minuter.
3. Slå på USB-felsökning på telefonen:
   **Inställningar › Om telefonen**. Tryck sju gånger på **Build-nummer**. Gå sedan till
   **Inställningar › System › Utvecklaralternativ** och slå på **USB-felsökning**.
4. Koppla in telefonen med USB-kabel och godkänn datorn på telefonen.
5. Välj telefonen i listan högst upp i Android Studio och tryck på den gröna ▶-knappen (**Run**).

Om du hellre vill ha en installationsfil: **Build › Build App Bundle(s) / APK(s) › Build APK(s)**.
Filen hamnar i `app/build/outputs/apk/debug/app-debug.apk`. Skicka den till telefonen och öppna den.
Telefonen frågar då om den får installera appar från den källan.

## Musiken

Appen hittar alla FLAC- och MP3-filer som telefonen känner till, till exempel i mappen **Music**.
Har du lagt till musik och den inte syns, tryck på ↻ uppe till höger.
