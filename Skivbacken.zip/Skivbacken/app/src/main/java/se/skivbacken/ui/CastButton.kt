package se.skivbacken.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.mediarouter.media.MediaRouteSelector
import androidx.mediarouter.media.MediaRouter
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.framework.CastContext
import se.skivbacken.CastUi

/** Cast button: lights up in the accent colour while the music plays on a TV. */
@Composable
fun CastButton(size: Dp = 44.dp) {
    val c = LocalSkiv.current
    var open by remember { mutableStateOf(false) }
    val on = CastUi.device != null
    PressButton(onClick = { open = true }, size = size) {
        Glyph(Ic.Cast, if (on) c.sticker else c.ink, Modifier.size(size * 0.5f))
    }
    if (open) CastDialog(onClose = { open = false })
}

/** Lists the TVs and speakers with Chromecast on the home wifi. */
@Composable
private fun CastDialog(onClose: () -> Unit) {
    val c = LocalSkiv.current
    val ctx = LocalContext.current
    val router = remember { MediaRouter.getInstance(ctx) }
    val selector = remember {
        MediaRouteSelector.Builder()
            .addControlCategory(CastMediaControlIntent.categoryForCast(CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID))
            .build()
    }
    var routes by remember { mutableStateOf<List<MediaRouter.RouteInfo>>(emptyList()) }
    val castOk = remember { runCatching { CastContext.getSharedInstance(ctx) }.isSuccess }

    DisposableEffect(router) {
        fun refresh() {
            routes = router.routes.filter { !it.isDefault && it.isEnabled && it.matchesSelector(selector) }
        }
        val cb = object : MediaRouter.Callback() {
            override fun onRouteAdded(r: MediaRouter, route: MediaRouter.RouteInfo) = refresh()
            override fun onRouteRemoved(r: MediaRouter, route: MediaRouter.RouteInfo) = refresh()
            override fun onRouteChanged(r: MediaRouter, route: MediaRouter.RouteInfo) = refresh()
        }
        router.addCallback(selector, cb, MediaRouter.CALLBACK_FLAG_PERFORM_ACTIVE_SCAN)
        refresh()
        onDispose { router.removeCallback(cb) }
    }

    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .widthIn(min = 260.dp, max = 420.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(c.panel)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            val now = CastUi.device
            Text(if (now != null) "Spelar på $now" else "Spela på TV:n", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = c.ink)
            when {
                !castOk -> Text("Chromecast fungerar inte på den här enheten (Google Play-tjänster saknas).", fontSize = 14.sp, color = c.inkSoft)
                now != null -> {
                    Text("Telefonen styr musiken och måste vara på samma wifi så länge den spelar.", fontSize = 14.sp, color = c.inkSoft)
                    Row(
                        Modifier.padding(top = 8.dp).clip(RoundedCornerShape(50)).background(c.sticker)
                            .clickable { router.unselect(MediaRouter.UNSELECT_REASON_STOPPED); onClose() }
                            .padding(horizontal = 18.dp, vertical = 10.dp),
                    ) { Text("Spela i telefonen igen", color = c.stickerInk, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
                }
                routes.isEmpty() -> Text(
                    "Letar efter TV-apparater…\nTV:n måste vara på och ansluten till samma wifi som telefonen.",
                    fontSize = 14.sp, color = c.inkSoft,
                )
                else -> routes.forEach { r ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                            .clickable { r.select(); onClose() }
                            .padding(vertical = 10.dp, horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Glyph(Ic.Cast, c.ink, Modifier.size(22.dp))
                        Column(Modifier.padding(start = 12.dp)) {
                            Text(r.name, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = c.ink)
                            r.description?.takeIf { it.isNotBlank() }?.let { Text(it, fontSize = 12.sp, color = c.inkSoft) }
                        }
                    }
                }
            }
        }
    }
}
