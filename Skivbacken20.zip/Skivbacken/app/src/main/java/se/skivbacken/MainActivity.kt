package se.skivbacken

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import se.skivbacken.ui.SkivApp
import se.skivbacken.ui.SkivTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refreshPermission() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        se.skivbacken.ui.ThemePrefs.init(this)
        vm.connect()
        refreshPermission()
        setContent {
            SkivTheme {
                SkivApp(vm, onRequestPermission = { permLauncher.launch(permissions()) })
            }
        }
    }

    private fun permissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun refreshPermission() {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        val ok = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
        vm.hasPermission = ok
        if (ok && vm.albums.isEmpty() && !vm.loading) vm.load()
    }
}
