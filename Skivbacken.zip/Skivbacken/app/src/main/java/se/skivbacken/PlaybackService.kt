package se.skivbacken

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlaybackException
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaLibraryService.LibraryParams
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaConstants
import androidx.media3.session.MediaSession
import androidx.media3.session.CommandButton
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import android.os.Bundle
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import java.util.concurrent.Executors

/** Audio format of the last track the player could not decode; read by the app's error message. */
object LastError {
    @Volatile var format: String? = null
}

/**
 * Plays the music with the screen off, shows lock-screen controls, and lets
 * Android Auto browse albums → tracks.
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaLibraryService() {
    private var session: MediaLibrarySession? = null
    private val io = MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor())

    private val lock = Any()
    private var loaded = false
    private var albums: List<Album> = emptyList()
    private var albumById: Map<String, Album> = emptyMap()
    private var artists: List<Pair<String, List<Album>>> = emptyList()
    private var artistById: Map<String, Pair<String, List<Album>>> = emptyMap()
    private var trackById: Map<String, Pair<Album, Track>> = emptyMap()

    override fun onCreate() {
        super.onCreate()
        // Taps the decoded audio for the spectrum bars on the player screen.
        val renderers = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean,
            ): AudioSink = DefaultAudioSink.Builder(context)
                .setAudioProcessors(arrayOf<AudioProcessor>(TeeAudioProcessor(Spectrum)))
                .build()
        }
        // The phone's own decoders first; FFmpeg only for formats it can't play, such as ALAC.
        renderers.setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        val player = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true,
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val f = (error as? ExoPlaybackException)
                    ?.takeIf { it.type == ExoPlaybackException.TYPE_RENDERER }?.rendererFormat
                LastError.format = f?.sampleMimeType ?: f?.containerMimeType
            }

            override fun onEvents(p: Player, events: Player.Events) {
                if (events.containsAny(
                        Player.EVENT_MEDIA_ITEM_TRANSITION, Player.EVENT_IS_PLAYING_CHANGED,
                        Player.EVENT_MEDIA_METADATA_CHANGED, Player.EVENT_TIMELINE_CHANGED,
                    )
                ) {
                    Widgets.fromPlayer(this@PlaybackService, p)
                    saveResume(p)
                }
                if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION)) p.currentMediaItem?.mediaId?.let { remember(it) }
                if (events.containsAny(Player.EVENT_SHUFFLE_MODE_ENABLED_CHANGED, Player.EVENT_REPEAT_MODE_CHANGED)) {
                    session?.setCustomLayout(buttons(p))
                }
            }
        })
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        session = MediaLibrarySession.Builder(this, player, Callback()).setSessionActivity(open).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    /** Remembers the queue and position, so a widget or headphone press can carry on after a restart. */
    private fun saveResume(p: Player) {
        if (p.mediaItemCount == 0) return
        val ids = (0 until p.mediaItemCount).map { p.getMediaItemAt(it).mediaId }
        getSharedPreferences("skivbacken", Context.MODE_PRIVATE).edit()
            .putString("resume_ids", ids.joinToString(","))
            .putInt("resume_index", p.currentMediaItemIndex)
            .putLong("resume_pos", p.currentPosition.coerceAtLeast(0))
            .apply()
    }

    override fun onDestroy() {
        session?.player?.let { saveResume(it) }
        Widgets.stopped(this)
        session?.run {
            player.release()
            release()
        }
        session = null
        io.shutdown()
        super.onDestroy()
    }

    // ---------- library for Android Auto ----------

    private fun albumId(a: Album) = "album:${a.albumId}:${a.key.hashCode()}"

    private fun ensureLoaded(force: Boolean = false) = synchronized(lock) {
        if (loaded && !force) return@synchronized
        val prefs = getSharedPreferences("skivbacken", Context.MODE_PRIVATE)
        val chosen = prefs.getStringSet("folders", null)?.toSet() ?: emptySet()
        val hidden = prefs.getStringSet("hidden", null)?.toSet() ?: emptySet()
        val list = runCatching { filterFolders(LibraryRepo.load(this), chosen).filterNot { it.key in hidden } }
            .getOrDefault(emptyList())
        albums = list
        albumById = list.associateBy { albumId(it) }
        val coll = java.text.Collator.getInstance(java.util.Locale.forLanguageTag("sv-SE")).apply { strength = java.text.Collator.PRIMARY }
        artists = list.groupBy { it.artist }.toList()
            .sortedWith { x, y -> coll.compare(sortName(x.first), sortName(y.first)) }
            .map { (name, al) -> name to al.sortedBy { it.year } }
        artistById = artists.associateBy { artistId(it.first) }
        trackById = buildMap { list.forEach { a -> a.tracks.forEach { t -> put(t.id.toString(), a to t) } } }
        loaded = true
    }

    /** A plain root that can't fail, for when building the real menu does. */
    private val plainRoot: MediaItem = MediaItem.Builder()
        .setMediaId(ROOT)
        .setMediaMetadata(MediaMetadata.Builder().setTitle("Skivbacken").setIsBrowsable(true).setIsPlayable(false).build())
        .build()

    /**
     * Runs one Android Auto request. If it fails, the error is saved (shown under Settings in the app)
     * and the car gets an empty answer instead of the app crashing and being hidden.
     */
    private fun <T> guard(what: String, block: () -> T): T? = try {
        block()
    } catch (t: Throwable) {
        runCatching {
            getSharedPreferences("skivbacken", Context.MODE_PRIVATE).edit()
                .putString("autoError", "Fel när bilen hämtade $what:\n" + t.stackTraceToString().take(1200))
                .apply()
        }
        null
    }

    // ---------- shuffle / repeat buttons in the car's player ----------

    private val cmdShuffle = SessionCommand(CMD_SHUFFLE, Bundle.EMPTY)
    private val cmdRepeat = SessionCommand(CMD_REPEAT, Bundle.EMPTY)

    private fun buttons(p: Player): ImmutableList<CommandButton> = ImmutableList.of(
        CommandButton.Builder()
            .setDisplayName(if (p.shuffleModeEnabled) "Blanda: på" else "Blanda: av")
            .setIconResId(if (p.shuffleModeEnabled) R.drawable.ic_cmd_shuffle_on else R.drawable.ic_cmd_shuffle_off)
            .setSessionCommand(cmdShuffle)
            .build(),
        CommandButton.Builder()
            .setDisplayName(
                when (p.repeatMode) {
                    Player.REPEAT_MODE_ALL -> "Upprepa: alla"
                    Player.REPEAT_MODE_ONE -> "Upprepa: en"
                    else -> "Upprepa: av"
                },
            )
            .setIconResId(
                when (p.repeatMode) {
                    Player.REPEAT_MODE_ALL -> R.drawable.ic_cmd_repeat_all
                    Player.REPEAT_MODE_ONE -> R.drawable.ic_cmd_repeat_one
                    else -> R.drawable.ic_cmd_repeat_off
                },
            )
            .setSessionCommand(cmdRepeat)
            .build(),
    )

    // ---------- recently played ----------

    /** Keeps the last 60 tracks started, newest first; the car shows their records. */
    private fun remember(trackId: String) {
        val p = getSharedPreferences("skivbacken", Context.MODE_PRIVATE)
        val list = (listOf(trackId) + p.getString("recent_tracks", "").orEmpty().split(",").filter { it.isNotBlank() && it != trackId }).take(60)
        p.edit().putString("recent_tracks", list.joinToString(",")).apply()
    }

    private fun recentAlbums(): List<Album> {
        val ids = getSharedPreferences("skivbacken", Context.MODE_PRIVATE).getString("recent_tracks", "").orEmpty().split(",")
        return ids.mapNotNull { trackById[it]?.first }.distinctBy { it.key }.take(20)
    }

    // ---------- search and voice ----------

    private fun allShuffled(): List<MediaItem> =
        albums.flatMap { a -> a.tracks.map { a to it } }.shuffled().take(400).map { (a, t) -> trackItem(a, t) }

    private class Hits(val albums: List<Album>, val tracks: List<Pair<Album, Track>>, val artist: String?)

    /** Albums, tracks and an artist matching what was said or typed, best first. */
    private fun search(query: String): Hits {
        var q = fold(query).replace(Regex("\\b(i|pa|fran|med)\\s+skivbacken\\b"), " ").replace("skivbacken", " ")
        q = q.replace(Regex("^(spela|play|lyssna pa)\\s+"), "").replace(Regex("\\s+"), " ").trim()
        if (q.isEmpty()) return Hits(emptyList(), emptyList(), null)
        fun score(text: String): Int {
            val t = fold(text).trim()
            return when {
                t.isEmpty() -> 0
                q == t -> 10
                t.length >= 3 && q.contains(t) -> 6
                q.length >= 3 && t.contains(q) -> 5
                else -> 0
            }
        }
        val albumHits = albums.map { a ->
            val ts = maxOf(score(a.title), score(OnlineArt.cleanTitle(a.title)))
            val ar = score(a.artist)
            a to (if (ts > 0) ts * 2 + (if (ar >= 5) 3 else 0) else 0)
        }.filter { it.second > 0 }.sortedByDescending { it.second }.map { it.first }
        val trackHits = albums.flatMap { a -> a.tracks.map { a to it } }
            .map { (a, t) -> (a to t) to (score(t.title) * 2 + if (score(t.artist) >= 5 || score(a.artist) >= 5) 3 else 0).let { if (score(t.title) == 0) 0 else it } }
            .filter { it.second > 0 }.sortedByDescending { it.second }.map { it.first }
        val artist = artists.map { it.first }.maxByOrNull { score(it) }?.takeIf { score(it) >= 6 }
        return Hits(albumHits, trackHits, artist)
    }

    /** What to play for "spela …": an album, a song (with the rest of its album), an artist, or everything shuffled. */
    private fun voicePlay(query: String): MediaSession.MediaItemsWithStartPosition {
        val h = search(query)
        val album = h.albums.firstOrNull()
        val track = h.tracks.firstOrNull()
        val q = fold(query).trim()
        return when {
            album != null && (track == null || fold(album.title).length >= fold(track.second.title).length || fold(album.title) == q) ->
                MediaSession.MediaItemsWithStartPosition(album.tracks.map { trackItem(album, it) }, 0, 0L)
            track != null -> {
                val (a, t) = track
                MediaSession.MediaItemsWithStartPosition(a.tracks.map { trackItem(a, it) }, a.tracks.indexOf(t).coerceAtLeast(0), 0L)
            }
            h.artist != null -> {
                val list = artists.first { it.first == h.artist }.second.flatMap { a -> a.tracks.map { a to it } }.shuffled()
                MediaSession.MediaItemsWithStartPosition(list.map { (a, t) -> trackItem(a, t) }, 0, 0L)
            }
            else -> MediaSession.MediaItemsWithStartPosition(allShuffled(), 0, 0L)
        }
    }

    private val searchResults = java.util.concurrent.ConcurrentHashMap<String, List<MediaItem>>()

    private fun shuffleAllItem(): MediaItem = MediaItem.Builder()
        .setMediaId(SHUFFLE_ALL)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle("Blanda alla låtar")
                .setSubtitle("${albums.sumOf { it.tracks.size }} låtar från ${albums.size} skivor")
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .setMediaType(MediaMetadata.MEDIA_TYPE_PLAYLIST)
                .apply { albums.firstOrNull()?.let { setArtworkUri(ArtFiles.uriFor(this@PlaybackService, it)) } }
                .build()
        )
        .build()

    private fun artistId(name: String) = "artist:" + Integer.toHexString(name.lowercase().hashCode())

    /** How Android Auto lays out the children of an item: covers in a grid or rows in a list. */
    private fun style(browsable: Int, playable: Int = MediaConstants.EXTRAS_VALUE_CONTENT_STYLE_LIST_ITEM) = Bundle().apply {
        putInt(MediaConstants.EXTRAS_KEY_CONTENT_STYLE_BROWSABLE, browsable)
        putInt(MediaConstants.EXTRAS_KEY_CONTENT_STYLE_PLAYABLE, playable)
    }

    private val rootItem: MediaItem = MediaItem.Builder()
        .setMediaId(ROOT)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle("Skivbacken")
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_MIXED)
                .setExtras(style(MediaConstants.EXTRAS_VALUE_CONTENT_STYLE_GRID_ITEM))
                .build()
        )
        .build()

    /** The tabs along the top in Android Auto. */
    private fun tab(id: String, title: String, type: Int, childStyle: Int): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setMediaType(type)
                .setExtras(style(childStyle))
                .build()
        )
        .build()

    private val tabs: List<MediaItem> by lazy {
        listOf(
            tab(TAB_ALBUMS, "Album", MediaMetadata.MEDIA_TYPE_FOLDER_ALBUMS, MediaConstants.EXTRAS_VALUE_CONTENT_STYLE_GRID_ITEM),
            tab(TAB_ARTISTS, "Artister", MediaMetadata.MEDIA_TYPE_FOLDER_ARTISTS, MediaConstants.EXTRAS_VALUE_CONTENT_STYLE_LIST_ITEM),
            tab(TAB_RECENT, "Senast spelade", MediaMetadata.MEDIA_TYPE_FOLDER_ALBUMS, MediaConstants.EXTRAS_VALUE_CONTENT_STYLE_GRID_ITEM),
        )
    }

    /** Item extras with a group heading (A, B, C …) so the car lists them under letters. */
    private fun grouped(base: Bundle, group: String?) = base.apply {
        if (group != null) putString(MediaConstants.EXTRAS_KEY_CONTENT_STYLE_GROUP_TITLE, group)
    }

    private fun artistItem(name: String, al: List<Album>, group: String? = null): MediaItem = MediaItem.Builder()
        .setMediaId(artistId(name))
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(name)
                .setSubtitle(if (al.size == 1) "1 album" else "${al.size} album")
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setMediaType(MediaMetadata.MEDIA_TYPE_ARTIST)
                .setArtworkUri(ArtFiles.uriFor(this, al.first()))
                .setExtras(grouped(style(MediaConstants.EXTRAS_VALUE_CONTENT_STYLE_GRID_ITEM), group))
                .build()
        )
        .build()

    private fun albumItem(a: Album, group: String? = null): MediaItem = MediaItem.Builder()
        .setMediaId(albumId(a))
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(a.title)
                .setArtist(a.artist)
                .setAlbumTitle(a.title)
                .setAlbumArtist(a.artist)
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setSubtitle(listOfNotNull(a.artist, a.year.takeIf { it > 0 }?.toString()).joinToString(" · "))
                .setMediaType(MediaMetadata.MEDIA_TYPE_ALBUM)
                .setArtworkUri(ArtFiles.uriFor(this, a))
                .setExtras(grouped(style(MediaConstants.EXTRAS_VALUE_CONTENT_STYLE_LIST_ITEM), group))
                .build()
        )
        .build()

    private fun trackItem(a: Album, t: Track): MediaItem = MediaItem.Builder()
        .setMediaId(t.id.toString())
        .setUri(t.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(t.title)
                .setArtist(t.artist)
                .setAlbumTitle(a.title)
                .setAlbumArtist(a.artist)
                .setTrackNumber(t.no)
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                .setArtworkUri(ArtFiles.uriFor(this, a))
                .build()
        )
        .build()

    private inner class Callback : MediaLibrarySession.Callback {
        override fun onGetLibraryRoot(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<MediaItem>> = io.submit<LibraryResult<MediaItem>> {
            guard("menyn") {
                ensureLoaded(force = true)
                val out = LibraryParams.Builder()
                    .setExtras(style(MediaConstants.EXTRAS_VALUE_CONTENT_STYLE_GRID_ITEM).apply { putBoolean("android.media.browse.SEARCH_SUPPORTED", true) })
                    .build()
                LibraryResult.ofItem(rootItem, out)
            } ?: LibraryResult.ofItem(plainRoot, null)
        }

        override fun onGetChildren(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> = io.submit<LibraryResult<ImmutableList<MediaItem>>> {
            guard("listan " + parentId) {
                ensureLoaded()
                val items: List<MediaItem> = when {
                    parentId == ROOT -> tabs
                    parentId == TAB_ALBUMS -> listOf(shuffleAllItem()) + albums.map { albumItem(it, it.letter.toString()) }
                    parentId == TAB_ARTISTS -> artists.map { (name, al) -> artistItem(name, al, letterOf(name).toString()) }
                    parentId == TAB_RECENT -> recentAlbums().map { albumItem(it) }
                    artistById[parentId] != null -> artistById.getValue(parentId).second.map { albumItem(it) }
                    else -> albumById[parentId]?.let { a -> a.tracks.map { trackItem(a, it) } } ?: emptyList()
                }
                val from = (page.toLong() * pageSize).coerceIn(0L, items.size.toLong()).toInt()
                val to = (from.toLong() + pageSize).coerceIn(from.toLong(), items.size.toLong()).toInt()
                LibraryResult.ofItemList(ImmutableList.copyOf(items.subList(from, to)), params)
            } ?: LibraryResult.ofItemList(ImmutableList.of(), params)
        }

        override fun onGetItem(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            mediaId: String,
        ): ListenableFuture<LibraryResult<MediaItem>> = io.submit<LibraryResult<MediaItem>> {
            guard("objektet " + mediaId) {
                ensureLoaded()
                val item = when {
                    mediaId == ROOT -> rootItem
                    mediaId == TAB_ALBUMS || mediaId == TAB_ARTISTS || mediaId == TAB_RECENT -> tabs.first { it.mediaId == mediaId }
                mediaId == SHUFFLE_ALL -> shuffleAllItem()
                    artistById[mediaId] != null -> artistById.getValue(mediaId).let { (n, al) -> artistItem(n, al) }
                    albumById[mediaId] != null -> albumItem(albumById.getValue(mediaId))
                    trackById[mediaId] != null -> trackById.getValue(mediaId).let { (a, t) -> trackItem(a, t) }
                    else -> null
                }
                if (item != null) LibraryResult.ofItem(item, null) else LibraryResult.ofError(LibraryResult.RESULT_ERROR_BAD_VALUE)
            } ?: LibraryResult.ofError(LibraryResult.RESULT_ERROR_UNKNOWN)
        }

        /** Lets the car use the shuffle and repeat buttons. */
        override fun onConnect(session: MediaSession, controller: MediaSession.ControllerInfo): MediaSession.ConnectionResult =
            guard("anslutningen (${controller.packageName})") {
                val cmds = MediaSession.ConnectionResult.DEFAULT_SESSION_AND_LIBRARY_COMMANDS.buildUpon()
                    .add(cmdShuffle).add(cmdRepeat).build()
                MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                    .setAvailableSessionCommands(cmds)
                    .setCustomLayout(buttons(session.player))
                    .build()
            } ?: MediaSession.ConnectionResult.AcceptedResultBuilder(session).build()

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle,
        ): ListenableFuture<SessionResult> {
            if (guard("knappen") { customCommand.customAction } == null) return Futures.immediateFuture(SessionResult(SessionResult.RESULT_ERROR_UNKNOWN))
            val p = session.player
            when (customCommand.customAction) {
                CMD_SHUFFLE -> p.shuffleModeEnabled = !p.shuffleModeEnabled
                CMD_REPEAT -> p.repeatMode = when (p.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
            }
            session.setCustomLayout(buttons(p))
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }

        /** Typed search in the car (while parked). */
        override fun onSearch(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<Void>> = io.submit<LibraryResult<Void>> {
            guard("sökningen") {
                ensureLoaded()
                val h = search(query)
                val items = h.albums.take(20).map { albumItem(it) } + h.tracks.take(30).map { (a, t) -> trackItem(a, t) }
                searchResults[query] = items
                session.notifySearchResultChanged(browser, query, items.size, params)
            }
            LibraryResult.ofVoid()
        }

        override fun onGetSearchResult(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> = io.submit<LibraryResult<ImmutableList<MediaItem>>> {
            val items = searchResults[query] ?: guard("sökningen") { ensureLoaded(); search(query).let { h -> h.albums.take(20).map { albumItem(it) } + h.tracks.take(30).map { (a, t) -> trackItem(a, t) } } }.orEmpty()
            val from = (page.toLong() * pageSize).coerceIn(0L, items.size.toLong()).toInt()
            val to = (from.toLong() + pageSize).coerceIn(from.toLong(), items.size.toLong()).toInt()
            LibraryResult.ofItemList(ImmutableList.copyOf(items.subList(from, to)), params)
        }

        /** Items from Android Auto arrive without a file address; look them up. */
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> = io.submit<MutableList<MediaItem>> {
            ensureLoaded()
            mediaItems.mapNotNull { item ->
                if (item.localConfiguration != null) item
                else trackById[item.mediaId]?.let { (a, t) -> trackItem(a, t) }
            }.toMutableList()
        }

        /** A play press with nothing loaded (widget, headphones, car): carry on where you left off. */
        override fun onPlaybackResumption(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> = io.submit<MediaSession.MediaItemsWithStartPosition> {
            ensureLoaded()
            val p = getSharedPreferences("skivbacken", Context.MODE_PRIVATE)
            val ids = p.getString("resume_ids", null)?.split(",").orEmpty()
            val items = ids.mapNotNull { id -> trackById[id]?.let { (a, t) -> trackItem(a, t) } }
            if (items.isEmpty()) {
                // Nothing saved yet: start the first record in the crate.
                val first = albums.firstOrNull()
                MediaSession.MediaItemsWithStartPosition(first?.tracks?.map { trackItem(first, it) }.orEmpty(), 0, 0L)
            } else {
                val idx = p.getInt("resume_index", 0).coerceIn(0, items.size - 1)
                MediaSession.MediaItemsWithStartPosition(items, idx, p.getLong("resume_pos", 0L))
            }
        }

        /** Picking one track in the car queues the whole album from that track. */
        override fun onSetMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
            startIndex: Int,
            startPositionMs: Long,
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            val single = mediaItems.singleOrNull()
            if (single != null && single.localConfiguration == null) {
                return io.submit<MediaSession.MediaItemsWithStartPosition> {
                    ensureLoaded()
                    val spoken = single.requestMetadata.searchQuery
                    if (spoken != null || single.mediaId.isEmpty()) {
                        return@submit guard("röststyrningen") { voicePlay(spoken.orEmpty()) }
                            ?: MediaSession.MediaItemsWithStartPosition(emptyList(), 0, C.TIME_UNSET)
                    }
                    if (single.mediaId == SHUFFLE_ALL) return@submit MediaSession.MediaItemsWithStartPosition(allShuffled(), 0, 0L)
                    val hit = trackById[single.mediaId]
                    if (hit == null) {
                        MediaSession.MediaItemsWithStartPosition(emptyList(), 0, C.TIME_UNSET)
                    } else {
                        val (a, t) = hit
                        MediaSession.MediaItemsWithStartPosition(
                            a.tracks.map { trackItem(a, it) },
                            a.tracks.indexOf(t).coerceAtLeast(0),
                            C.TIME_UNSET,
                        )
                    }
                }
            }
            return Futures.transform(
                onAddMediaItems(mediaSession, controller, mediaItems),
                { items -> MediaSession.MediaItemsWithStartPosition(items, startIndex, startPositionMs) },
                MoreExecutors.directExecutor(),
            )
        }
    }

    private companion object {
        const val ROOT = "root"
        const val TAB_ALBUMS = "albums"
        const val TAB_ARTISTS = "artists"
        const val TAB_RECENT = "recent"
        const val SHUFFLE_ALL = "shuffle_all"
        const val CMD_SHUFFLE = "se.skivbacken.SHUFFLE"
        const val CMD_REPEAT = "se.skivbacken.REPEAT"
    }
}
