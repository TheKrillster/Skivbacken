package se.skivbacken.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import se.skivbacken.MainViewModel

/** Pick which folders the crate is filled from. A chosen folder includes everything below it. */
@Composable
fun FolderScreen(vm: MainViewModel, onDone: () -> Unit) {
    val c = LocalSkiv.current
    var sel by remember { mutableStateOf(vm.chosenFolders) }

    Column(Modifier.fillMaxSize().background(c.panel).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            PressButton(onClick = onDone, size = 48.dp) { Glyph(Ic.Down, c.ink, Modifier.size(26.dp)) }
            Text("Mappar och dolda skivor", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, letterSpacing = (-0.02).em)
        }
        Text(
            "Välj var din musik ligger. Undermappar följer med.",
            modifier = Modifier.padding(horizontal = 16.dp).padding(bottom = 8.dp), fontSize = 14.sp, color = c.inkSoft,
        )
        LazyColumn(Modifier.weight(1f)) {
            item {
                FolderRow(
                    name = "Alla mappar", detail = "Allt som telefonen hittar",
                    depth = 0, checked = sel.isEmpty(), enabled = true,
                    onClick = { sel = emptySet() },
                )
            }
            items(vm.folders, key = { it.path }) { f ->
                val parentOn = sel.any { it != f.path && f.path.startsWith(it, ignoreCase = true) }
                FolderRow(
                    name = f.name,
                    detail = "${f.path} · ${f.count} låtar",
                    depth = f.depth - 1,
                    checked = f.path in sel || parentOn,
                    enabled = !parentOn,
                    onClick = {
                        sel = if (f.path in sel) sel - f.path
                        else sel.filterNot { it.startsWith(f.path, ignoreCase = true) }.toSet() + f.path
                    },
                )
            }
            val hidden = vm.hiddenList
            item {
                Text(
                    "DOLDA SKIVOR", modifier = Modifier.padding(start = 16.dp, top = 24.dp, bottom = 4.dp),
                    fontSize = 11.sp, letterSpacing = 0.12.em, color = c.inkSoft,
                )
                if (hidden.isEmpty()) {
                    Text(
                        "Inga skivor är dolda. Öppna en skiva och tryck Dölj för att gömma den.",
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp), fontSize = 13.sp, color = c.inkSoft,
                    )
                }
            }
            items(hidden, key = { "h:" + it.key }) { a ->
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = c.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(a.artist, fontSize = 12.5.sp, color = c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(
                        "Visa igen",
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(c.chip).clickable { vm.unhide(a.key) }
                            .padding(horizontal = 14.dp, vertical = 7.dp),
                        fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = c.ink,
                    )
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(c.line))
        Button(
            onClick = { vm.setFolders(sel); onDone() },
            modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = c.sticker, contentColor = c.stickerInk),
        ) {
            Text(
                if (sel.isEmpty()) "Använd alla mappar" else if (sel.size == 1) "Använd 1 mapp" else "Använd ${sel.size} mappar",
                fontWeight = FontWeight.Bold, fontSize = 15.sp,
            )
        }
    }
}

@Composable
private fun FolderRow(name: String, detail: String, depth: Int, checked: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val c = LocalSkiv.current
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(enabled = enabled, onClick = onClick)
                .padding(start = (8 + depth * 28).dp, end = 16.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Checkbox(
                checked = checked, onCheckedChange = null, enabled = enabled,
                modifier = Modifier.padding(12.dp),
                colors = CheckboxDefaults.colors(
                    checkedColor = c.sticker, checkmarkColor = c.stickerInk,
                    uncheckedColor = c.inkSoft, disabledCheckedColor = c.sticker.copy(alpha = 0.45f),
                ),
            )
            Column(Modifier.weight(1f)) {
                Text(name, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = c.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(detail, fontFamily = AppFont, fontSize = 11.5.sp, color = c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Box(Modifier.padding(start = (60 + depth * 28).dp).fillMaxWidth().height(1.dp).background(c.line))
    }
}
