package se.skivbacken.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** What sits behind the crate, as picked in Settings. */
@Composable
fun CrateBackdrop(modifier: Modifier) {
    when (ThemePrefs.crateBg) {
        0 -> ShopScene(modifier)
        1 -> OwnPicture(modifier)
        else -> Unit
    }
}

private val SpineColors = listOf(
    Color(0xFF8C3B2E), Color(0xFF2F4F6F), Color(0xFFC9A24A), Color(0xFF3E6B4F), Color(0xFF6B4A7A),
    Color(0xFFD8D2C4), Color(0xFF1E1E1E), Color(0xFFB5643A), Color(0xFF4F7A8C), Color(0xFF7A7A6A),
)

/** A calm record shop: two shelves of record spines and a wooden floor, a little out of focus. */
@Composable
private fun ShopScene(modifier: Modifier) {
    val c = LocalSkiv.current
    Canvas(modifier.blur(2.5.dp)) {
        val w = size.width
        val h = size.height
        val rnd = java.util.Random(11)
        val gap = 1.dp.toPx()
        for (row in 0..1) {
            val rowTop = h * (0.04f + row * 0.29f)
            val rowH = h * 0.22f
            var x = -rnd.nextFloat() * 12f
            while (x < w) {
                if (rnd.nextInt(14) == 0) { x += (6 + rnd.nextInt(10)).dp.toPx(); continue }
                val sw = (3 + rnd.nextInt(5)).dp.toPx()
                val sh = rowH * (0.80f + rnd.nextFloat() * 0.2f)
                val col = lerp(SpineColors[rnd.nextInt(SpineColors.size)], c.wall, 0.58f)
                drawRect(col, Offset(x, rowTop + rowH - sh), Size(sw, sh))
                x += sw + gap
            }
            drawRect(lerp(c.ply, c.wall, 0.35f), Offset(0f, rowTop + rowH), Size(w, 7.dp.toPx()))
            drawRect(
                Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.10f), Color.Transparent), rowTop + rowH + 7.dp.toPx(), rowTop + rowH + 22.dp.toPx()),
                Offset(0f, rowTop + rowH + 7.dp.toPx()), Size(w, 15.dp.toPx()),
            )
        }
        val floorTop = h * 0.70f
        drawRect(lerp(c.plyDark, c.wall, 0.55f), Offset(0f, floorTop), Size(w, h - floorTop))
        var y = floorTop
        var k = 0
        while (y < h) {
            drawLine(Color.Black.copy(alpha = 0.06f), Offset(0f, y), Offset(w, y), 1.dp.toPx())
            y += (14 + k * 6).dp.toPx()
            k++
        }
        drawRect(Brush.verticalGradient(listOf(c.wall.copy(alpha = 0.0f), c.wall.copy(alpha = 0.35f))), size = size)
    }
}

private fun bgFile(ctx: Context) = File(ctx.filesDir, "crate_bg.jpg")

/** The user's own picture, softened so the sleeves stay in front. */
@Composable
private fun OwnPicture(modifier: Modifier) {
    val c = LocalSkiv.current
    val ctx = LocalContext.current
    val img by produceState<ImageBitmap?>(null, ThemePrefs.bgVersion) {
        value = withContext(Dispatchers.IO) {
            runCatching { BitmapFactory.decodeFile(bgFile(ctx).path)?.asImageBitmap() }.getOrNull()
        }
    }
    Box(modifier) {
        img?.let {
            Image(it, contentDescription = null, modifier = Modifier.fillMaxSize().blur(5.dp), contentScale = ContentScale.Crop)
        }
        Box(Modifier.fillMaxSize().background(c.wall.copy(alpha = 0.45f)))
    }
}

/** Copies a picture the user picked into the app, at most 1400 px wide. */
suspend fun saveBackground(ctx: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
    runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 1400) sample *= 2
        val bmp = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return@runCatching false
        bgFile(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        true
    }.getOrDefault(false)
}
