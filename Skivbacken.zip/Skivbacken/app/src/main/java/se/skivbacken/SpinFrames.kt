package se.skivbacken

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.net.Uri
import java.io.File

/**
 * Pictures of the record at 16 angles for the Vinyl widget. The home screen flips through them,
 * which makes the record turn at about 33 rpm. The label is the cover; the light on the vinyl
 * stays in place from frame to frame. Drawn once per record and kept on the phone.
 */
object SpinFrames {
    const val COUNT = 16
    private const val SIZE = 320

    fun prepare(ctx: Context, artKey: String?, cover: Bitmap?): List<Uri> {
        val dir = File(ctx.filesDir, "spin").apply { mkdirs() }
        val key = Integer.toHexString((artKey ?: "none").hashCode())
        val files = (0 until COUNT).map { File(dir, "$key-$it.png") }
        if (files.any { !it.exists() }) {
            // Only the current record is kept.
            dir.listFiles()?.filter { !it.name.startsWith("$key-") }?.forEach { it.delete() }
            files.forEachIndexed { k, f ->
                val bmp = frame(cover, k * 360f / COUNT)
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                bmp.recycle()
            }
        }
        return files.map { Uri.parse("content://se.skivbacken.art/s/${it.name}") }
    }

    private fun frame(cover: Bitmap?, angle: Float): Bitmap {
        val out = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val cx = SIZE / 2f
        val r = SIZE * 0.49f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // Vinyl and grooves.
        p.color = Color.rgb(16, 16, 17)
        c.drawCircle(cx, cx, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        var gr = r * 0.97f
        var k = 0
        while (gr > r * 0.36f) {
            p.color = Color.argb(if (k % 6 == 0) 18 else 9, 255, 255, 255)
            c.drawCircle(cx, cx, gr, p)
            gr -= r * 0.013f
            k++
        }
        p.color = Color.BLACK
        p.strokeWidth = 2.5f
        for (f in floatArrayOf(0.84f, 0.70f, 0.56f)) c.drawCircle(cx, cx, r * f, p)
        p.style = Paint.Style.FILL

        // Label: the cover, turned.
        val lr = r * 0.34f
        if (cover != null) {
            val m = Matrix()
            val s = (lr * 2) / minOf(cover.width, cover.height)
            m.postScale(s, s)
            m.postTranslate(cx - cover.width * s / 2f, cx - cover.height * s / 2f)
            m.postRotate(angle, cx, cx)
            p.shader = BitmapShader(cover, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).apply { setLocalMatrix(m) }
        } else {
            p.color = Color.rgb(47, 143, 91)
        }
        c.drawCircle(cx, cx, lr, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f
        p.color = Color.argb(46, 255, 255, 255)
        c.drawCircle(cx, cx, lr, p)
        p.style = Paint.Style.FILL

        // Light on the vinyl, the same in every frame.
        val clear = Color.TRANSPARENT
        p.shader = SweepGradient(
            cx, cx,
            intArrayOf(clear, Color.argb(30, 255, 255, 255), clear, clear, Color.argb(22, 255, 255, 255), clear, clear),
            null,
        )
        c.drawCircle(cx, cx, r, p)
        p.shader = null
        // Spindle.
        p.shader = RadialGradient(cx - 2f, cx - 2f, 7f, Color.WHITE, Color.rgb(125, 130, 135), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cx, 5f, p)
        p.shader = null
        return out
    }
}
