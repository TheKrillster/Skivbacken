package se.skivbacken.ui

import android.content.res.Configuration
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import se.skivbacken.Album
import se.skivbacken.MainViewModel
import se.skivbacken.Screen

@Composable
fun SkivApp(vm: MainViewModel, onRequestPermission: () -> Unit) {
    val c = LocalSkiv.current
    Box(Modifier.fillMaxSize().background(c.wall)) {
        if (!vm.hasPermission) {
            PermissionScreen(onRequestPermission)
        } else {
            val screen = vm.screen
            val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
            if (landscape && screen !is Screen.Folders && screen !is Screen.CoverSearch) {
                LandscapeRoot(vm, screen)
                BackHandler(enabled = screen != Screen.Library) { vm.screen = Screen.Library }
                return@Box
            }
            // The crate is not drawn at all while a record plays.
            if (screen !is Screen.Playing) {
                CrateScreen(vm, onOpen = { vm.screen = Screen.AlbumView(it.key) })
            }
            val open = (screen as? Screen.AlbumView)?.let { s -> vm.albums.firstOrNull { it.key == s.key } }
            val shown = remember { arrayOfNulls<Album>(1) }
            if (open != null) shown[0] = open
            AnimatedVisibility(
                visible = open != null,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut(),
            ) {
                shown[0]?.let { AlbumScreen(it, vm, onBack = { vm.screen = Screen.Library }) }
            }
            AnimatedVisibility(
                visible = screen is Screen.Playing,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut(),
            ) {
                PlayingScreen(vm, onBack = { vm.screen = Screen.Library })
            }
            AnimatedVisibility(
                visible = screen is Screen.Folders,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut(),
            ) {
                FolderScreen(vm, onDone = { vm.screen = Screen.Library })
            }
            val search = screen as? Screen.CoverSearch
            val searchAlbum = search?.let { s -> vm.albums.firstOrNull { it.key == s.key } }
            val shownSearch = remember { arrayOfNulls<Album>(1) }
            if (searchAlbum != null) shownSearch[0] = searchAlbum
            AnimatedVisibility(
                visible = searchAlbum != null,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut(),
            ) {
                shownSearch[0]?.let { a -> CoverSearchScreen(vm, a, onDone = { vm.screen = search?.back ?: Screen.Library }) }
            }
        }
    }
    BackHandler(enabled = vm.screen != Screen.Library) {
        vm.screen = (vm.screen as? Screen.CoverSearch)?.back ?: Screen.Library
    }
}

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    val c = LocalSkiv.current
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Skivbacken", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, letterSpacing = (-0.02).em)
        Text(
            "Appen behöver komma åt musiken på telefonen för att hitta dina FLAC-, MP3- och M4A-filer.",
            modifier = Modifier.padding(top = 10.dp, bottom = 20.dp), fontSize = 16.sp, color = c.inkSoft,
        )
        Button(onClick = onRequest, colors = ButtonDefaults.buttonColors(containerColor = c.sticker, contentColor = c.stickerInk)) {
            Text("Ge åtkomst till musik", fontWeight = FontWeight.Bold)
        }
        Text(
            "Händer inget? Öppna Inställningar › Appar › Skivbacken › Behörigheter och tillåt Musik och ljud.",
            modifier = Modifier.padding(top = 16.dp), fontSize = 13.sp, color = c.inkSoft,
        )
    }
}

/** Phone on its side: the record shelf, an opened record, or the player. */
@Composable
private fun LandscapeRoot(vm: MainViewModel, screen: Screen) {
    val c = LocalSkiv.current
    val album = when (screen) {
        is Screen.AlbumView -> vm.albums.firstOrNull { it.key == screen.key }
        Screen.Playing -> vm.currentAlbum
        else -> null
    }
    if (album != null) {
        LandscapeAlbum(vm, album, onBack = { vm.screen = Screen.Library })
        return
    }
    Column(
        Modifier
            .fillMaxSize()
            .background(c.wall)
            .statusBarsPadding()
            .windowInsetsPadding(androidx.compose.foundation.layout.WindowInsets.safeDrawing.only(androidx.compose.foundation.layout.WindowInsetsSides.Horizontal)),
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Skivbacken", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, modifier = Modifier.weight(1f))
            PressButton(onClick = { vm.screen = Screen.Folders }, size = 40.dp) { Glyph(Ic.Settings, c.ink, Modifier.size(21.dp)) }
            PressButton(onClick = { vm.load() }, size = 40.dp) { Glyph(Ic.Refresh, c.ink, Modifier.size(20.dp)) }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (vm.albums.isEmpty()) {
                Text(
                    if (vm.loading) "Letar efter musik…" else "Backen är tom.",
                    modifier = Modifier.align(Alignment.Center), fontSize = 16.sp, color = c.inkSoft,
                )
            } else {
                ShelfScreen(vm, onOpen = { vm.screen = Screen.AlbumView(it.key) })
            }
        }
        if (vm.currentTrack != null) LandscapePlayerRow(vm)
        Spacer(Modifier.navigationBarsPadding())
    }
}
