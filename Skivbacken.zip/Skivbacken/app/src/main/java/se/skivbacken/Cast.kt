package se.skivbacken

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.FileInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/** What the app shows about casting: the TV's name while music plays there. */
object CastUi {
    var device by mutableStateOf<String?>(null)
}

/**
 * A small web server on the phone that hands music files and covers to the TV while casting.
 * The TV fetches the files itself over the home wifi, so the sound is not re-compressed.
 * Every address carries a random key, so other devices on the network can't browse the music.
 */
object CastServer {
    private var socket: ServerSocket? = null
    private val key = UUID.randomUUID().toString().replace("-", "").take(20)
    private val pool = Executors.newCachedThreadPool()
    private lateinit var app: Context

    @Synchronized
    fun start(ctx: Context): Boolean {
        app = ctx.applicationContext
        if (socket?.isClosed == false) return true
        val s = runCatching { ServerSocket(0) }.getOrNull() ?: return false
        socket = s
        thread(isDaemon = true, name = "skivbacken-cast") {
            while (!s.isClosed) {
                val c = runCatching { s.accept() }.getOrNull() ?: break
                pool.execute { runCatching { serve(c) } }
            }
        }
        return true
    }

    @Synchronized
    fun stop() {
        runCatching { socket?.close() }
        socket = null
    }

    private fun base(): String? {
        val port = socket?.localPort ?: return null
        val ip = wifiIp(app) ?: return null
        return "http://$ip:$port/$key"
    }

    /** Web address of a music file on the phone. */
    fun fileUrl(file: Uri, mime: String): Uri? =
        base()?.let { Uri.parse("$it/f?m=${Uri.encode(mime)}&u=${Uri.encode(file.toString())}") }

    /** Web address of a cover from [ArtProvider]. */
    fun artUrl(art: Uri?): Uri? =
        if (art == null) null else base()?.let { Uri.parse("$it/f?m=image%2Fjpeg&u=${Uri.encode(art.toString())}") }

    /** The phone's address on the home network (wifi or cable), or null without one. */
    fun wifiIp(ctx: Context): String? {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return null
        @Suppress("DEPRECATION")
        val nets = listOfNotNull(cm.activeNetwork) + cm.allNetworks.toList()
        for (n in nets) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) && !caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) continue
            val ip = cm.getLinkProperties(n)?.linkAddresses
                ?.map { it.address }
                ?.firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
                ?.hostAddress
            if (ip != null) return ip
        }
        return null
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = input.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(b.toChar())
            if (sb.length > 8192) return null
        }
    }

    private fun head(out: OutputStream, status: String, headers: List<String>) {
        val text = buildString {
            append("HTTP/1.1 ").append(status).append("\r\n")
            headers.forEach { append(it).append("\r\n") }
            append("Access-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n")
        }
        out.write(text.toByteArray(Charsets.ISO_8859_1))
    }

    private fun serve(sock: Socket) = sock.use {
        sock.soTimeout = 30_000
        val input = BufferedInputStream(sock.getInputStream())
        val out = BufferedOutputStream(sock.getOutputStream(), 64 * 1024)
        val request = readLine(input) ?: return
        var range: String? = null
        while (true) {
            val h = readLine(input) ?: break
            if (h.isEmpty()) break
            if (h.startsWith("range:", ignoreCase = true)) range = h.substringAfter(':').trim()
        }
        val parts = request.split(' ')
        val method = parts.getOrNull(0) ?: return
        val path = parts.getOrNull(1) ?: return
        if (method == "OPTIONS") {
            head(out, "204 No Content", listOf("Access-Control-Allow-Headers: *", "Access-Control-Allow-Methods: GET, HEAD"))
            out.flush(); return
        }
        val url = Uri.parse("http://x$path")
        val target = url.getQueryParameter("u")?.let(Uri::parse)
        val mime = url.getQueryParameter("m") ?: "application/octet-stream"
        // Only music from the phone's music library and covers from the app itself.
        val allowed = target != null && url.path == "/$key/f" &&
            target.scheme == "content" && (target.authority == "media" || target.authority == "se.skivbacken.art")
        if (!allowed) {
            head(out, "404 Not Found", listOf("Content-Length: 0")); out.flush(); return
        }
        sendFile(out, method == "HEAD", target!!, mime, range)
        out.flush()
    }

    private fun sendFile(out: OutputStream, headOnly: Boolean, uri: Uri, mime: String, range: String?) {
        val afd = runCatching { app.contentResolver.openAssetFileDescriptor(uri, "r") }.getOrNull()
        if (afd == null) {
            head(out, "404 Not Found", listOf("Content-Length: 0")); return
        }
        afd.use {
            val len = afd.length.takeIf { it >= 0 } ?: afd.parcelFileDescriptor.statSize
            if (len < 0) {
                // Unknown size: send it all in one go.
                val bytes = app.contentResolver.openInputStream(uri)?.use { s -> s.readBytes() } ?: ByteArray(0)
                head(out, "200 OK", listOf("Content-Type: $mime", "Content-Length: ${bytes.size}"))
                if (!headOnly) out.write(bytes)
                return
            }
            var start = 0L
            var end = len - 1
            var partial = false
            if (range != null && range.startsWith("bytes=")) {
                val spec = range.removePrefix("bytes=").substringBefore(',')
                val a = spec.substringBefore('-').trim()
                val b = spec.substringAfter('-', "").trim()
                if (a.isEmpty()) {
                    b.toLongOrNull()?.let { n -> start = (len - n).coerceAtLeast(0) }
                } else {
                    start = a.toLongOrNull() ?: 0L
                    b.toLongOrNull()?.let { end = it.coerceAtMost(len - 1) }
                }
                if (start >= len) {
                    head(out, "416 Range Not Satisfiable", listOf("Content-Range: bytes */$len", "Content-Length: 0")); return
                }
                partial = true
            }
            val count = end - start + 1
            val headers = mutableListOf("Content-Type: $mime", "Content-Length: $count", "Accept-Ranges: bytes")
            if (partial) headers += "Content-Range: bytes $start-$end/$len"
            head(out, if (partial) "206 Partial Content" else "200 OK", headers)
            if (headOnly) return
            FileInputStream(afd.fileDescriptor).use { fis ->
                fis.channel.position(afd.startOffset + start)
                val buf = ByteArray(64 * 1024)
                var left = count
                while (left > 0) {
                    val r = fis.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (r < 0) break
                    out.write(buf, 0, r)
                    left -= r
                }
            }
        }
    }
}
