package se.skivbacken

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.text.Collator
import java.text.Normalizer
import java.util.Locale

data class Track(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val no: Int,
    val disc: Int,
    val durationMs: Long,
    val format: String,
    /** Folder on the phone, e.g. "Music/Kent/Isola/". */
    val folder: String,
    /** Average bitrate in kbps, 0 if unknown. */
    val kbps: Int = 0,
    val genre: String = "",
)

data class Album(
    val key: String,
    val albumId: Long,
    val title: String,
    val artist: String,
    val year: Int,
    val tracks: List<Track>,
    val format: String,
) {
    val letter: Char = letterOf(artist)
    val totalMs: Long get() = tracks.sumOf { it.durationMs }
    val discCount: Int get() = tracks.map { it.disc }.distinct().size
    /** The genre most tracks are tagged with, or "". */
    val genre: String get() = tracks.map { it.genre }.filter { it.isNotBlank() }
        .groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: ""
}

/** Divider letters in the order a Swedish record shop files them. */
val LETTERS: List<Char> = "#ABCDEFGHIJKLMNOPQRSTUVWXYZÅÄÖ".toList()

fun sortName(s: String): String = s.trim().let { if (it.startsWith("The ", ignoreCase = true)) it.substring(4) else it }

fun letterOf(artist: String): Char {
    val c = sortName(artist).firstOrNull()?.uppercaseChar() ?: return '#'
    if (c == 'Å' || c == 'Ä' || c == 'Ö') return c
    val base = Normalizer.normalize(c.toString(), Normalizer.Form.NFD).first()
    return if (base in 'A'..'Z') base else '#'
}

object LibraryRepo {
    private const val UNKNOWN = "<unknown>"

    /** Tracks of one album: same album name in the same folder, whatever the artist tag says. */
    private class Acc(val albumId: Long, val title: String, var year: Int) {
        val tracks = mutableListOf<Track>()
        val albumArtists = mutableListOf<String>()

        /** Album artist tag if any track has one, otherwise the artist on most tracks. */
        fun artist(): String {
            val pool = albumArtists.ifEmpty { tracks.map { it.artist } }
            return pool.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: "Okänd artist"
        }
    }

    fun load(context: Context): List<Album> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.ALBUM_ARTIST,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.DISC_NUMBER,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.RELATIVE_PATH,
            MediaStore.Audio.Media.GENRE,
            MediaStore.Audio.Media.BITRATE,
            MediaStore.Audio.Media.SIZE,
        )
        val sel = "${MediaStore.Audio.Media.MIME_TYPE} IN ('audio/flac','audio/x-flac','audio/mpeg','audio/mp3'," +
            "'audio/mp4','audio/x-m4a','audio/m4a','audio/aac','audio/alac')" +
            " OR ${MediaStore.Audio.Media.DISPLAY_NAME} LIKE '%.flac'" +
            " OR ${MediaStore.Audio.Media.DISPLAY_NAME} LIKE '%.mp3'" +
            " OR ${MediaStore.Audio.Media.DISPLAY_NAME} LIKE '%.m4a'"

        val map = LinkedHashMap<String, Acc>()
        context.contentResolver.query(collection, proj, sel, null, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iAlbumArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ARTIST)
            val iTrack = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val iDisc = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISC_NUMBER)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iYear = c.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
            val iMime = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val iPath = c.getColumnIndexOrThrow(MediaStore.Audio.Media.RELATIVE_PATH)
            val iGenre = c.getColumnIndex(MediaStore.Audio.Media.GENRE)
            val iBitrate = c.getColumnIndexOrThrow(MediaStore.Audio.Media.BITRATE)
            val iSize = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)

            while (c.moveToNext()) {
                fun str(i: Int): String? = c.getString(i)?.trim()?.takeIf { it.isNotEmpty() && it != UNKNOWN }
                val id = c.getLong(iId)
                val name = c.getString(iName) ?: ""
                val artist = str(iArtist) ?: "Okänd artist"
                val albumArtist = str(iAlbumArtist)
                val folder = c.getString(iPath) ?: ""
                val album = str(iAlbum) ?: "Okänt album"
                val title = str(iTitle) ?: name.substringBeforeLast('.')
                val trackRaw = c.getInt(iTrack)
                val disc = c.getString(iDisc)?.substringBefore('/')?.trim()?.toIntOrNull()
                    ?: (trackRaw / 1000).coerceAtLeast(1)
                val year = c.getInt(iYear)
                val mime = c.getString(iMime) ?: ""
                val format = when {
                    mime.contains("flac") || name.endsWith(".flac", ignoreCase = true) -> "FLAC"
                    name.endsWith(".m4a", ignoreCase = true) || mime.contains("mp4") || mime.contains("m4a") ||
                        mime.contains("aac") || mime.contains("alac") -> "M4A"
                    else -> "MP3"
                }

                val group = album.lowercase() + "\u0000" + folder.lowercase()
                val acc = map.getOrPut(group) { Acc(c.getLong(iAlbumId), album, year) }
                if (acc.year == 0) acc.year = year
                if (albumArtist != null) acc.albumArtists += albumArtist
                acc.tracks += Track(
                    id = id,
                    uri = ContentUris.withAppendedId(collection, id),
                    title = title,
                    artist = artist,
                    no = trackRaw % 1000,
                    disc = disc,
                    durationMs = c.getLong(iDur),
                    format = format,
                    folder = folder,
                    genre = if (iGenre >= 0) str(iGenre) ?: "" else "",
                    kbps = c.getInt(iBitrate).takeIf { it > 0 }?.let { it / 1000 }
                        ?: c.getLong(iDur).takeIf { it > 0 }?.let { (c.getLong(iSize) * 8 / it).toInt() } ?: 0,
                )
            }
        }

        val coll = Collator.getInstance(Locale.forLanguageTag("sv-SE")).apply { strength = Collator.PRIMARY }
        // Same artist and album in two folders (a copy, say) is still one album.
        val merged = LinkedHashMap<String, Pair<Acc, MutableList<Track>>>()
        for (a in map.values) {
            val key = a.artist().lowercase() + "\u0000" + a.title.lowercase()
            merged.getOrPut(key) { a to mutableListOf() }.second += a.tracks
        }
        // iTunes files a track by its own artist ("Kent & Titiyo/Isola/" next to "Kent/Isola/"),
        // so a song with a guest ends up in a folder of its own. Fold such strays into the main album.
        val byTitle = merged.entries.groupBy { e ->
            normTitle(e.value.first.title, e.value.second.flatMap { artistNames(it.artist) }.toSet())
        }
        for ((_, entries) in byTitle) {
            if (entries.size < 2) continue
            val sorted = entries.sortedByDescending { it.value.second.size }
            for (small in sorted.drop(1)) {
                val sa = small.value.first
                val host = sorted.firstOrNull { big ->
                    big !== small && big.key in merged && big.value.second.size >= small.value.second.size &&
                        belongTogether(big.value.second, small.value.second)
                } ?: continue
                host.value.second += small.value.second
                if (host.value.first.year == 0) host.value.first.year = sa.year
                merged.remove(small.key)
            }
        }
        return merged.map { (key, pair) ->
            val (a, all) = pair
            val tracks = all.distinctBy { it.id }.sortedWith { x, y ->
                when {
                    x.disc != y.disc -> x.disc - y.disc
                    x.no != y.no -> x.no - y.no
                    else -> coll.compare(x.title, y.title)
                }
            }
            Album(key, a.albumId, a.title, a.artist(), a.year, tracks,
                when {
                    tracks.any { it.format == "FLAC" } -> "FLAC"
                    tracks.any { it.format == "M4A" } -> "M4A"
                    else -> "MP3"
                })
        }.sortedWith { x, y ->
            val lx = LETTERS.indexOf(x.letter)
            val ly = LETTERS.indexOf(y.letter)
            if (lx != ly) return@sortedWith lx - ly
            val n = coll.compare(sortName(x.artist), sortName(y.artist))
            if (n != 0) return@sortedWith n
            if (x.year != y.year) x.year - y.year else coll.compare(x.title, y.title)
        }
    }
}

fun artUri(album: Album): Uri =
    ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), album.albumId)

/** Keeps only tracks inside the chosen folders. An empty choice keeps everything. */
fun filterFolders(all: List<Album>, chosen: Set<String>): List<Album> =
    if (chosen.isEmpty()) all else all.mapNotNull { a ->
        val kept = a.tracks.filter { t -> chosen.any { t.folder.startsWith(it, ignoreCase = true) } }
        when {
            kept.isEmpty() -> null
            kept.size == a.tracks.size -> a
            else -> a.copy(tracks = kept)
        }
    }

private val artistSplit = Regex(
    "\\s*(?:,|&|\\+|/|;|\\bfeat\\.?|\\bft\\.?|\\bfeaturing\\b|\\bwith\\b|\\bmed\\b|\\boch\\b|\\band\\b|\\bx\\b|\\bvs\\.?)\\s*",
    RegexOption.IGNORE_CASE,
)

/** Lower case without accents, so "Björk" and "Bjork" compare equal. */
fun fold(s: String): String =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

/** "Kent & Titiyo feat. X" → {"kent", "titiyo", "x"}. */
fun artistNames(s: String): Set<String> =
    fold(s).split(artistSplit).map { it.trim().trim('(', ')') }.filter { it.isNotEmpty() }.toSet()

/** "Björk - Debut" → "debut" when Björk is one of the artists; punctuation and accents ignored. */
fun normTitle(title: String, artists: Set<String>): String {
    var t = fold(title).trim()
    for (a in artists) {
        for (sep in listOf(" - ", " – ", " — ", ": ", " / ")) {
            if (t.startsWith(a + sep)) t = t.removePrefix(a + sep)
        }
    }
    return t.replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
}

/**
 * Same album name (checked by the caller); and either an artist in common, or a lone track
 * or two in a folder of the same name whose numbers fit into the main album's.
 */
private fun belongTogether(big: List<Track>, small: List<Track>): Boolean {
    val bigArtists = big.flatMap { artistNames(it.artist) }.toSet()
    val smallArtists = small.flatMap { artistNames(it.artist) }.toSet()
    if (bigArtists.intersect(smallArtists).isNotEmpty()) return true
    if (small.size > 2) return false
    val taken = big.map { it.disc to it.no }.toSet()
    if (small.any { it.no > 0 && (it.disc to it.no) in taken }) return false
    val leaf = { t: Track -> t.folder.trimEnd('/').substringAfterLast('/').lowercase() }
    return small.all { s -> big.any { leaf(it) == leaf(s) } }
}

data class Folder(val path: String, val name: String, val depth: Int, val count: Int)

/** Top two folder levels that hold music, with how many tracks each contains. */
fun foldersOf(albums: List<Album>): List<Folder> {
    val counts = HashMap<String, Int>()
    for (a in albums) for (t in a.tracks) {
        val segs = t.folder.trim('/').split('/').filter { it.isNotEmpty() }
        for (d in 1..minOf(2, segs.size)) {
            val p = segs.take(d).joinToString("/") + "/"
            counts[p] = (counts[p] ?: 0) + 1
        }
    }
    return counts.map { (p, n) -> Folder(p, p.trimEnd('/').substringAfterLast('/'), p.count { it == '/' }, n) }
        .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.path })
}


/**
 * The library as it was last read, kept on the phone so the crate shows at once on start.
 * Android counts every change to its music index ("generation"); if that count is unchanged
 * nothing has been added, removed or edited, and the library needn't be read again.
 */
object LibraryCache {
    private fun file(ctx: Context) = java.io.File(ctx.filesDir, "library.json")

    fun stamp(ctx: Context): String = runCatching {
        MediaStore.getVersion(ctx) + ":" + MediaStore.getGeneration(ctx, MediaStore.VOLUME_EXTERNAL)
    }.getOrDefault("")

    fun storedStamp(ctx: Context): String =
        ctx.getSharedPreferences("skivbacken", Context.MODE_PRIVATE).getString("lib_stamp", "").orEmpty()

    fun save(ctx: Context, albums: List<Album>, stamp: String) {
        val arr = org.json.JSONArray()
        for (a in albums) {
            val tr = org.json.JSONArray()
            for (t in a.tracks) {
                tr.put(
                    org.json.JSONObject().put("id", t.id).put("ti", t.title).put("ar", t.artist).put("no", t.no).put("di", t.disc)
                        .put("du", t.durationMs).put("fo", t.format).put("dir", t.folder).put("kb", t.kbps).put("ge", t.genre),
                )
            }
            arr.put(
                org.json.JSONObject().put("key", a.key).put("aid", a.albumId).put("ti", a.title).put("ar", a.artist)
                    .put("y", a.year).put("fo", a.format).put("tr", tr),
            )
        }
        val f = file(ctx)
        val tmp = java.io.File(f.path + ".tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(f)
        ctx.getSharedPreferences("skivbacken", Context.MODE_PRIVATE).edit().putString("lib_stamp", stamp).apply()
    }

    fun load(ctx: Context): List<Album>? = runCatching {
        val f = file(ctx)
        if (!f.exists()) return null
        val arr = org.json.JSONArray(f.readText())
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val tr = o.getJSONArray("tr")
            Album(
                key = o.getString("key"),
                albumId = o.getLong("aid"),
                title = o.getString("ti"),
                artist = o.getString("ar"),
                year = o.optInt("y"),
                tracks = (0 until tr.length()).map { j ->
                    val t = tr.getJSONObject(j)
                    val id = t.getLong("id")
                    Track(
                        id = id, uri = ContentUris.withAppendedId(base, id), title = t.getString("ti"), artist = t.getString("ar"),
                        no = t.optInt("no"), disc = t.optInt("di", 1), durationMs = t.optLong("du"), format = t.optString("fo"),
                        folder = t.optString("dir"), kbps = t.optInt("kb"), genre = t.optString("ge"),
                    )
                },
                format = o.optString("fo"),
            )
        }
    }.getOrNull()
}
