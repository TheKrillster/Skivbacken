package se.skivbacken.ui

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.Surface
import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext

/**
 * How far the phone is tilted from the way you are holding it, in screen directions,
 * each about -1..1. It follows the gravity sensor and slowly re-centres, so whatever
 * angle you hold the phone at becomes "straight on" after a few seconds.
 */
@Composable
fun rememberTilt(): Offset {
    val ctx = LocalContext.current
    var tilt by remember { mutableStateOf(Offset.Zero) }
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        var bx = Float.NaN
        var by = 0f
        var sx = 0f
        var sy = 0f
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val gx = e.values[0] / 9.81f
                val gy = e.values[1] / 9.81f
                if (bx.isNaN()) { bx = gx; by = gy }
                // Slowly follow the way the phone is held.
                bx += (gx - bx) * 0.012f
                by += (gy - by) * 0.012f
                val dx = gx - bx
                val dy = gy - by
                @Suppress("DEPRECATION")
                val rot = (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation
                val (x, y) = when (rot) {
                    Surface.ROTATION_90 -> dy to dx
                    Surface.ROTATION_180 -> dx to -dy
                    Surface.ROTATION_270 -> -dy to -dx
                    else -> -dx to dy
                }
                // Smooth out the shaking hand.
                sx += ((x * 3.2f).coerceIn(-1f, 1f) - sx) * 0.18f
                sy += ((y * 3.2f).coerceIn(-1f, 1f) - sy) * 0.18f
                tilt = Offset(sx, sy)
            }

            override fun onAccuracyChanged(s: Sensor?, a: Int) = Unit
        }
        if (sensor != null) sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm.unregisterListener(listener) }
    }
    return tilt
}
