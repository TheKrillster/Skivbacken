package se.skivbacken.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import se.skivbacken.Album
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin

/** Proportions of a direct-drive DJ turntable seen from straight above (width : depth). */
const val DeckAspect = 0.78f

private val Plinth = Color(0xFF1A1B1C)
private val PlinthEdge = Color(0xFF2B2D2F)
private val Rubber = Color(0xFF0D0D0E)
private val Silver = Color(0xFFC9CDD1)
private val SilverDark = Color(0xFF7D8287)
private val Print = Color(0xFFB9BDC1)

/**
 * A matte-black direct-drive turntable from above: strobe-dotted platter, the record with the
 * cover as its label, S-shaped tonearm with counterweight, start/stop, speed buttons and pitch fader.
 * The arm rests on its post when paused and tracks inward through the song while playing.
 */
@Composable
fun TurntableDeck(album: Album, angle: Float, playing: Boolean, progress: Float, modifier: Modifier) {
    val cover = rememberCover(album)
    val measurer = rememberTextMeasurer()
    val armTarget = if (playing) progress.coerceIn(0f, 1f) else -1f
    // -1 = parked on the rest, 0..1 = outer to inner groove.
    val armPos by animateFloatAsState(armTarget, tween(if (playing) 1100 else 800), label = "arm")
    val lift by animateFloatAsState(if (playing) 0f else 1f, tween(450), label = "lift")
    val labelHue = remember(album.key) { ((album.key.hashCode().toLong() and 0xffffffffL) % 360).toFloat() }

    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val u = w / 100f // one unit = 1 % of the deck's width

        // ---- plinth
        drawRoundRect(Color.Black.copy(alpha = 0.35f), Offset(u * 0.8f, u * 1.6f), size, CornerRadius(u * 1.6f))
        drawRoundRect(Brush.verticalGradient(listOf(PlinthEdge, Plinth, Color(0xFF141516))), size = size, cornerRadius = CornerRadius(u * 1.6f))
        drawRoundRect(Color.White.copy(alpha = 0.10f), Offset(u * 0.4f, u * 0.4f), Size(w - u * 0.8f, h - u * 0.8f), CornerRadius(u * 1.3f), style = Stroke(u * 0.25f))
        // Dust-cover hinges.
        for (fx in listOf(0.27f, 0.66f)) drawRoundRect(Color(0xFF3A3C3F), Offset(w * fx, 0f), Size(u * 7f, u * 1.6f), CornerRadius(u * 0.4f))

        // ---- platter, record and label
        val ctr = Offset(w * 0.40f, h * 0.47f)
        val platterR = h * 0.415f
        val recR = platterR * 0.905f
        drawCircle(Color.Black.copy(alpha = 0.45f), platterR * 1.02f, ctr + Offset(u * 0.6f, u * 1.0f))
        drawCircle(Color(0xFF151617), platterR, ctr)
        rotate(angle, ctr) {
            // Four rows of strobe dots on the platter rim.
            val rows = listOf(0.975f to 96, 0.955f to 100, 0.935f to 104, 0.915f to 108)
            for ((f, n) in rows) {
                val r = platterR * f
                val dot = platterR * 0.0085f
                for (i in 0 until n) {
                    val a = (i * 2 * Math.PI / n).toFloat()
                    drawCircle(Silver.copy(alpha = 0.9f), dot, Offset(ctr.x + r * cos(a), ctr.y + r * sin(a)))
                }
            }
        }
        drawCircle(Silver, platterR, ctr, style = Stroke(u * 0.35f))
        drawCircle(SilverDark, platterR * 0.995f, ctr, style = Stroke(u * 0.15f))

        // Record.
        drawCircle(Color.Black.copy(alpha = 0.5f), recR, ctr + Offset(u * 0.2f, u * 0.4f))
        drawCircle(Color(0xFF0E0E0F), recR, ctr)
        var gr = recR * 0.985f
        var k = 0
        while (gr > recR * 0.36f) {
            drawCircle(Color.White.copy(alpha = if (k % 6 == 0) 0.055f else 0.028f), gr, ctr, style = Stroke(u * 0.12f))
            gr -= recR * 0.011f
            k++
        }
        for (f in listOf(0.84f, 0.70f, 0.56f)) drawCircle(Color.Black, recR * f, ctr, style = Stroke(u * 0.35f))
        // Light on the vinyl stays put while the record turns.
        drawCircle(
            Brush.sweepGradient(
                listOf(
                    Color.Transparent, Color.White.copy(alpha = 0.11f), Color.Transparent, Color.Transparent,
                    Color.White.copy(alpha = 0.08f), Color.Transparent, Color.Transparent,
                ),
                ctr,
            ),
            recR, ctr,
        )
        // Label turns with the record.
        val labelR = recR * 0.34f
        rotate(angle, ctr) {
            val clip = Path().apply { addOval(androidx.compose.ui.geometry.Rect(ctr, labelR)) }
            clipPath(clip) {
                if (cover != null) {
                    drawImage(
                        cover,
                        srcOffset = IntOffset.Zero,
                        srcSize = IntSize(cover.width, cover.height),
                        dstOffset = IntOffset((ctr.x - labelR).roundToInt(), (ctr.y - labelR).roundToInt()),
                        dstSize = IntSize((labelR * 2).roundToInt(), (labelR * 2).roundToInt()),
                    )
                } else {
                    drawCircle(Color.hsv(labelHue, 0.5f, 0.62f), labelR, ctr)
                }
            }
        }
        drawCircle(Color.White.copy(alpha = 0.18f), labelR, ctr, style = Stroke(u * 0.2f))
        // Spindle.
        drawCircle(Color.Black.copy(alpha = 0.4f), u * 0.9f, ctr + Offset(u * 0.2f, u * 0.3f))
        drawCircle(Brush.radialGradient(listOf(Color.White, Silver, SilverDark), ctr - Offset(u * 0.3f, u * 0.3f), u * 1.2f), u * 0.85f, ctr)

        // ---- controls, left side
        // 45 rpm adapter holder.
        val adapter = Offset(w * 0.065f, h * 0.085f)
        drawCircle(Rubber, u * 3.2f, adapter)
        drawCircle(Color(0xFF2E3033), u * 2.4f, adapter)
        drawCircle(Rubber, u * 0.8f, adapter)
        // Power knob.
        val knob = Offset(w * 0.06f, h * 0.74f)
        drawCircle(Color.Black.copy(alpha = 0.4f), u * 3.4f, knob + Offset(u * 0.4f, u * 0.6f))
        drawCircle(Brush.radialGradient(listOf(Color(0xFF3A3C3F), Color(0xFF151617)), knob - Offset(u, u), u * 4.5f), u * 3.4f, knob)
        drawLine(Silver, knob, knob + Offset(-u * 1.6f, -u * 2.2f), u * 0.45f, StrokeCap.Round)
        drawCircle(if (playing) Color(0xFFE04A3A) else Color(0xFF5A1E18), u * 0.55f, Offset(w * 0.115f, h * 0.79f))
        // Start/stop button.
        val ss = Offset(w * 0.025f, h * 0.81f)
        drawRoundRect(Color.Black.copy(alpha = 0.5f), ss + Offset(u * 0.3f, u * 0.5f), Size(w * 0.12f, h * 0.12f), CornerRadius(u * 0.6f))
        drawRoundRect(Brush.verticalGradient(listOf(Color(0xFF34363A), Color(0xFF1C1D1F)), ss.y, ss.y + h * 0.12f), ss, Size(w * 0.12f, h * 0.12f), CornerRadius(u * 0.6f))
        label(measurer, "START/STOP", Offset(ss.x + w * 0.06f, ss.y + h * 0.06f), u * 1.5f)
        // 33 / 45 buttons; the active one is lit.
        for ((i, t) in listOf("33", "45").withIndex()) {
            val o = Offset(w * 0.165f + i * w * 0.075f, h * 0.905f)
            drawRoundRect(Color(0xFF26282B), o, Size(w * 0.065f, h * 0.045f), CornerRadius(u * 0.4f))
            if (i == 0) drawRoundRect(Color(0xFF8FE07A).copy(alpha = 0.7f), o + Offset(u * 0.6f, u * 0.4f), Size(u * 1.2f, u * 0.6f), CornerRadius(u * 0.2f))
            label(measurer, t, Offset(o.x + w * 0.0325f, o.y + h * 0.0225f), u * 1.6f)
        }

        // ---- right side: pitch fader, target light, name plate
        val fx = w * 0.95f
        val top = h * 0.48f
        val bottom = h * 0.86f
        drawRoundRect(Rubber, Offset(fx - u * 0.9f, top), Size(u * 1.8f, bottom - top), CornerRadius(u * 0.9f))
        for (i in 0..8) {
            val y = top + (bottom - top) * i / 8f
            drawLine(Print.copy(alpha = 0.5f), Offset(fx - u * 3.4f, y), Offset(fx - u * 2.1f, y), u * 0.18f)
        }
        val capY = (top + bottom) / 2f
        drawRoundRect(Color.Black.copy(alpha = 0.5f), Offset(fx - u * 2.4f + u * 0.3f, capY - u * 1.4f + u * 0.5f), Size(u * 4.8f, u * 2.8f), CornerRadius(u * 0.5f))
        drawRoundRect(Brush.verticalGradient(listOf(Color(0xFF4A4D51), Color(0xFF232527)), capY - u * 1.4f, capY + u * 1.4f), Offset(fx - u * 2.4f, capY - u * 1.4f), Size(u * 4.8f, u * 2.8f), CornerRadius(u * 0.5f))
        drawLine(Silver, Offset(fx - u * 2f, capY), Offset(fx + u * 2f, capY), u * 0.3f)
        label(measurer, "PITCH", Offset(fx, h * 0.90f), u * 1.4f)
        // Target light.
        val tl = Offset(w * 0.665f, h * 0.88f)
        drawCircle(Color.Black.copy(alpha = 0.5f), u * 1.6f, tl + Offset(u * 0.3f, u * 0.5f))
        drawCircle(Brush.radialGradient(listOf(Color(0xFF55585C), Color(0xFF1C1D1F)), tl - Offset(u * 0.4f, u * 0.4f), u * 2f), u * 1.5f, tl)
        // Name plate.
        val plate = Offset(w * 0.72f, h * 0.905f)
        drawRoundRect(Brush.verticalGradient(listOf(Color(0xFFDADDE0), Color(0xFF9DA2A7)), plate.y, plate.y + h * 0.06f), plate, Size(w * 0.15f, h * 0.06f), CornerRadius(u * 0.3f))
        label(measurer, "SKIVBACKEN", Offset(plate.x + w * 0.075f, plate.y + h * 0.03f), u * 1.5f, Color(0xFF1A1B1C), bold = true)

        // ---- tonearm
        val pivot = Offset(w * 0.855f, h * 0.20f)
        val armLen = hypot(pivot.x - ctr.x, pivot.y - ctr.y) * 1.035f
        val (outerA, innerA) = grooveAngles(pivot, armLen, ctr, recR * 0.95f, recR * 0.40f)
        val restA = 2f
        val a = if (armPos < 0f) restA + (outerA - restA) * (1f + armPos).coerceIn(0f, 1f) else outerA + (innerA - outerA) * armPos
        // Base with height ring and anti-skate dial.
        drawCircle(Color.Black.copy(alpha = 0.45f), u * 7.6f, pivot + Offset(u * 0.6f, u * 1f))
        drawCircle(Color(0xFF222326), u * 7.6f, pivot)
        drawCircle(Color(0xFF2E3033), u * 5.4f, pivot)
        for (i in 0 until 36) {
            val t = (i * 10.0 * Math.PI / 180).toFloat()
            drawLine(Print.copy(alpha = 0.35f), pivot + Offset(cos(t), sin(t)) * (u * 4.6f), pivot + Offset(cos(t), sin(t)) * (u * 5.2f), u * 0.14f)
        }
        val skate = Offset(w * 0.94f, h * 0.35f)
        drawCircle(Color(0xFF26282B), u * 2.1f, skate)
        drawLine(Silver, skate, skate + Offset(u * 1.2f, -u * 1.2f), u * 0.3f, StrokeCap.Round)
        // Arm rest post with clip.
        val rest = pivot + Offset(-armLen * sin(Math.toRadians(restA.toDouble())).toFloat(), armLen * cos(Math.toRadians(restA.toDouble())).toFloat()) * 0.62f
        drawCircle(Color(0xFF26282B), u * 1.6f, rest)
        drawRoundRect(Color(0xFF3A3C3F), rest - Offset(u * 0.7f, u * 2.2f), Size(u * 1.4f, u * 1.6f), CornerRadius(u * 0.3f))
        // Arm, first its shadow then the metal.
        for (pass in 0..1) {
            val off = if (pass == 0) Offset(u * (0.9f + lift * 1.2f), u * (1.3f + lift * 1.5f)) else Offset.Zero
            translate(off.x, off.y) {
                rotate(a, pivot) { drawArm(pivot, armLen, u, shadow = pass == 0) }
            }
        }
        // Pivot cap on top.
        drawCircle(Brush.radialGradient(listOf(Color(0xFF55595D), Color(0xFF1A1B1C)), pivot - Offset(u, u), u * 4f), u * 3.2f, pivot)
        drawCircle(Silver, u * 1.1f, pivot)
    }
}

/** Angles (degrees, clockwise from straight down) where the stylus sits on the outer and inner groove. */
private fun grooveAngles(pivot: Offset, len: Float, ctr: Offset, outerR: Float, innerR: Float): Pair<Float, Float> {
    fun at(r: Float): Float {
        var a = 0f
        while (a < 80f) {
            val rad = Math.toRadians(a.toDouble())
            val tip = Offset(pivot.x - len * sin(rad).toFloat(), pivot.y + len * cos(rad).toFloat())
            if ((tip - ctr).getDistance() <= r) return a
            a += 0.1f
        }
        return 30f
    }
    return at(outerR) to at(innerR)
}

/** S-shaped arm drawn pointing straight down from the pivot; the caller rotates it into place. */
private fun DrawScope.drawArm(pivot: Offset, len: Float, u: Float, shadow: Boolean) {
    val sh = Color.Black.copy(alpha = 0.38f)
    val metal = if (shadow) sh else Color(0xFF2A2C2F)
    val shine = if (shadow) Color.Transparent else Color.White.copy(alpha = 0.22f)
    // Counterweight behind the pivot.
    val cw = Offset(pivot.x - u * 2.6f, pivot.y - u * 13f)
    drawRoundRect(if (shadow) sh else Color(0xFF1C1D1F), cw, Size(u * 5.2f, u * 8.2f), CornerRadius(u * 1f))
    if (!shadow) {
        for (i in 1..6) drawLine(Color.White.copy(alpha = 0.10f), Offset(cw.x + u * 0.4f, cw.y + i * u * 1.15f), Offset(cw.x + u * 4.8f, cw.y + i * u * 1.15f), u * 0.15f)
        drawRoundRect(Color(0xFF3C3F43), Offset(pivot.x - u * 0.8f, pivot.y - u * 5f), Size(u * 1.6f, u * 5f), CornerRadius(u * 0.4f))
    }
    // The S-curve.
    val tube = Path().apply {
        moveTo(pivot.x, pivot.y)
        lineTo(pivot.x, pivot.y + len * 0.34f)
        cubicTo(pivot.x, pivot.y + len * 0.52f, pivot.x + len * 0.07f, pivot.y + len * 0.60f, pivot.x + len * 0.035f, pivot.y + len * 0.74f)
        cubicTo(pivot.x, pivot.y + len * 0.84f, pivot.x - len * 0.035f, pivot.y + len * 0.86f, pivot.x - len * 0.02f, pivot.y + len * 0.92f)
    }
    drawPath(tube, metal, style = Stroke(u * 1.25f, cap = StrokeCap.Round))
    drawPath(tube, shine, style = Stroke(u * 0.35f, cap = StrokeCap.Round))
    // Headshell, angled like the real thing, with cartridge and finger lift.
    val hs = Offset(pivot.x - u * 0.2f, pivot.y + len * 0.93f)
    rotate(20f, hs) {
        drawRoundRect(if (shadow) sh else Color(0xFF1E1F21), Offset(hs.x - u * 2.2f, hs.y - u * 1f), Size(u * 4.4f, u * 7.2f), CornerRadius(u * 0.6f))
        if (!shadow) {
            drawRoundRect(Color(0xFF3A3D41), Offset(hs.x - u * 1.5f, hs.y + u * 1.6f), Size(u * 3f, u * 4.6f), CornerRadius(u * 0.4f))
            drawRoundRect(Color(0xFFC0392B), Offset(hs.x - u * 1.0f, hs.y + u * 4.6f), Size(u * 2f, u * 1.4f), CornerRadius(u * 0.3f))
            drawCircle(Color(0xFF55595D), u * 0.35f, Offset(hs.x - u * 1.2f, hs.y + u * 0.4f))
            drawCircle(Color(0xFF55595D), u * 0.35f, Offset(hs.x + u * 1.2f, hs.y + u * 0.4f))
        }
        drawLine(if (shadow) sh else Color(0xFF3A3D41), Offset(hs.x + u * 2.2f, hs.y + u * 1.4f), Offset(hs.x + u * 5f, hs.y + u * 0.6f), u * 0.6f, StrokeCap.Round)
    }
}

private fun DrawScope.label(
    measurer: androidx.compose.ui.text.TextMeasurer,
    text: String,
    centre: Offset,
    sizePx: Float,
    color: Color = Print,
    bold: Boolean = false,
) {
    val style = TextStyle(color = color, fontSize = (sizePx / density).sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium, letterSpacing = 0.06.sp)
    val layout = measurer.measure(text, style)
    drawText(layout, topLeft = Offset(centre.x - layout.size.width / 2f, centre.y - layout.size.height / 2f))
}
