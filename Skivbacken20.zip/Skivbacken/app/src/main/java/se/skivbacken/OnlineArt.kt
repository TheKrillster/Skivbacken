package se.skivbacken

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Covers and disc images from MusicBrainz + Cover Art Archive.
 * Free, no account. "Front" is the sleeve, "Medium" is a photo of the disc itself.
 * Results are stored in the app's own folder, so each album is looked up once.
 */
object OnlineArt {
    private const val UA = "Skivbacken/1.0 ( personal music player )"
    private val mbLock = Mutex()
    private var lastMbCall = 0L

    data class Result(val front: File?, val disc: File?)

    private fun dir(ctx: Context) = File(ctx.filesDir, "art").apply { mkdirs() }
    fun base(album: Album) = Integer.toHexString(album.key.hashCode()) + "-" + album.key.length
    fun frontFile(ctx: Context, album: Album) = File(dir(ctx), "${base(album)}-front.jpg")
    fun discFile(ctx: Context, album: Album) = File(dir(ctx), "${base(album)}-disc.jpg")
    private fun missFile(ctx: Context, album: Album) = File(dir(ctx), "${base(album)}.none")
    /** A cover the user picked by hand; it wins over everything else. */
    fun customFile(ctx: Context, album: Album) = File(dir(ctx), "${base(album)}-custom.jpg")

    /** Forgets every stored picture for the album, so it is looked up again. */
    fun reset(ctx: Context, album: Album) {
        listOf(frontFile(ctx, album), discFile(ctx, album), missFile(ctx, album), customFile(ctx, album)).forEach {
            ArtCache.forget(it)
            it.delete()
        }
        ArtVersion.bump()
    }

    fun clearCustom(ctx: Context, album: Album) {
        val f = customFile(ctx, album)
        ArtCache.forget(f)
        f.delete()
        ArtVersion.bump()
    }

    data class CoverHit(val thumbUrl: String, val fullUrl: String, val title: String, val artist: String, val source: String)

    /** Free-text cover search in iTunes and Cover Art Archive. */
    suspend fun searchCovers(query: String): List<CoverHit> = withContext(Dispatchers.IO) {
        val hits = mutableListOf<CoverHit>()
        val q = URLEncoder.encode(query.trim(), "UTF-8")
        runCatching {
            val json = httpGet("https://itunes.apple.com/search?term=$q&entity=album&limit=24") ?: return@runCatching
            val arr = JSONObject(json).optJSONArray("results") ?: return@runCatching
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val art = o.optString("artworkUrl100").takeIf { it.isNotEmpty() } ?: continue
                hits += CoverHit(
                    art.replace("100x100bb", "300x300bb"), art.replace("100x100bb", "600x600bb"),
                    o.optString("collectionName"), o.optString("artistName"), "iTunes",
                )
            }
        }
        runCatching {
            val url = "https://musicbrainz.org/ws/2/release/?fmt=json&limit=12&query=$q"
            val json = mbLock.withLock {
                val wait = 1100 - (System.currentTimeMillis() - lastMbCall)
                if (wait > 0) delay(wait)
                lastMbCall = System.currentTimeMillis()
                httpGet(url)
            } ?: return@runCatching
            val arr = JSONObject(json).optJSONArray("releases") ?: return@runCatching
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("id").takeIf { it.isNotEmpty() } ?: continue
                val artist = o.optJSONArray("artist-credit")?.optJSONObject(0)?.optString("name") ?: ""
                hits += CoverHit(
                    "https://coverartarchive.org/release/$id/front-250", "https://coverartarchive.org/release/$id/front-500",
                    o.optString("title"), artist, "Cover Art Archive",
                )
            }
        }
        hits.distinctBy { it.fullUrl }
    }

    /** Downloads the chosen picture and makes it the album's cover. */
    suspend fun saveCustom(ctx: Context, album: Album, url: String): Boolean = withContext(Dispatchers.IO) {
        val bytes = runCatching { fetchBytes(url) }.getOrNull() ?: return@withContext false
        val f = customFile(ctx, album)
        f.writeBytes(bytes)
        ArtCache.forget(f)
        ArtVersion.bump()
        true
    }

    /** GET that follows redirects (also between http and https), returning the body or null. */
    fun fetchBytes(url: String): ByteArray? {
        var current = url.replace("http://", "https://")
        repeat(6) {
            val c = open(current)
            try {
                c.instanceFollowRedirects = false
                val code = c.responseCode
                if (code in 301..308) {
                    current = URL(URL(current), c.getHeaderField("Location") ?: return null).toString().replace("http://", "https://")
                    return@repeat
                }
                return if (code == 200) c.inputStream.use { it.readBytes() } else null
            } finally {
                c.disconnect()
            }
        }
        return null
    }

    suspend fun get(ctx: Context, album: Album): Result = withContext(Dispatchers.IO) {
        val front = frontFile(ctx, album)
        val disc = discFile(ctx, album)
        val miss = missFile(ctx, album)
        if (front.exists() || disc.exists() || miss.exists()) {
            return@withContext Result(front.takeIf { it.exists() }, disc.takeIf { it.exists() })
        }
        try {
            val releases = findReleases(album)
            for (mbid in releases) {
                val json = httpGet("https://coverartarchive.org/release/$mbid") ?: continue
                val images = JSONObject(json).optJSONArray("images") ?: continue
                var frontUrl: String? = null
                var discUrl: String? = null
                for (i in 0 until images.length()) {
                    val img = images.getJSONObject(i)
                    val types = img.optJSONArray("types")
                    val typeList = (0 until (types?.length() ?: 0)).map { types!!.getString(it) }
                    val thumbs = img.optJSONObject("thumbnails")
                    val url = (thumbs?.optString("500")?.takeIf { it.isNotEmpty() }
                        ?: thumbs?.optString("large")?.takeIf { it.isNotEmpty() }
                        ?: img.optString("image")).replace("http://", "https://")
                    if (url.isEmpty()) continue
                    if (frontUrl == null && (img.optBoolean("front") || "Front" in typeList)) frontUrl = url
                    if (discUrl == null && "Medium" in typeList) discUrl = url
                }
                frontUrl?.let { download(it, front) }
                discUrl?.let { download(it, disc) }
                if (front.exists()) break
            }
            if (!front.exists() && !disc.exists()) miss.createNewFile()
        } catch (e: Exception) {
            // Offline or the service is busy: try again next time the album is shown.
        }
        Result(front.takeIf { it.exists() }, disc.takeIf { it.exists() })
    }

    private suspend fun findReleases(album: Album): List<String> {
        fun clean(s: String) = s.replace("\"", " ").replace("\\", " ").trim()
        val q = "release:\"${clean(album.title)}\" AND artist:\"${clean(album.artist)}\""
        val url = "https://musicbrainz.org/ws/2/release/?fmt=json&limit=5&query=" + URLEncoder.encode(q, "UTF-8")
        // MusicBrainz asks for at most one request per second.
        val json = mbLock.withLock {
            val wait = 1100 - (System.currentTimeMillis() - lastMbCall)
            if (wait > 0) delay(wait)
            lastMbCall = System.currentTimeMillis()
            httpGet(url)
        } ?: return emptyList()
        val arr = JSONObject(json).optJSONArray("releases") ?: return emptyList()
        return (0 until arr.length()).map { arr.getJSONObject(it) }
            .filter { it.optInt("score", 0) >= 85 }
            .take(3)
            .map { it.getString("id") }
    }

    private fun open(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 15_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Accept", "application/json")
        }

    private fun httpGet(url: String): String? {
        val c = open(url)
        return try {
            if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
        } finally {
            c.disconnect()
        }
    }

    private fun download(url: String, target: File) {
        var c = open(url)
        try {
            // Cover Art Archive redirects to archive.org; follow by hand in case the host changes.
            var hops = 0
            while (c.responseCode in 301..308 && hops++ < 5) {
                val next = c.getHeaderField("Location") ?: break
                c.disconnect()
                c = open(URL(URL(url), next).toString().replace("http://", "https://"))
            }
            if (c.responseCode != 200) return
            val tmp = File(target.path + ".part")
            c.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            tmp.renameTo(target)
        } finally {
            c.disconnect()
        }
    }
}
