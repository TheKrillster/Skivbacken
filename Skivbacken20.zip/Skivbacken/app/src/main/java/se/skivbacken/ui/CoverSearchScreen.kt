package se.skivbacken.ui

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import se.skivbacken.Album
import se.skivbacken.MainViewModel
import se.skivbacken.OnlineArt
import se.skivbacken.RemoteImages

/** Search iTunes and Cover Art Archive by hand and pick the cover to use. */
@Composable
fun CoverSearchScreen(vm: MainViewModel, album: Album, onDone: () -> Unit) {
    val c = LocalSkiv.current
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current
    val scope = rememberCoroutineScope()
    var query by remember(album.key) { mutableStateOf("${album.artist} ${album.title}") }
    var run by remember(album.key) { mutableIntStateOf(0) }
    var hits by remember(album.key) { mutableStateOf<List<OnlineArt.CoverHit>?>(null) }
    var saving by remember { mutableStateOf(false) }
    val failed = remember(album.key) { mutableStateListOf<String>() }
    val hasCustom = remember(album.key, se.skivbacken.ArtVersion.value) { OnlineArt.customFile(ctx, album).exists() }

    LaunchedEffect(album.key, run) {
        hits = null
        failed.clear()
        hits = OnlineArt.searchCovers(query)
    }

    fun search() {
        focus.clearFocus()
        run++
    }

    Column(Modifier.fillMaxSize().background(c.panel).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            PressButton(onClick = onDone, size = 48.dp) { Glyph(Ic.Down, c.ink, Modifier.size(26.dp)) }
            Column(Modifier.weight(1f)) {
                Text("Sök omslag", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, letterSpacing = (-0.02).em)
                Text(album.title, fontSize = 13.sp, color = c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("Artist och album") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { search() }),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = c.sticker, focusedLabelColor = c.sticker, cursorColor = c.sticker),
            )
            Text(
                "Sök",
                modifier = Modifier
                    .padding(start = 10.dp)
                    .clip(RoundedCornerShape(50))
                    .background(c.ink)
                    .clickable { search() }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = c.panel,
            )
        }
        if (hasCustom) {
            Text(
                "Använd filens eget omslag igen",
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(50))
                    .background(c.chip)
                    .clickable {
                        OnlineArt.clearCustom(ctx, album)
                        Toast.makeText(ctx, "Omslaget är återställt", Toast.LENGTH_SHORT).show()
                        onDone()
                    }
                    .padding(horizontal = 14.dp, vertical = 7.dp),
                fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = c.ink,
            )
        }

        val list = hits
        val shown = list?.filter { it.thumbUrl !in failed }
        when {
            list == null -> Text("Söker…", modifier = Modifier.padding(16.dp), fontSize = 15.sp, color = c.inkSoft)
            shown.isNullOrEmpty() -> Text(
                "Hittade inga omslag. Prova att ändra sökningen, till exempel bara albumets namn.",
                modifier = Modifier.padding(16.dp), fontSize = 15.sp, color = c.inkSoft,
            )
            else -> {
                Text(
                    if (saving) "Hämtar bilden…" else "Tryck på omslaget du vill använda.",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp), fontSize = 13.sp, color = c.inkSoft,
                )
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 104.dp),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    items(shown, key = { it.fullUrl }) { hit ->
                        Hit(hit, onFailed = { if (hit.thumbUrl !in failed) failed.add(hit.thumbUrl) }) {
                            if (saving) return@Hit
                            saving = true
                            scope.launch {
                                val ok = OnlineArt.saveCustom(ctx, album, hit.fullUrl)
                                saving = false
                                if (ok) {
                                    Toast.makeText(ctx, "Omslaget är bytt", Toast.LENGTH_SHORT).show()
                                    onDone()
                                } else {
                                    Toast.makeText(ctx, "Kunde inte hämta bilden. Prova en annan.", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                }
            }
        }
        Text(
            "Bilder från iTunes och Cover Art Archive",
            modifier = Modifier.navigationBarsPadding().padding(16.dp), fontSize = 11.sp, color = c.inkSoft,
        )
    }
}

@Composable
private fun Hit(hit: OnlineArt.CoverHit, onFailed: () -> Unit, onPick: () -> Unit) {
    val c = LocalSkiv.current
    val img by produceState<ImageBitmap?>(null, hit.thumbUrl) {
        value = RemoteImages.load(hit.thumbUrl)
        if (value == null) onFailed()
    }
    val shape = RoundedCornerShape(3.dp)
    Column(Modifier.clickable(onClick = onPick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f).shadow(6.dp, shape).clip(shape).background(c.chip)) {
            img?.let { Image(it, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        }
        Text(hit.title, modifier = Modifier.padding(top = 6.dp), fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = c.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("${hit.artist} · ${hit.source}", fontSize = 11.sp, color = c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
