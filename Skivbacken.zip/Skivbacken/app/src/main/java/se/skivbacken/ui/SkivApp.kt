package se.skivbacken.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import se.skivbacken.Album
import se.skivbacken.MainViewModel
import se.skivbacken.Screen

@Composable
fun SkivApp(vm: MainViewModel, onRequestPermission: () -> Unit) {
    val c = LocalSkiv.current
    Box(Modifier.fillMaxSize().background(c.wall)) {
        if (!vm.hasPermission) {
            PermissionScreen(onRequestPermission)
        } else {
            val screen = vm.screen
            // The crate is not drawn at all while a record plays.
            if (screen !is Screen.Playing) {
                CrateScreen(vm, onOpen = { vm.screen = Screen.AlbumView(it.key) })
            }
            val open = (screen as? Screen.AlbumView)?.let { s -> vm.albums.firstOrNull { it.key == s.key } }
            val shown = remember { arrayOfNulls<Album>(1) }
            if (open != null) shown[0] = open
            AnimatedVisibility(
                visible = open != null,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut(),
            ) {
                shown[0]?.let { AlbumScreen(it, vm, onBack = { vm.screen = Screen.Library }) }
            }
            AnimatedVisibility(
                visible = screen is Screen.Playing,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut(),
            ) {
                PlayingScreen(vm, onBack = { vm.screen = Screen.Library })
            }
        }
    }
    BackHandler(enabled = vm.screen != Screen.Library) { vm.screen = Screen.Library }
}

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    val c = LocalSkiv.current
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Skivbacken", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, letterSpacing = (-0.02).em)
        Text(
            "Appen behöver komma åt musiken på telefonen för att hitta dina FLAC- och MP3-filer.",
            modifier = Modifier.padding(top = 10.dp, bottom = 20.dp), fontSize = 16.sp, color = c.inkSoft,
        )
        Button(onClick = onRequest, colors = ButtonDefaults.buttonColors(containerColor = c.sticker, contentColor = c.stickerInk)) {
            Text("Ge åtkomst till musik", fontWeight = FontWeight.Bold)
        }
        Text(
            "Händer inget? Öppna Inställningar › Appar › Skivbacken › Behörigheter och tillåt Musik och ljud.",
            modifier = Modifier.padding(top = 16.dp), fontSize = 13.sp, color = c.inkSoft,
        )
    }
}
