package se.skivbacken

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.text.Collator
import java.text.Normalizer
import java.util.Locale

data class Track(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val no: Int,
    val disc: Int,
    val durationMs: Long,
    val format: String,
    /** Folder on the phone, e.g. "Music/Kent/Isola/". */
    val folder: String,
)

data class Album(
    val key: String,
    val albumId: Long,
    val title: String,
    val artist: String,
    val year: Int,
    val tracks: List<Track>,
    val format: String,
) {
    val letter: Char = letterOf(artist)
    val totalMs: Long get() = tracks.sumOf { it.durationMs }
    val discCount: Int get() = tracks.map { it.disc }.distinct().size
}

/** Divider letters in the order a Swedish record shop files them. */
val LETTERS: List<Char> = "#ABCDEFGHIJKLMNOPQRSTUVWXYZÅÄÖ".toList()

fun sortName(s: String): String = s.trim().let { if (it.startsWith("The ", ignoreCase = true)) it.substring(4) else it }

fun letterOf(artist: String): Char {
    val c = sortName(artist).firstOrNull()?.uppercaseChar() ?: return '#'
    if (c == 'Å' || c == 'Ä' || c == 'Ö') return c
    val base = Normalizer.normalize(c.toString(), Normalizer.Form.NFD).first()
    return if (base in 'A'..'Z') base else '#'
}

object LibraryRepo {
    private const val UNKNOWN = "<unknown>"

    private class Acc(val albumId: Long, val title: String, val artist: String, var year: Int) {
        val tracks = mutableListOf<Track>()
    }

    fun load(context: Context): List<Album> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.ALBUM_ARTIST,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.DISC_NUMBER,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.RELATIVE_PATH,
        )
        val sel = "${MediaStore.Audio.Media.MIME_TYPE} IN ('audio/flac','audio/x-flac','audio/mpeg','audio/mp3')" +
            " OR ${MediaStore.Audio.Media.DISPLAY_NAME} LIKE '%.flac'" +
            " OR ${MediaStore.Audio.Media.DISPLAY_NAME} LIKE '%.mp3'"

        val map = LinkedHashMap<String, Acc>()
        context.contentResolver.query(collection, proj, sel, null, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iAlbumArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ARTIST)
            val iTrack = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val iDisc = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISC_NUMBER)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iYear = c.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
            val iMime = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val iPath = c.getColumnIndexOrThrow(MediaStore.Audio.Media.RELATIVE_PATH)

            while (c.moveToNext()) {
                fun str(i: Int): String? = c.getString(i)?.trim()?.takeIf { it.isNotEmpty() && it != UNKNOWN }
                val id = c.getLong(iId)
                val name = c.getString(iName) ?: ""
                val artist = str(iArtist) ?: "Okänd artist"
                val albumArtist = str(iAlbumArtist) ?: artist
                val album = str(iAlbum) ?: "Okänt album"
                val title = str(iTitle) ?: name.substringBeforeLast('.')
                val trackRaw = c.getInt(iTrack)
                val disc = c.getString(iDisc)?.substringBefore('/')?.trim()?.toIntOrNull()
                    ?: (trackRaw / 1000).coerceAtLeast(1)
                val year = c.getInt(iYear)
                val mime = c.getString(iMime) ?: ""
                val format = if (mime.contains("flac") || name.endsWith(".flac", ignoreCase = true)) "FLAC" else "MP3"

                val key = albumArtist.lowercase() + "\u0000" + album.lowercase()
                val acc = map.getOrPut(key) { Acc(c.getLong(iAlbumId), album, albumArtist, year) }
                if (acc.year == 0) acc.year = year
                acc.tracks += Track(
                    id = id,
                    uri = ContentUris.withAppendedId(collection, id),
                    title = title,
                    artist = artist,
                    no = trackRaw % 1000,
                    disc = disc,
                    durationMs = c.getLong(iDur),
                    format = format,
                    folder = c.getString(iPath) ?: "",
                )
            }
        }

        val coll = Collator.getInstance(Locale.forLanguageTag("sv-SE")).apply { strength = Collator.PRIMARY }
        return map.map { (key, a) ->
            val tracks = a.tracks.sortedWith { x, y ->
                when {
                    x.disc != y.disc -> x.disc - y.disc
                    x.no != y.no -> x.no - y.no
                    else -> coll.compare(x.title, y.title)
                }
            }
            Album(key, a.albumId, a.title, a.artist, a.year, tracks,
                if (tracks.any { it.format == "FLAC" }) "FLAC" else "MP3")
        }.sortedWith { x, y ->
            val lx = LETTERS.indexOf(x.letter)
            val ly = LETTERS.indexOf(y.letter)
            if (lx != ly) return@sortedWith lx - ly
            val n = coll.compare(sortName(x.artist), sortName(y.artist))
            if (n != 0) return@sortedWith n
            if (x.year != y.year) x.year - y.year else coll.compare(x.title, y.title)
        }
    }
}

data class Folder(val path: String, val name: String, val depth: Int, val count: Int)

/** Top two folder levels that hold music, with how many tracks each contains. */
fun foldersOf(albums: List<Album>): List<Folder> {
    val counts = HashMap<String, Int>()
    for (a in albums) for (t in a.tracks) {
        val segs = t.folder.trim('/').split('/').filter { it.isNotEmpty() }
        for (d in 1..minOf(2, segs.size)) {
            val p = segs.take(d).joinToString("/") + "/"
            counts[p] = (counts[p] ?: 0) + 1
        }
    }
    return counts.map { (p, n) -> Folder(p, p.trimEnd('/').substringAfterLast('/'), p.count { it == '/' }, n) }
        .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.path })
}
