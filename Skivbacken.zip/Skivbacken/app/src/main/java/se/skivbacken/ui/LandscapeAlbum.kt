package se.skivbacken.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import se.skivbacken.Album
import se.skivbacken.MainViewModel
import se.skivbacken.OnlineArt
import se.skivbacken.Screen

/**
 * Landscape album page, used both for an opened record and for the player:
 * cover on the left with the vinyl sliding out behind it, tabs for tracks, version and lyrics on the right,
 * and a slim control row at the bottom while something plays.
 */
@Composable
fun LandscapeAlbum(vm: MainViewModel, album: Album, onBack: () -> Unit) {
    val c = LocalSkiv.current
    val playingThis = vm.currentAlbum?.key == album.key
    var tab by remember(album.key) { mutableIntStateOf(0) }
    Column(
        Modifier
            .fillMaxSize()
            .background(c.panel)
            .statusBarsPadding()
            // Keep clear of the navigation buttons and camera cut-out at the sides.
            .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal)),
    ) {
        Row(Modifier.weight(1f).fillMaxWidth()) {
            // ---- left: cover, vinyl, title
            Column(Modifier.weight(0.44f).fillMaxHeight().padding(start = 8.dp, end = 8.dp, top = 4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PressButton(onClick = onBack, size = 40.dp) { Glyph(Ic.Down, c.ink, Modifier.size(24.dp)) }
                    Spacer(Modifier.weight(1f))
                }
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(start = 12.dp)) {
                    DiscModes(vm, album, playing = playingThis && vm.isPlaying, maxW = maxWidth, maxH = maxHeight)
                }
                Column(Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp)) {
                    Text(album.title, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${album.artist}  ›", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = c.sticker, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    val spec = rememberSpec(album.tracks.first())
                    val chips = listOfNotNull(
                        album.year.takeIf { it > 0 }?.toString(),
                        album.genre.ifBlank { null }?.uppercase(),
                        spec?.takeIf { it.known }?.let { s -> if (s.bits > 0) "${s.codec} ${s.short}" else s.codec } ?: album.format,
                    )
                    Row(Modifier.padding(top = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        chips.forEach { OutlinedChip(it) }
                    }
                }
            }
            // ---- right: tabs
            Column(Modifier.weight(0.56f).fillMaxHeight().padding(end = 12.dp, top = 8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Låtar", "Version", "Text").forEachIndexed { i, label ->
                        val on = i == tab
                        Text(
                            label,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(50))
                                .background(if (on) c.ink else c.chip)
                                .clickable { tab = i }
                                .padding(vertical = 7.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, color = if (on) c.panel else c.ink,
                        )
                    }
                }
                Box(
                    Modifier
                        .padding(top = 8.dp, bottom = 6.dp)
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(c.wall.copy(alpha = 0.55f)),
                ) {
                    when (tab) {
                        0 -> TracksTab(vm, album)
                        1 -> VersionTab(album)
                        else -> {
                            val t = if (playingThis) vm.currentTrack else null
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                                if (t != null) LyricsView(album, t, vm.positionMs)
                                else Text(
                                    "Spela en låt från skivan för att se texten.",
                                    modifier = Modifier.padding(16.dp), fontSize = 14.sp, color = c.inkSoft,
                                )
                            }
                        }
                    }
                }
            }
        }
        if (vm.currentTrack != null) LandscapePlayerRow(vm)
        Spacer(Modifier.navigationBarsPadding())
    }
}

/**
 * Tap to step through the same looks as standing up: sleeve with the record sliding out,
 * spinning CD, turntable. The choice is shared with portrait. Long press to change the cover.
 */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun DiscModes(
    vm: MainViewModel,
    album: Album,
    playing: Boolean,
    maxW: androidx.compose.ui.unit.Dp,
    maxH: androidx.compose.ui.unit.Dp,
) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("skivbacken", android.content.Context.MODE_PRIVATE) }
    var mode by remember { mutableIntStateOf(prefs.getInt("discMode", 0).coerceIn(0, 2)) }
    var label by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(label) {
        if (label != null) {
            kotlinx.coroutines.delay(1100)
            label = null
        }
    }
    val labelAlpha by animateFloatAsState(if (label != null) 1f else 0f, tween(250), label = "modeLabel")
    var lastLabel by remember { mutableStateOf("") }
    if (label != null) lastLabel = label!!
    var coverMenu by remember { mutableStateOf(false) }
    val vinyl = mode == 2
    val angle = rememberSpin(playing && mode != 0, degPerSec = if (vinyl) 200f else 1300f, response = if (vinyl) 4f else 1.2f)
    val progress = if (vm.durationMs > 0) (vm.positionMs.toFloat() / vm.durationMs).coerceIn(0f, 1f) else 0f

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.CenterStart) {
        val tap = Modifier.combinedClickable(
            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
            indication = null,
            onLongClick = { coverMenu = true },
        ) {
            mode = (mode + 1) % 3
            prefs.edit().putInt("discMode", mode).apply()
            label = when (mode) { 0 -> "FODRAL"; 1 -> "CD"; else -> "VINYL" }
        }
        Box {
            when (mode) {
                0 -> Box(tap) { SleeveWithVinyl(album, playing, minOf(maxH, maxW * 0.72f)) }
                1 -> {
                    val d = minOf(maxH, maxW) * 0.96f
                    CdFace(album, angle, Modifier.size(d).shadow(18.dp, CircleShape).then(tap))
                }
                else -> {
                    val w = minOf(maxW, maxH / DeckAspect)
                    TurntableDeck(album, angle, playing, progress, Modifier.size(w, w * DeckAspect).then(tap))
                }
            }
            if (labelAlpha > 0f) {
                Text(
                    lastLabel,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .graphicsLayer { alpha = labelAlpha }
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF0E100D).copy(alpha = 0.8f))
                        .padding(horizontal = 12.dp, vertical = 5.dp),
                    fontSize = 14.sp, letterSpacing = 0.2.em, fontWeight = FontWeight.SemiBold, color = Color(0xFFEBE8DE),
                )
            }
            CoverMenu(vm, album, coverMenu, onDismiss = { coverMenu = false })
        }
    }
}

@Composable
private fun OutlinedChip(text: String) {
    val c = LocalSkiv.current
    Text(
        text,
        modifier = Modifier.border(1.dp, c.ink.copy(alpha = 0.35f), RoundedCornerShape(50)).padding(horizontal = 9.dp, vertical = 3.dp),
        fontSize = 11.sp, letterSpacing = 0.08.em, color = c.ink, maxLines = 1,
    )
}

/**
 * The sleeve in 3D with the record half out to the right. Tilting the phone turns the sleeve
 * and moves a glare across it; the record slides out when the page opens and spins while it plays.
 */
@Composable
internal fun SleeveWithVinyl(album: Album, playing: Boolean, dim: androidx.compose.ui.unit.Dp) {
    val tilt = rememberTilt()
    var shown by remember(album.key) { mutableStateOf(false) }
    LaunchedEffect(album.key) { shown = true }
    val out by animateFloatAsState(if (shown) 1f else 0f, tween(900, delayMillis = 150), label = "vinylOut")
    val angle = rememberSpin(playing, degPerSec = 200f, response = 4f)
    val cover = rememberCover(album)
    val disc = rememberDiscImage(album)
    val labelColour = remember(album.key) { Color.hsv(((album.key.hashCode().toLong() and 0xffffffffL) % 360).toFloat(), 0.45f, 0.55f) }

    Box(Modifier.size(dim * 1.38f, dim)) {
        // Record, behind the sleeve. Parallax: it moves a little against the tilt.
        Canvas(
            Modifier
                .size(dim * 0.96f)
                .align(Alignment.CenterStart)
                .offset(x = dim * (0.02f + 0.38f * out) - (tilt.x * 6).dp, y = (tilt.y * 3).dp),
        ) {
            val r = size.minDimension / 2f
            val ctr = center
            drawCircle(Color.Black.copy(alpha = 0.35f), r, ctr + Offset(3f, 6f))
            drawCircle(Color(0xFF111112), r, ctr)
            var gr = r * 0.97f
            var k = 0
            while (gr > r * 0.36f) {
                drawCircle(Color.White.copy(alpha = if (k % 6 == 0) 0.06f else 0.03f), gr, ctr, style = Stroke(1f))
                gr -= r * 0.013f
                k++
            }
            rotate(angle, ctr) {
                if (disc != null || cover != null) {
                    val img = (disc ?: cover)!!
                    val lr = r * 0.34f
                    drawCircle(labelColour, lr, ctr)
                    val path = androidx.compose.ui.graphics.Path().apply { addOval(androidx.compose.ui.geometry.Rect(ctr, lr)) }
                    clipPath(path) {
                        drawImage(
                            img,
                            dstOffset = androidx.compose.ui.unit.IntOffset((ctr.x - lr).toInt(), (ctr.y - lr).toInt()),
                            dstSize = androidx.compose.ui.unit.IntSize((lr * 2).toInt(), (lr * 2).toInt()),
                        )
                    }
                } else drawCircle(labelColour, r * 0.34f, ctr)
            }
            drawCircle(
                Brush.sweepGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.12f), Color.Transparent, Color.Transparent, Color.White.copy(alpha = 0.09f), Color.Transparent), ctr),
                r, ctr,
            )
            drawCircle(Color(0xFFD9DCDF), r * 0.025f, ctr)
        }
        // Sleeve in front, turned by the tilt.
        val shape = RoundedCornerShape(3.dp)
        Box(
            Modifier
                .size(dim)
                .align(Alignment.CenterStart)
                .graphicsLayer {
                    rotationY = tilt.x * 14f
                    rotationX = -tilt.y * 14f
                    cameraDistance = 9f * density
                }
                .shadow(16.dp, shape)
                .clip(shape)
                .drawWithContent {
                    drawContent()
                    // Glare that slides with the tilt.
                    val gx = size.width * (0.5f + tilt.x * 0.6f)
                    drawRect(
                        Brush.linearGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.22f), Color.Transparent),
                            start = Offset(gx - size.width * 0.4f, 0f),
                            end = Offset(gx + size.width * 0.4f, size.height * (0.6f + tilt.y * 0.4f)),
                        ),
                    )
                },
        ) {
            AlbumArt(album, Modifier.fillMaxSize(), dim)
            Sticker(album, dim)
        }
    }
}

@Composable
private fun TracksTab(vm: MainViewModel, album: Album) {
    val c = LocalSkiv.current
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 8.dp)) {
        Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${album.tracks.size} spår · ${fmtTotal(album.totalMs)}", modifier = Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = c.ink)
            Text(
                "Spela skivan",
                modifier = Modifier.clip(RoundedCornerShape(50)).background(c.sticker).clickable { vm.play(album, 0) }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                fontSize = 13.sp, fontWeight = FontWeight.Bold, color = c.stickerInk,
            )
            Text(
                "Lägg i kön",
                modifier = Modifier.padding(start = 6.dp).border(1.dp, c.ink.copy(alpha = 0.35f), RoundedCornerShape(50))
                    .clickable {
                        vm.addToQueue(album, album.tracks)
                        android.widget.Toast.makeText(ctx, "Skivan lagd i kön", android.widget.Toast.LENGTH_SHORT).show()
                    }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = c.ink,
            )
        }
        album.tracks.forEachIndexed { i, t ->
            val now = vm.currentAlbum?.key == album.key && vm.currentTrackIndex == i
            val progress = if (now && vm.durationMs > 0) (vm.positionMs.toFloat() / vm.durationMs).coerceIn(0f, 1f) else 0f
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { vm.jumpTo(album, i) }
                    .drawWithContent {
                        if (now) drawRect(c.sticker.copy(alpha = 0.14f), size = Size(size.width * progress, size.height))
                        drawContent()
                    }
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(28.dp).clip(RoundedCornerShape(6.dp)).background(if (now) c.sticker else c.chip),
                    contentAlignment = Alignment.Center,
                ) {
                    Glyph(if (now && vm.isPlaying) Ic.Pause else Ic.Play, if (now) c.stickerInk else c.ink, Modifier.size(14.dp))
                }
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text(t.title, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, color = if (now) c.sticker else c.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(t.artist, fontSize = 12.sp, color = c.sticker.copy(alpha = 0.8f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text(fmtTime(t.durationMs), fontSize = 12.sp, color = c.inkSoft)
            }
        }
    }
}

@Composable
private fun VersionTab(album: Album) {
    val c = LocalSkiv.current
    val ctx = LocalContext.current
    val first = album.tracks.first()
    val spec = rememberSpec(first)
    var attempt by remember(album.key) { mutableIntStateOf(0) }
    val lookup by produceState<OnlineArt.Lookup?>(null, album.key, attempt) {
        value = null
        value = OnlineArt.release(ctx, album)
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 10.dp)) {
        @Composable
        fun row(label: String, value: String, accent: Boolean = false) {
            if (value.isBlank()) return
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
                Text(label, modifier = Modifier.width(110.dp), fontSize = 13.sp, color = c.inkSoft)
                Text(
                    value, modifier = Modifier.weight(1f), fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    color = if (accent) c.sticker else c.ink, textAlign = androidx.compose.ui.text.style.TextAlign.End,
                )
            }
        }
        val r = (lookup as? OnlineArt.Lookup.Found)?.release
        if (r != null) {
            row("Skivbolag", r.label.uppercase())
            row("Katalognr", r.catNo)
            row("Utgiven", listOf(r.date, r.country).filter { it.isNotBlank() }.joinToString(", "))
            row("Format", r.format, accent = true)
            row("Streckkod", r.barcode)
        } else {
            val l = lookup
            Text(
                when (l) {
                    null -> "Söker utgåvan på MusicBrainz…"
                    is OnlineArt.Lookup.Failed -> l.why
                    else -> "MusicBrainz har ingen utgåva som matchar \"${OnlineArt.cleanTitle(album.title)}\" av ${album.artist}."
                },
                modifier = Modifier.padding(vertical = 6.dp), fontSize = 13.sp, color = c.inkSoft,
            )
            if (l != null) {
                Text(
                    "Sök igen",
                    modifier = Modifier
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(50))
                        .background(c.chip)
                        .clickable { OnlineArt.forgetRelease(ctx, album); attempt++ }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = c.ink,
                )
            }
        }
        Box(Modifier.padding(vertical = 6.dp).fillMaxWidth().height(1.dp).background(c.line))
        row("Fil", spec?.takeIf { it.known }?.let { s -> listOfNotNull(s.codec, if (s.bits > 0) "${s.bits}-bit" else null, s.khzLabel).joinToString(" · ") } ?: album.format)
        row("Bithastighet", first.kbps.takeIf { it > 0 }?.let { "%,d kbps".format(java.util.Locale.forLanguageTag("sv-SE"), it) } ?: "")
        row("Spår", "${album.tracks.size}" + if (album.discCount > 1) " på ${album.discCount} skivor" else "")
        row("Speltid", fmtTotal(album.totalMs))
        row("Genre", album.genre)
        row("Mapp", first.folder.trimEnd('/'))
        if (r != null) Text("Utgåva från MusicBrainz", modifier = Modifier.padding(top = 8.dp), fontSize = 11.sp, color = c.inkSoft)
    }
}

/** Slim player row along the bottom in landscape. */
@Composable
internal fun LandscapePlayerRow(vm: MainViewModel) {
    val c = LocalSkiv.current
    val t = vm.currentTrack ?: return
    val a = vm.currentAlbum ?: return
    Row(
        Modifier.fillMaxWidth().shadow(8.dp).background(c.panel).padding(horizontal = 12.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(4.dp)).clickable { vm.screen = Screen.Playing }) {
            AlbumArt(a, Modifier.fillMaxSize(), 38.dp, showText = false)
        }
        Column(Modifier.width(170.dp).padding(horizontal = 10.dp).clickable { vm.screen = Screen.Playing }) {
            Text(t.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = c.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(t.artist, fontSize = 12.sp, color = c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        SeekBar(vm.positionMs, vm.durationMs, onSeek = { vm.seek(it) }, modifier = Modifier.weight(1f))
        Controls(vm, Modifier.width(280.dp).padding(start = 8.dp))
    }
}
