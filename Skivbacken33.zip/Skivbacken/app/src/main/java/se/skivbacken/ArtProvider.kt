package se.skivbacken

import android.content.ContentProvider
import android.content.ContentUris
import android.content.ContentValues
import android.database.Cursor
import android.graphics.Bitmap
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Size
import java.io.File
import java.io.FileNotFoundException

/**
 * Serves album covers as content://se.skivbacken.art/t/<first track id>/<album base>.
 * Android Auto and the system media controls run in other apps and can't read the app's own files,
 * so they fetch covers from here. Picked-by-hand cover first, then the one in the music file
 * (pulled out on first request and kept), then the one downloaded from Cover Art Archive.
 */
class ArtProvider : ContentProvider() {
    override fun onCreate() = true

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        val ctx = context ?: throw FileNotFoundException()
        val seg = uri.pathSegments
        if (seg.size != 3 || seg[0] != "t") throw FileNotFoundException(uri.toString())
        val trackId = seg[1].toLongOrNull() ?: throw FileNotFoundException(uri.toString())
        val base = seg[2].takeIf { it.matches(Regex("[0-9a-f-]+")) } ?: throw FileNotFoundException(uri.toString())
        val dir = File(ctx.filesDir, "art").apply { mkdirs() }

        val custom = File(dir, "$base-custom.jpg")
        val embedded = File(dir, "$base-embedded.jpg")
        val noEmbedded = File(dir, "$base.noembed")
        val front = File(dir, "$base-front.jpg")

        val file = when {
            custom.exists() -> custom
            embedded.exists() -> embedded
            !noEmbedded.exists() && extract(ctx, trackId, embedded) -> embedded
            front.exists() -> front
            else -> {
                noEmbedded.takeIf { !it.exists() }?.let { runCatching { it.createNewFile() } }
                throw FileNotFoundException("Inget omslag")
            }
        }
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    private fun extract(ctx: android.content.Context, trackId: Long, target: File): Boolean = try {
        val track = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, trackId)
        val bmp = ctx.contentResolver.loadThumbnail(track, Size(600, 600), null)
        val tmp = File(target.path + ".part")
        tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        tmp.renameTo(target)
    } catch (e: Exception) {
        File(target.parentFile, target.name.replace("-embedded.jpg", ".noembed")).let { runCatching { it.createNewFile() } }
        false
    }

    override fun getType(uri: Uri) = "image/jpeg"
    override fun query(uri: Uri, p: Array<out String>?, s: String?, a: Array<out String>?, o: String?): Cursor? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, s: String?, a: Array<out String>?) = 0
    override fun update(uri: Uri, v: ContentValues?, s: String?, a: Array<out String>?) = 0
}
